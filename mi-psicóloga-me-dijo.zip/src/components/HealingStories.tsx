import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { BookOpen, Sparkles, Heart, ChevronRight, Lock, RotateCw, CheckCircle2, Bookmark, Send, HelpCircle, AlertCircle, RefreshCw } from 'lucide-react';
import { Language, UserState } from '../types';
import { audioSynth } from '../lib/audio';

interface HealingStoriesProps {
  language: Language;
  userState: UserState;
  onGainXP: (amount: number) => void;
  onUpdateUserState: (updated: Partial<UserState>) => void;
  onNavigateToChat: (initialMessage: string) => void;
}

interface Story {
  id: number;
  titulo: string;
  historia: string;
  preguntaReflexion: string;
  reflexionGuiada: string;
  ejercicioPractico: {
    titulo: string;
    descripcion: string;
  };
  retoPersonalizado: string;
  minijuegoRelacionado: {
    titulo: string;
    descripcion: string;
    tipo: 'breathe' | 'pop_bubbles' | 'drop_stones' | string;
  };
  recompensa: string;
  fraseInspiradora: string;
  psicologaOpening: string;
}

export default function HealingStories({
  language,
  userState,
  onGainXP,
  onUpdateUserState,
  onNavigateToChat,
}: HealingStoriesProps) {
  const [stories, setStories] = useState<Story[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedStory, setSelectedStory] = useState<Story | null>(null);
  const [isRead, setIsRead] = useState(false);
  const [personalReflection, setPersonalReflection] = useState('');
  const [reflectionSaved, setReflectionSaved] = useState(false);
  const [savedStories, setSavedStories] = useState<number[]>([]);
  const [completedStories, setCompletedStories] = useState<number[]>([]);

  // Mini-game states
  const [bubbleList, setBubbleList] = useState<{ id: number; popped: boolean; x: number; y: number }[]>([]);
  const [stones, setStones] = useState<{ id: number; text: string; dropped: boolean }[]>([]);
  const [breathePhase, setBreathePhase] = useState<'inhale' | 'hold' | 'exhale'>('inhale');
  const [breatheCount, setBreatheCount] = useState(0);
  const [gameCompleted, setGameCompleted] = useState(false);

  // Block Builder game states
  const [blockGrid, setBlockGrid] = useState<(string | null)[][]>([]);
  const [currentBlockWord, setCurrentBlockWord] = useState<string>('');
  const [blockPlacements, setBlockPlacements] = useState<number>(0);
  const [blockWordsList, setBlockWordsList] = useState<string[]>([]);

  // Translations
  const t: Record<Language, Record<string, string>> = {
    es: {
      title: '🌸 Historias que Sanan',
      subtitle: 'Tres reflexiones profundas creadas especialmente para ti hoy.',
      loading: 'Tu psicóloga está tejiendo historias para ti...',
      error: 'Hubo un problema al conectar con el servidor terapéutico.',
      readBtn: 'He terminado de leer, Olivia',
      reflectionTitle: '🧘 Reflexión Guiada',
      questionTitle: '💡 Pregunta Poderosa',
      exerciseTitle: '✍️ Ejercicio Práctico',
      challengeTitle: '🚀 Reto Relacionado',
      gameTitle: '🎮 Minijuego Terapéutico',
      chatBtn: 'Platicar con Olivia sobre esto',
      saveStory: 'Guardar historia',
      savedStory: 'Historia guardada',
      writeReflection: 'Escribe tu reflexión personal aquí...',
      saveReflectionBtn: 'Guardar mi reflexión',
      reflectionSavedMsg: '¡Tu reflexión ha sido guardada en tu corazón y en tu diario! +25 XP',
      xpRewardMsg: '¡Felicidades, has completado esta historia! Has ganado +50 XP y desbloqueado:',
      breatheIn: 'Inhala profunda y suavemente...',
      breatheHold: 'Sostén el aire, siente tu paz...',
      breatheOut: 'Exhala, liberando toda tensión...',
      popBubblesDesc: 'Toca y disuelve cada una de las expectativas ajenas para recuperar tu paz:',
      blockBuilderDesc: 'Apila tus pilares emocionales para construir tu fortaleza de estabilidad:',
      blockBuilderDrop: 'Apilar',
      blockBuilderNext: 'Siguiente pilar:',
      blockBuilderGoal: 'Meta: 8 bloques',
      blockBuilderPlaced: 'Pilares colocados:',
      dropStonesDesc: 'Arrastra y suelta las piedras de culpa en el océano de tu perdón:',
      dropBtn: 'Lanzar piedra al mar 🌊',
      completedGame: '¡Minijuego completado con éxito! +20 XP',
      congratsDay: '¡Has completado una actividad significativa hoy! Has avanzado en tu camino:',
      backBtn: 'Volver a las historias',
      completedTag: 'Completada',
    },
    en: {
      title: '🌸 Stories that Heal',
      subtitle: 'Three profound reflections created especially for you today.',
      loading: 'Your therapist is weaving healing stories for you...',
      error: 'There was a problem connecting to the therapeutic server.',
      readBtn: 'I have finished reading, Olivia',
      reflectionTitle: '🧘 Guided Reflection',
      questionTitle: '💡 Powerful Question',
      exerciseTitle: '✍️ Practical Exercise',
      challengeTitle: '🚀 Related Challenge',
      gameTitle: '🎮 Therapeutic Minigame',
      chatBtn: 'Talk to Olivia about this',
      saveStory: 'Save story',
      savedStory: 'Story saved',
      writeReflection: 'Write your personal reflection here...',
      saveReflectionBtn: 'Save my reflection',
      reflectionSavedMsg: 'Your reflection has been saved in your heart and journal! +25 XP',
      xpRewardMsg: 'Congratulations, you have completed this story! You earned +50 XP and unlocked:',
      breatheIn: 'Inhale deeply and gently...',
      breatheHold: 'Hold your breath, feel your peace...',
      breatheOut: 'Exhale, releasing all tension...',
      popBubblesDesc: 'Tap and dissolve each of the external expectations to reclaim your peace:',
      blockBuilderDesc: 'Stack your emotional pillars to build your fortress of stability:',
      blockBuilderDrop: 'Stack',
      blockBuilderNext: 'Next pillar:',
      blockBuilderGoal: 'Goal: 8 blocks',
      blockBuilderPlaced: 'Pillars placed:',
      dropStonesDesc: 'Drag and drop the stones of guilt into the ocean of your forgiveness:',
      dropBtn: 'Throw stone to the sea 🌊',
      completedGame: 'Minigame successfully completed! +20 XP',
      congratsDay: 'You have completed a significant activity today! You advanced in your journey:',
      backBtn: 'Back to stories',
      completedTag: 'Completed',
    },
    pt: {
      title: '🌸 Histórias que Curam',
      subtitle: 'Três reflexões profundas criadas especialmente para você hoje.',
      loading: 'Sua psicóloga está tecendo histórias para você...',
      error: 'Houve um problema ao conectar com o servidor terapêutico.',
      readBtn: 'Terminei de ler, Olivia',
      reflectionTitle: '🧘 Reflexão Guiada',
      questionTitle: '💡 Pergunta Poderosa',
      exerciseTitle: '✍️ Exercício Prático',
      challengeTitle: '🚀 Desafio Relacionado',
      gameTitle: '🎮 Minijogo Terapêutico',
      chatBtn: 'Conversar com Olivia sobre isso',
      saveStory: 'Salvar história',
      savedStory: 'História salva',
      writeReflection: 'Escreva sua reflexão pessoal aqui...',
      saveReflectionBtn: 'Salvar minha reflexão',
      reflectionSavedMsg: 'Sua reflexão foi salva no seu coração e diário! +25 XP',
      xpRewardMsg: 'Parabéns, você completou esta história! Ganhou +50 XP e desbloqueou:',
      breatheIn: 'Inspire profunda e suavemente...',
      breatheHold: 'Segure o ar, sinta sua paz...',
      breatheOut: 'Expire, liberando toda tensão...',
      popBubblesDesc: 'Toque e dissolva cada uma das expectativas alheias para recuperar sua paz:',
      dropStonesDesc: 'Arraste e solte as pedras de culpa no oceano do seu perdão:',
      dropBtn: 'Lançar pedra ao mar 🌊',
      completedGame: 'Minijogo concluído com sucesso! +20 XP',
      congratsDay: 'Você completou uma atividade significativa hoje! Avançou em sua jornada:',
      backBtn: 'Voltar para as histórias',
      completedTag: 'Concluída',
    },
    it: {
      title: '🌸 Storie che Curano',
      subtitle: 'Tre riflessioni profonde create appositamente per te oggi.',
      loading: 'La tua psicologa sta tessendo storie per te...',
      error: 'Si è verificato un problema di connessione al server terapeutico.',
      readBtn: 'Ho finito di leggere, Olivia',
      reflectionTitle: '🧘 Riflessione Guidata',
      questionTitle: '💡 Domanda Potente',
      exerciseTitle: '✍️ Esercizio Pratico',
      challengeTitle: '🚀 Sfida Correlata',
      gameTitle: '🎮 Minigioco Terapeutico',
      chatBtn: 'Parla con Olivia di questo',
      saveStory: 'Salva storia',
      savedStory: 'Storia salvata',
      writeReflection: 'Scrivi qui la tua riflessione personale...',
      saveReflectionBtn: 'Salva la mia riflessione',
      reflectionSavedMsg: 'La tua riflessione è stata salvata nel tuo cuore e nel diario! +25 XP',
      xpRewardMsg: 'Congratulazioni, hai completato questa storia! Hai guadagnato +50 XP e sbloccato:',
      breatheIn: 'Inspira profondamente e dolcemente...',
      breatheHold: 'Trattieni il respiro, senti la tua pace...',
      breatheOut: 'Espira, rilasciando ogni tensione...',
      popBubblesDesc: 'Tocca e dissolvi ciascuna delle aspettative altrui per reclamare la tua pace:',
      dropStonesDesc: 'Trascina e rilascia le pietre del senso di colpa nell\'oceano del tuo perdono:',
      dropBtn: 'Lancia la pietra nel mare 🌊',
      completedGame: 'Minigioco completato con successo! +20 XP',
      congratsDay: 'Hai completato un\'attività significativa oggi! Sei avanzata nel tuo viaggio:',
      backBtn: 'Torna alle storie',
      completedTag: 'Completata',
    },
    fr: {
      title: '🌸 Histoires qui Guérissent',
      subtitle: 'Trois réflexions profondes créées spécialement pour vous aujourd\'hui.',
      loading: 'Votre psychologue tisse des histoires pour vous...',
      error: 'Un problème est survenu lors de la connexion au serveur thérapeutique.',
      readBtn: 'J\'ai fini de lire, Olivia',
      reflectionTitle: '🧘 Réflexion Guidée',
      questionTitle: '💡 Question Puissante',
      exerciseTitle: '✍️ Exercice Pratique',
      challengeTitle: '🚀 Défi Associé',
      gameTitle: '🎮 Mini-jeu Thérapeutique',
      chatBtn: 'Parler avec Olivia de cela',
      saveStory: 'Enregistrer l\'histoire',
      savedStory: 'Histoire enregistrée',
      writeReflection: 'Écrivez votre réflexion personnelle ici...',
      saveReflectionBtn: 'Enregistrer ma réflexion',
      reflectionSavedMsg: 'Votre réflexion a été enregistrée dans votre cœur et journal ! +25 XP',
      xpRewardMsg: 'Félicitations, vous avez complété cette histoire ! Vous avez gagné +50 XP et débloqué :',
      breatheIn: 'Inspirez profondément et doucement...',
      breatheHold: 'Bloquez l\'air, ressentez votre paix...',
      breatheOut: 'Expirez, libérant toute tension...',
      popBubblesDesc: 'Touchez et dissolvez chacune des attentes des autres pour retrouver votre paix :',
      dropStonesDesc: 'Faites glisser et déposez les pierres de culpabilité dans l\'océan de votre pardon :',
      dropBtn: 'Jeter la pierre à la mer 🌊',
      completedGame: 'Mini-jeu complété avec succès ! +20 XP',
      congratsDay: 'Vous avez complété une activité significative aujourd\'hui ! Vous avancez dans votre chemin :',
      backBtn: 'Retour aux histoires',
      completedTag: 'Complétée',
    },
    de: {
      title: '🌸 Geschichten, die Heilen',
      subtitle: 'Drei tiefgründige Reflexionen, die heute speziell für dich erstellt wurden.',
      loading: 'Deine Psychologin webt Geschichten für dich...',
      error: 'Verbindungsproblem mit dem therapeutischen Server.',
      readBtn: 'Ich habe zu Ende gelesen, Olivia',
      reflectionTitle: '🧘 Geführte Reflexion',
      questionTitle: '💡 Kraftvolle Frage',
      exerciseTitle: '✍️ Praktische Übung',
      challengeTitle: '🚀 Zugehörige Herausforderung',
      gameTitle: '🎮 Therapeutisches Minispiel',
      chatBtn: 'Sprich mit Olivia darüber',
      saveStory: 'Geschichte speichern',
      savedStory: 'Geschichte gespeichert',
      writeReflection: 'Schreibe hier deine persönliche Reflexion...',
      saveReflectionBtn: 'Meine Reflexion speichern',
      reflectionSavedMsg: 'Deine Reflexion wurde in deinem Herzen und Tagebuch gespeichert! +25 XP',
      xpRewardMsg: 'Herzlichen Glückwunsch, du hast diese Geschichte abgeschlossen! Du hast +50 XP verdient und freigeschaltet:',
      breatheIn: 'Atme tief und sanft ein...',
      breatheHold: 'Halte den Atem an, spüre deinen Frieden...',
      breatheOut: 'Atme aus und lass alle Spannung los...',
      popBubblesDesc: 'Tippe auf die Erwartungen anderer und löse sie auf, um deinen Frieden wiederzufinden:',
      dropStonesDesc: 'Ziehe die Steine der Schuld in das Meer deiner Vergebung:',
      dropBtn: 'Stein ins Meer werfen 🌊',
      completedGame: 'Minispiel erfolgreich beendet! +20 XP',
      congratsDay: 'Du hast heute eine bedeutende Aktivität abgeschlossen! Du hast dich auf deinem Weg weiterentwickelt:',
      backBtn: 'Zurück zu den Geschichten',
      completedTag: 'Abgeschlossen',
    },
    nl: {
      title: '🌸 Verhalen die Helen',
      subtitle: 'Drie diepgaande reflecties speciaal voor jou gemaakt vandaag.',
      loading: 'Je psycholoog weeft helende verhalen voor jou...',
      error: 'Er was een probleem met de verbinding naar de therapeutische server.',
      readBtn: 'Ik ben klaar met lezen, Olivia',
      reflectionTitle: '🧘 Begeleide Reflectie',
      questionTitle: '💡 Krachtige Vraag',
      exerciseTitle: '✍️ Praktische Oefening',
      challengeTitle: '🚀 Gerelateerde Uitdaging',
      gameTitle: '🎮 Therapeutisch Minispel',
      chatBtn: 'Praat met Olivia hierover',
      saveStory: 'Verhaal opslaan',
      savedStory: 'Verhaal opgeslagen',
      writeReflection: 'Schrijf hier je persoonlijke reflectie...',
      saveReflectionBtn: 'Sla mijn reflectie op',
      reflectionSavedMsg: 'Je reflectie is opgeslagen in je hart en dagboek! +25 XP',
      xpRewardMsg: 'Gefeliciteerd, je hebt dit verhaal voltooid! Je hebt +50 XP verdiend en ontgrendeld:',
      breatheIn: 'Adem diep en rustig in...',
      breatheHold: 'Houd je adem in, voel je vrede...',
      breatheOut: 'Adem uit, laat alle spanning los...',
      popBubblesDesc: 'Tik en los de verwachtingen van anderen op om je rust terug te krijgen:',
      dropStonesDesc: 'Sleep en zet de stenen van schuld in de oceaan van je vergeving:',
      dropBtn: 'Gooi steen in zee 🌊',
      completedGame: 'Minispel succesvol voltooid! +20 XP',
      congratsDay: 'Je hebt vandaag een belangrijke activiteit voltooid! Je bent vooruitgegaan op je pad:',
      backBtn: 'Terug naar verhalen',
      completedTag: 'Voltooid',
    },
    ca: {
      title: '🌸 Històries que Sanen',
      subtitle: 'Tres reflexions profundes creades especialment per a tu avui.',
      loading: 'La teva psicòloga està teixint històries per a tu...',
      error: 'Hi ha hagut un problema de connexió amb el servidor terapèutic.',
      readBtn: 'He acabat de llegir, Olivia',
      reflectionTitle: '🧘 Reflexió Guiada',
      questionTitle: '💡 Pregunta Poderosa',
      exerciseTitle: '✍️ Exercici Pràctic',
      challengeTitle: '🚀 Repte Relacionat',
      gameTitle: '🎮 Minijoc Terapèutic',
      chatBtn: 'Parlar amb l\'Olivia sobre això',
      saveStory: 'Desar història',
      savedStory: 'Història desada',
      writeReflection: 'Escriu la teva reflexió personal aquí...',
      saveReflectionBtn: 'Desar la meva reflexió',
      reflectionSavedMsg: 'La teva reflexió s\'ha desat al teu cor i diari! +25 XP',
      xpRewardMsg: 'Enhorabona, has completat aquesta història! Has guanyat +50 XP i desbloquejat:',
      breatheIn: 'Inspira profundament i suau...',
      breatheHold: 'Aguanta l\'aire, sent la teva pau...',
      breatheOut: 'Expira, alliberant tota tensió...',
      popBubblesDesc: 'Toca i dissol cada una de les expectatives ajenes per recuperar la teva pau:',
      dropStonesDesc: 'Arrossega i deixa anar les pedres de culpa a l\'oceà del teu perdó:',
      dropBtn: 'Llençar pedra al mar 🌊',
      completedGame: 'Minijoc completat amb èxit! +20 XP',
      congratsDay: 'Has completat una activitat significativa avui! Has avançat en el teu camí:',
      backBtn: 'Tornar a les històries',
      completedTag: 'Completada',
    }
  };

  const curr = t[language] || t['es'];

  // Fetch stories on load
  useEffect(() => {
    fetchStories();
    // Load local saves
    try {
      const saved = localStorage.getItem('saved_stories_list');
      if (saved) setSavedStories(JSON.parse(saved));
      const completed = localStorage.getItem('completed_stories_list');
      if (completed) setCompletedStories(JSON.parse(completed));
    } catch (e) {
      console.error(e);
    }
  }, [language, userState.daysAcompanamiento]);

  const fetchStories = async () => {
    const cacheKey = `daily_stories_cache_${userState.name || 'María'}_day${userState.daysAcompanamiento || 1}_${language}`;
    try {
      const cached = localStorage.getItem(cacheKey);
      if (cached) {
        const parsed = JSON.parse(cached);
        if (parsed && parsed.length === 4) {
          setStories(parsed);
          setLoading(false);
          return; // Instant 0ms load!
        }
      }
    } catch (e) {
      console.error("Cache read error:", e);
    }

    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/gemini/generate-four-stories', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userName: userState.name,
          mood: Object.values(userState.moodHistory).pop() || 'ansiosa',
          daysAcompanamiento: userState.daysAcompanamiento || 1,
          language,
        }),
      });
      if (!res.ok) throw new Error('API failed');
      const data = await res.json();
      if (data.stories && data.stories.length > 0) {
        setStories(data.stories);
        try {
          localStorage.setItem(cacheKey, JSON.stringify(data.stories));
        } catch (e) {
          console.error("Cache write error:", e);
        }
      } else {
        throw new Error('No stories returned');
      }
    } catch (err) {
      console.error(err);
      setError(curr.error);
    } finally {
      setLoading(false);
    }
  };

  // Select a story
  const handleSelectStory = (story: Story) => {
    setSelectedStory(story);
    setIsRead(false);
    setPersonalReflection('');
    setReflectionSaved(false);
    setGameCompleted(false);

    // Initialize mini game based on story
    if (story.minijuegoRelacionado.tipo === 'pop_bubbles') {
      setBubbleList(
        Array.from({ length: 5 }).map((_, i) => ({
          id: i,
          popped: false,
          x: Math.random() * 80 + 10,
          y: Math.random() * 60 + 20,
        }))
      );
    } else if (story.minijuegoRelacionado.tipo === 'drop_stones') {
      const stoneWords = language === 'es' || language === 'ca' 
        ? ['Culpabilidad', 'Excesiva exigencia', 'Miedo a defraudar', 'Tristeza oculta', 'No ser suficiente']
        : ['Guilt', 'Over-demanding', 'Fear of disappointing', 'Hidden sadness', 'Not being enough'];
      setStones(stoneWords.map((word, i) => ({ id: i, text: word, dropped: false })));
    } else if (story.minijuegoRelacionado.tipo === 'block_builder') {
      // Initialize an empty 6x8 grid (8 rows, 6 columns, from bottom row index 0 to top index 7)
      const initialGrid = Array.from({ length: 8 }, () => Array(6).fill(null));
      setBlockGrid(initialGrid);
      setBlockPlacements(0);
      const gameWords = language === 'es' || language === 'ca'
        ? ['Amor Propio 💖', 'Paz 🕊️', 'Límites 🛡️', 'Respeto 🌸', 'Perdón ✨', 'Aceptación 🌿', 'Fuerza ⚡', 'Cuidado 🌱', 'Tiempo ⏳', 'Paciencia 🧘']
        : ['Self-Love 💖', 'Peace 🕊️', 'Boundaries 🛡️', 'Respect 🌸', 'Forgiveness ✨', 'Acceptance 🌿', 'Strength ⚡', 'Self-Care 🌱', 'Time ⏳', 'Patience 🧘'];
      setBlockWordsList(gameWords);
      const randomWord = gameWords[Math.floor(Math.random() * gameWords.length)];
      setCurrentBlockWord(randomWord);
    } else {
      // breathe game
      setBreathePhase('inhale');
      setBreatheCount(0);
    }

    audioSynth.playBell(523.25);
  };

  // Close story
  const handleBackToList = () => {
    setSelectedStory(null);
    setIsRead(false);
    audioSynth.playBell(392.00);
  };

  // Save/Bookmark Story
  const handleToggleSaveStory = (id: number) => {
    let next: number[] = [];
    if (savedStories.includes(id)) {
      next = savedStories.filter((s) => s !== id);
    } else {
      next = [...savedStories, id];
      audioSynth.playBell(659.25); // high bell
    }
    setSavedStories(next);
    localStorage.setItem('saved_stories_list', JSON.stringify(next));
  };

  // Complete story reading, unlock experience
  const handleCompleteStoryReading = () => {
    setIsRead(true);
    audioSynth.playBell(523.25);

    // Reward XP (+50 XP)
    onGainXP(50);

    // Unlock badge / complete tasks
    if (selectedStory) {
      // Save to completed stories list
      if (!completedStories.includes(selectedStory.id)) {
        const nextCompleted = [...completedStories, selectedStory.id];
        setCompletedStories(nextCompleted);
        localStorage.setItem('completed_stories_list', JSON.stringify(nextCompleted));
      }

      // Check if Companion Day needs to be advanced!
      // ONLY advance when completing a story and it's a new day!
      const todayStr = new Date().toISOString().split('T')[0];
      const lastActive = userState.lastActiveDate;
      const alreadyAdvancedToday = localStorage.getItem(`day_advanced_${todayStr}`);

      if (!alreadyAdvancedToday) {
        // Advance Companion Day!
        const currentDays = userState.daysAcompanamiento || 1;
        const newDays = currentDays + 1;
        
        onUpdateUserState({
          daysAcompanamiento: newDays,
          lastActiveDate: todayStr,
        });

        localStorage.setItem(`day_advanced_${todayStr}`, 'true');

        // Show a nice bell & alert
        setTimeout(() => {
          audioSynth.playBell(587.33);
        }, 1000);
      }
    }
  };

  // Mini-game actions
  const handlePopBubble = (id: number) => {
    setBubbleList(prev => {
      const updated = prev.map(b => (b.id === id ? { ...b, popped: true } : b));
      if (updated.every(b => b.popped)) {
        setGameCompleted(true);
        onGainXP(20);
        audioSynth.playBell(783.99); // high G
      } else {
        audioSynth.playBell(523.25); // pop chime
      }
      return updated;
    });
  };

  const handleDropStone = (id: number) => {
    setStones(prev => {
      const updated = prev.map(s => (s.id === id ? { ...s, dropped: true } : s));
      if (updated.every(s => s.dropped)) {
        setGameCompleted(true);
        onGainXP(20);
        audioSynth.playBell(783.99);
      } else {
        audioSynth.playBell(349.23); // low water plop sound
      }
      return updated;
    });
  };

  const handleDropBlock = (col: number) => {
    if (gameCompleted) return;

    // Find the first empty cell in this column from bottom (row 0 to 7)
    let targetRow = -1;
    for (let r = 0; r < 8; r++) {
      if (blockGrid[r][col] === null) {
        targetRow = r;
        break;
      }
    }

    if (targetRow === -1) {
      // Column is full - let's play a low chime and clear this specific column to allow stress-free rebuilding
      audioSynth.playBell(261.63); // low C
      const nextGrid = blockGrid.map(row => [...row]);
      for (let r = 0; r < 8; r++) {
        nextGrid[r][col] = null;
      }
      setBlockGrid(nextGrid);
      return;
    }

    // Place the block
    const nextGrid = blockGrid.map(row => [...row]);
    nextGrid[targetRow][col] = currentBlockWord;
    setBlockGrid(nextGrid);

    // Play a nice bell frequency proportional to the row height
    const baseFreqs = [261.63, 293.66, 329.63, 349.23, 392.00, 440.00, 493.88, 523.25];
    const freq = baseFreqs[targetRow] || 392.00;
    audioSynth.playBell(freq);

    const nextPlacements = blockPlacements + 1;
    setBlockPlacements(nextPlacements);

    // Check for row clears (all 6 columns in a row are occupied)
    let rowCleared = false;
    let finalGrid = nextGrid.map(row => [...row]);
    
    for (let r = 0; r < 8; r++) {
      if (finalGrid[r].every(cell => cell !== null)) {
        rowCleared = true;
        // Shift rows down
        for (let shiftRow = r; shiftRow < 7; shiftRow++) {
          finalGrid[shiftRow] = [...finalGrid[shiftRow + 1]];
        }
        finalGrid[7] = Array(6).fill(null);
        r--; // Recheck same row index since we shifted down
      }
    }

    if (rowCleared) {
      setBlockGrid(finalGrid);
      // Play a beautiful double chime
      setTimeout(() => {
        audioSynth.playBell(587.33);
        setTimeout(() => {
          audioSynth.playBell(783.99);
        }, 120);
      }, 100);
    }

    // Select next random block word
    if (blockWordsList.length > 0) {
      const randomWord = blockWordsList[Math.floor(Math.random() * blockWordsList.length)];
      setCurrentBlockWord(randomWord);
    }

    // Win condition check (placed 8 blocks total)
    if (nextPlacements >= 8) {
      setGameCompleted(true);
      onGainXP(20);
      setTimeout(() => {
        audioSynth.playBell(783.99);
        setTimeout(() => audioSynth.playBell(1046.50), 150);
      }, 300);
    }
  };

  // Breathing game phase step
  useEffect(() => {
    if (selectedStory && isRead && selectedStory.minijuegoRelacionado.tipo === 'breathe' && !gameCompleted) {
      const interval = setInterval(() => {
        setBreathePhase(prev => {
          if (prev === 'inhale') return 'hold';
          if (prev === 'hold') return 'exhale';
          // exhale
          setBreatheCount(c => {
            const next = c + 1;
            if (next >= 3) {
              setGameCompleted(true);
              onGainXP(20);
              audioSynth.playBell(783.99);
            }
            return next;
          });
          return 'inhale';
        });
      }, 4000);

      return () => clearInterval(interval);
    }
  }, [selectedStory, isRead, gameCompleted]);

  // Save Reflection Note
  const handleSaveReflection = () => {
    if (!personalReflection.trim() || !selectedStory) return;
    setReflectionSaved(true);
    onGainXP(25);
    audioSynth.playBell(659.25);

    // Save reflection to user diary
    const savedReflectionsKey = 'user_therapeutic_reflections';
    try {
      const existing = localStorage.getItem(savedReflectionsKey);
      const list = existing ? JSON.parse(existing) : [];
      list.push({
        id: Date.now().toString(),
        storyTitle: selectedStory.titulo,
        reflection: personalReflection.trim(),
        date: new Date().toLocaleDateString(),
      });
      localStorage.setItem(savedReflectionsKey, JSON.stringify(list));
    } catch (e) {
      console.error(e);
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-center p-6 space-y-4">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ repeat: Infinity, duration: 2, ease: 'linear' }}
          className="w-16 h-16 rounded-full border-4 border-rose-100 border-t-rose-500"
        />
        <p className="text-sm font-semibold text-neutral-500 tracking-wide animate-pulse">
          {curr.loading}
        </p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-center p-6 space-y-4">
        <AlertCircle className="w-12 h-12 text-rose-500" />
        <p className="text-sm font-semibold text-neutral-600">{error}</p>
        <button
          onClick={fetchStories}
          className="px-5 py-2.5 rounded-full bg-rose-500 text-white font-bold text-sm tracking-wide shadow-md hover:bg-rose-600 transition-all flex items-center gap-2"
        >
          <RefreshCw className="w-4 h-4" /> Reintentar
        </button>
      </div>
    );
  }

  return (
    <div className="px-4 py-6 max-w-lg mx-auto pb-28">
      <AnimatePresence mode="wait">
        {!selectedStory ? (
          // Story Selection Panel
          <motion.div
            key="list"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            className="space-y-6"
          >
            <div className="space-y-1.5 text-center">
              <h2 className="text-2xl font-black text-rose-500 tracking-tight flex items-center justify-center gap-2">
                {curr.title}
              </h2>
              <p className="text-xs text-neutral-400 font-medium">
                {curr.subtitle}
              </p>
            </div>

            <div className="grid grid-cols-1 gap-4">
              {stories.map((story) => {
                const isCompleted = completedStories.includes(story.id);
                const isSaved = savedStories.includes(story.id);

                return (
                  <motion.div
                    key={story.id}
                    whileHover={{ scale: 1.01 }}
                    whileTap={{ scale: 0.99 }}
                    onClick={() => handleSelectStory(story)}
                    className="p-5 rounded-3xl border border-rose-100 bg-white/80 backdrop-blur-md shadow-sm hover:shadow-md transition-all cursor-pointer relative overflow-hidden"
                  >
                    {/* Background glow card decor */}
                    <div className="absolute -top-12 -right-12 w-24 h-24 bg-rose-400/5 rounded-full blur-xl pointer-events-none" />

                    <div className="flex items-start justify-between gap-4">
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-black uppercase tracking-wider text-rose-400">
                            Premium • {language === 'es' || language === 'ca' ? `Historia ${story.id}` : `Story ${story.id}`}
                          </span>
                          {isCompleted && (
                            <span className="px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-600 text-[9px] font-bold flex items-center gap-0.5">
                              <CheckCircle2 className="w-2.5 h-2.5" /> {curr.completedTag}
                            </span>
                          )}
                        </div>

                        <h3 className="text-lg font-black text-neutral-800 leading-snug">
                          {story.titulo}
                        </h3>

                        <p className="text-xs text-neutral-500 line-clamp-2 leading-relaxed">
                          {story.historia}
                        </p>
                      </div>

                      <div className="flex flex-col items-center gap-2">
                        <div className="w-10 h-10 rounded-2xl bg-rose-50/50 border border-rose-100 flex items-center justify-center text-rose-500">
                          <BookOpen className="w-5 h-5" />
                        </div>
                        {isSaved && (
                          <Bookmark className="w-4 h-4 text-rose-400 fill-rose-400" />
                        )}
                      </div>
                    </div>

                    <div className="mt-4 pt-3 border-t border-rose-50 flex items-center justify-between text-[10px] text-neutral-400 font-bold tracking-wide">
                      <span className="flex items-center gap-1">
                        🎁 +50 XP
                      </span>
                      <span className="text-rose-400 flex items-center gap-0.5 hover:underline">
                        Comenzar <ChevronRight className="w-3 h-3" />
                      </span>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </motion.div>
        ) : (
          // Active Story Guided View
          <motion.div
            key="story-view"
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.98 }}
            className="space-y-6"
          >
            {/* Header toolbar */}
            <div className="flex items-center justify-between">
              <button
                onClick={handleBackToList}
                className="text-xs font-bold text-neutral-400 hover:text-neutral-700 flex items-center gap-1 border border-neutral-100 rounded-full px-3 py-1.5 bg-white/50 backdrop-blur-sm cursor-pointer"
              >
                ← {curr.backBtn}
              </button>

              <button
                onClick={() => handleToggleSaveStory(selectedStory.id)}
                className={`p-2 rounded-full border cursor-pointer transition-colors ${
                  savedStories.includes(selectedStory.id)
                    ? 'bg-rose-50 border-rose-200 text-rose-500'
                    : 'bg-white/50 border-neutral-100 text-neutral-400 hover:text-neutral-700'
                }`}
              >
                <Bookmark className={`w-4 h-4 ${savedStories.includes(selectedStory.id) ? 'fill-rose-500' : ''}`} />
              </button>
            </div>

            {/* Main Story Content Card */}
            <div className="p-6 rounded-3xl border border-rose-100 bg-white/90 backdrop-blur-md shadow-lg space-y-6 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-rose-400/5 rounded-full blur-2xl pointer-events-none" />

              <div className="space-y-2 text-center">
                <span className="text-[10px] font-black uppercase tracking-widest text-rose-400">
                  🌸 {curr.title}
                </span>
                <h3 className="text-xl font-black text-neutral-800 leading-tight">
                  {selectedStory.titulo}
                </h3>
              </div>

              {/* Story Content Block */}
              <div className="text-sm text-neutral-700 leading-relaxed space-y-4 font-normal">
                {selectedStory.historia.split('\n\n').map((para, idx) => (
                  <p key={idx} className="indent-2">
                    {para}
                  </p>
                ))}
              </div>

              {/* Quote frame */}
              <div className="p-4 rounded-2xl bg-rose-50/40 border border-rose-100/50 text-center relative italic text-rose-700 font-medium text-xs leading-relaxed">
                "{selectedStory.fraseInspiradora}"
              </div>

              {/* Read Confirmation Button */}
              {!isRead && (
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={handleCompleteStoryReading}
                  className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-rose-400 to-rose-500 text-white font-black text-sm tracking-wide shadow-lg cursor-pointer"
                >
                  {curr.readBtn}
                </motion.button>
              )}
            </div>

            {/* Post-Story Interactive Experience */}
            <AnimatePresence>
              {isRead && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="space-y-6"
                >
                  {/* Guided Reflection Card */}
                  <div className="p-5 rounded-3xl border border-rose-100 bg-white/80 backdrop-blur-md shadow-sm space-y-3">
                    <h4 className="text-sm font-black text-neutral-800">
                      {curr.reflectionTitle}
                    </h4>
                    <p className="text-xs text-neutral-600 leading-relaxed">
                      {selectedStory.reflexionGuiada}
                    </p>
                  </div>

                  {/* Powerful Question Card */}
                  <div className="p-5 rounded-3xl border border-rose-100 bg-white/80 backdrop-blur-md shadow-sm space-y-3">
                    <h4 className="text-sm font-black text-neutral-800">
                      {curr.questionTitle}
                    </h4>
                    <p className="text-xs text-rose-500 italic leading-relaxed">
                      {selectedStory.preguntaReflexion}
                    </p>
                  </div>

                  {/* Practical Exercise Card */}
                  <div className="p-5 rounded-3xl border border-rose-100 bg-white/80 backdrop-blur-md shadow-sm space-y-3">
                    <h4 className="text-sm font-black text-neutral-800">
                      {curr.exerciseTitle}
                    </h4>
                    <div className="p-3.5 rounded-2xl bg-neutral-50/50 border border-neutral-100 space-y-1.5">
                      <h5 className="text-xs font-black text-neutral-700">
                        {selectedStory.ejercicioPractico.titulo}
                      </h5>
                      <p className="text-xs text-neutral-500 leading-relaxed">
                        {selectedStory.ejercicioPractico.descripcion}
                      </p>
                    </div>
                  </div>

                  {/* Related Challenge Card */}
                  <div className="p-5 rounded-3xl border border-rose-100 bg-white/80 backdrop-blur-md shadow-sm space-y-3">
                    <h4 className="text-sm font-black text-neutral-800">
                      {curr.challengeTitle}
                    </h4>
                    <p className="text-xs text-neutral-600 leading-relaxed bg-amber-50/30 border border-amber-100/50 p-3 rounded-2xl">
                      🎯 {selectedStory.retoPersonalizado}
                    </p>
                  </div>

                  {/* Embedded Interactive Therapeutic Minigame */}
                  <div className="p-5 rounded-3xl border border-rose-100 bg-white/80 backdrop-blur-md shadow-sm space-y-3">
                    <div className="flex items-center justify-between">
                      <h4 className="text-sm font-black text-neutral-800">
                        {curr.gameTitle}
                      </h4>
                      {gameCompleted && (
                        <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full flex items-center gap-0.5">
                          ✓ {language === 'es' || language === 'ca' ? 'Hecho' : 'Done'}
                        </span>
                      )}
                    </div>
                    <div className="p-4 rounded-2xl bg-rose-50/20 border border-rose-100/30 space-y-3 text-center min-h-[140px] flex flex-col justify-center">
                      <div className="space-y-1">
                        <h5 className="text-xs font-black text-neutral-700">
                          {selectedStory.minijuegoRelacionado.titulo}
                        </h5>
                        <p className="text-[11px] text-neutral-500 leading-relaxed">
                          {selectedStory.minijuegoRelacionado.descripcion}
                        </p>
                      </div>

                      {/* Render Game: Breathe */}
                      {selectedStory.minijuegoRelacionado.tipo === 'breathe' && !gameCompleted && (
                        <div className="flex flex-col items-center justify-center py-4 space-y-4">
                          <motion.div
                            animate={{
                              scale: breathePhase === 'inhale' ? 1.5 : (breathePhase === 'hold' ? 1.5 : 0.8),
                            }}
                            transition={{ duration: 4, ease: 'easeInOut' }}
                            className="w-14 h-14 bg-rose-400/30 border-2 border-rose-400 rounded-full flex items-center justify-center text-rose-600 shadow-inner"
                          >
                            <Heart className="w-5 h-5 fill-rose-300 animate-pulse" />
                          </motion.div>
                          <span className="text-xs font-bold text-rose-500">
                            {breathePhase === 'inhale' && curr.breatheIn}
                            {breathePhase === 'hold' && curr.breatheHold}
                            {breathePhase === 'exhale' && curr.breatheOut}
                          </span>
                          <span className="text-[10px] text-neutral-400 font-bold">
                            {language === 'es' || language === 'ca' ? `Ciclos: ${breatheCount} / 3` : `Cycles: ${breatheCount} / 3`}
                          </span>
                        </div>
                      )}

                      {/* Render Game: Pop Bubbles */}
                      {selectedStory.minijuegoRelacionado.tipo === 'pop_bubbles' && !gameCompleted && (
                        <div className="space-y-2">
                          <p className="text-[10px] text-rose-500 font-medium">{curr.popBubblesDesc}</p>
                          <div className="relative w-full h-32 bg-rose-50/10 border border-rose-100/20 rounded-xl overflow-hidden flex items-center justify-around">
                            {bubbleList.map((bubble) => (
                              <AnimatePresence key={bubble.id}>
                                {!bubble.popped && (
                                  <motion.button
                                    whileHover={{ scale: 1.1 }}
                                    whileTap={{ scale: 0.8 }}
                                    onClick={() => handlePopBubble(bubble.id)}
                                    className="w-8 h-8 rounded-full bg-gradient-to-tr from-rose-200 to-rose-300 border border-white/60 text-white font-bold flex items-center justify-center shadow cursor-pointer text-xs"
                                  >
                                    🫧
                                  </motion.button>
                                )}
                              </AnimatePresence>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Render Game: Drop Stones */}
                      {selectedStory.minijuegoRelacionado.tipo === 'drop_stones' && !gameCompleted && (
                        <div className="space-y-3">
                          <p className="text-[10px] text-rose-500 font-medium">{curr.dropStonesDesc}</p>
                          <div className="flex flex-wrap gap-2 justify-center">
                            {stones.map((stone) => (
                              <button
                                key={stone.id}
                                disabled={stone.dropped}
                                onClick={() => handleDropStone(stone.id)}
                                className={`px-2.5 py-1.5 rounded-full border text-[10px] font-bold transition-all cursor-pointer flex items-center gap-1 ${
                                  stone.dropped
                                    ? 'bg-emerald-50 border-emerald-100 text-emerald-500 line-through opacity-50'
                                    : 'bg-neutral-100 border-neutral-200 text-neutral-600 hover:bg-neutral-200'
                                }`}
                              >
                                🪨 {stone.text}
                              </button>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Render Game: Block Builder (Tetris) */}
                      {selectedStory.minijuegoRelacionado.tipo === 'block_builder' && !gameCompleted && (
                        <div className="space-y-4 text-center">
                          <p className="text-[10px] text-rose-500 font-medium">{curr.blockBuilderDesc}</p>
                          
                          {/* Current Block Preview */}
                          <div className="flex items-center justify-center gap-3 bg-rose-50/50 border border-rose-100 p-2.5 rounded-xl max-w-xs mx-auto shadow-sm">
                            <span className="text-[10px] font-bold text-neutral-500 uppercase tracking-wider">{curr.blockBuilderNext}</span>
                            <motion.span
                              key={currentBlockWord}
                              initial={{ scale: 0.8, opacity: 0 }}
                              animate={{ scale: 1, opacity: 1 }}
                              className="px-3 py-1 rounded-full bg-rose-500 text-white text-xs font-black shadow-sm flex items-center gap-1.5"
                            >
                              {currentBlockWord}
                            </motion.span>
                          </div>

                          {/* Interactive Grid Area */}
                          <div className="w-full max-w-[260px] mx-auto bg-neutral-950 p-3 rounded-2xl shadow-2xl border border-neutral-800">
                            
                            {/* Column Selection Arrow Headers (Top of columns) */}
                            <div className="grid grid-cols-6 gap-1 mb-2.5">
                              {Array.from({ length: 6 }).map((_, colIdx) => (
                                <button
                                  key={colIdx}
                                  onClick={() => handleDropBlock(colIdx)}
                                  className="py-1 rounded-md bg-neutral-900 hover:bg-rose-500 border border-neutral-800 hover:border-rose-400 text-neutral-400 hover:text-white font-bold transition-all flex flex-col items-center justify-center cursor-pointer active:scale-95 text-[10px]"
                                  title={`Apilar en columna ${colIdx + 1}`}
                                >
                                  <span className="uppercase font-black tracking-tighter">C{colIdx + 1}</span>
                                  <span className="text-xs">↓</span>
                                </button>
                              ))}
                            </div>

                            {/* Grid Rows (Render from index 7 down to 0) */}
                            <div className="space-y-1">
                              {Array.from({ length: 8 }).map((_, rIdx) => {
                                const rowIdx = 7 - rIdx; // reverse index so 7 is at top
                                return (
                                  <div key={rowIdx} className="grid grid-cols-6 gap-1">
                                    {Array.from({ length: 6 }).map((_, colIdx) => {
                                      const word = blockGrid[rowIdx]?.[colIdx];
                                      // Get dynamic background based on row or word
                                      const hasBlock = !!word;
                                      return (
                                        <div
                                          key={colIdx}
                                          onClick={() => handleDropBlock(colIdx)}
                                          className={`relative aspect-square rounded flex items-center justify-center p-0.5 text-[8px] leading-none font-bold transition-all overflow-hidden select-none cursor-pointer border ${
                                            hasBlock
                                              ? 'bg-gradient-to-b from-rose-400 to-rose-500 border-rose-300 text-white shadow-md'
                                              : 'bg-neutral-900/85 border-neutral-800/50 text-transparent'
                                          }`}
                                        >
                                          {hasBlock && (
                                            <span className="break-all font-black leading-tight">
                                              {word.split(' ')[0]}
                                            </span>
                                          )}
                                        </div>
                                      );
                                    })}
                                  </div>
                                );
                              })}
                            </div>
                          </div>

                          {/* Progress Indicator */}
                          <div className="space-y-1">
                            <div className="text-[10px] text-neutral-500 font-bold flex items-center justify-between px-6">
                              <span>{curr.blockBuilderGoal}</span>
                              <span className="text-rose-500">{curr.blockBuilderPlaced} {blockPlacements} / 8</span>
                            </div>
                            
                            {/* Horizontal Progress Bar */}
                            <div className="w-11/12 mx-auto h-2 bg-neutral-200/50 border border-neutral-100 rounded-full overflow-hidden">
                              <motion.div
                                className="h-full bg-gradient-to-r from-rose-400 to-rose-500"
                                initial={{ width: 0 }}
                                animate={{ width: `${Math.min(100, (blockPlacements / 8) * 100)}%` }}
                              />
                            </div>
                          </div>
                        </div>
                      )}

                      {gameCompleted && (
                        <motion.div
                          initial={{ scale: 0.9 }}
                          animate={{ scale: 1 }}
                          className="text-center text-emerald-600 font-black text-xs py-3"
                        >
                          🎉 {curr.completedGame}
                        </motion.div>
                      )}
                    </div>
                  </div>

                  {/* Personal Reflection Input Panel */}
                  <div className="p-5 rounded-3xl border border-rose-100 bg-white/80 backdrop-blur-md shadow-sm space-y-4">
                    <h4 className="text-sm font-black text-neutral-800">
                      📝 {language === 'es' || language === 'ca' ? 'Mi Diario de Sanación' : 'My Healing Journal'}
                    </h4>
                    <textarea
                      value={personalReflection}
                      disabled={reflectionSaved}
                      onChange={(e) => setPersonalReflection(e.target.value)}
                      placeholder={curr.writeReflection}
                      className="w-full p-4 rounded-2xl border border-rose-100/60 bg-neutral-50/30 text-xs leading-relaxed outline-none focus:bg-white focus:border-rose-400 focus:ring-1 focus:ring-rose-400/30 transition-all min-h-[90px] resize-none"
                    />

                    {!reflectionSaved ? (
                      <button
                        onClick={handleSaveReflection}
                        disabled={!personalReflection.trim()}
                        className="w-full py-2.5 rounded-2xl bg-neutral-900 text-white font-bold text-xs tracking-wide cursor-pointer flex items-center justify-center gap-2 hover:bg-neutral-800 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
                      >
                        <Send className="w-3.5 h-3.5" /> {curr.saveReflectionBtn}
                      </button>
                    ) : (
                      <div className="text-emerald-600 font-black text-xs text-center flex items-center justify-center gap-1">
                        <CheckCircle2 className="w-4 h-4" /> {curr.reflectionSavedMsg}
                      </div>
                    )}
                  </div>

                  {/* Reward Medallion Unlock Panel */}
                  <div className="p-5 rounded-3xl border border-rose-200 bg-rose-50/30 backdrop-blur-md shadow-sm text-center space-y-3 relative overflow-hidden">
                    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 bg-rose-400/5 rounded-full blur-2xl pointer-events-none" />
                    <span className="text-3xl animate-bounce block">🏆</span>
                    <p className="text-xs font-semibold text-neutral-600 leading-relaxed">
                      {curr.xpRewardMsg}
                    </p>
                    <div className="inline-block px-4 py-2 rounded-full border border-rose-200 bg-white font-black text-xs text-rose-500 shadow-sm">
                      {selectedStory.recompensa}
                    </div>
                  </div>

                  {/* Chat With Therapist Trigger */}
                  <button
                    onClick={() => onNavigateToChat(selectedStory.psicologaOpening)}
                    className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-rose-500 to-rose-600 text-white font-black text-sm tracking-wide shadow-lg flex items-center justify-center gap-2 cursor-pointer hover:shadow-xl hover:from-rose-600 hover:to-rose-700 transition-all"
                  >
                    💬 {curr.chatBtn}
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
