import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Award, Flame, Calendar, Sparkles, BookOpen, ChevronRight, PenTool, CheckCircle, Heart, Star, Brain, Gift, RefreshCw, Gamepad2, HelpCircle, HeartHandshake, Layers, MessageCircle } from 'lucide-react';
import { Language, Mood, UserState, JournalEntry } from '../types';
import { audioSynth } from '../lib/audio';
import { getTemporalEvent } from '../lib/temporalEvents';
import { allSessions } from '../data/sessions';

interface DashboardProps {
  language: Language;
  userState: UserState;
  onGainXP: (amount: number) => void;
  onUpdateMood: (mood: Mood) => void;
  userId: string;
  onOpenMindGames: () => void;
  onNavigateToChat: (message: string) => void;
  onUnlockMedal?: (medalId: string) => void;
}

export default function Dashboard({
  language,
  userState,
  onGainXP,
  onUpdateMood,
  userId,
  onOpenMindGames,
  onNavigateToChat,
  onUnlockMedal
}: DashboardProps) {
  const [selectedMood, setSelectedMood] = useState<Mood | null>(null);
  const [dailyData, setDailyData] = useState<any>(null);
  const [loadingDaily, setLoadingDaily] = useState(false);

  // New Daily Story states
  const [storyData, setStoryData] = useState<any>(null);
  const [loadingStory, setLoadingStory] = useState(false);
  const [storyRead, setStoryRead] = useState(false);
  const [userReflectionText, setUserReflectionText] = useState('');
  const [reflectionSaved, setReflectionSaved] = useState(false);
  const [isFavorite, setIsFavorite] = useState(false);
  const [sharedSuccess, setSharedSuccess] = useState(false);
  const [minijameCompleted, setMinijameCompleted] = useState(false);
  const [overallStoryCompleted, setOverallStoryCompleted] = useState(false);

  // Journal form state
  const [journalNote, setJournalNote] = useState('');
  const [journalGratitude, setJournalGratitude] = useState('');
  const [journalLesson, setJournalLesson] = useState('');
  const [journalSaved, setJournalSaved] = useState(false);

  // Surprises & rewards
  const [chestOpened, setChestOpened] = useState(false);
  const [unlockedTask, setUnlockedTask] = useState<string | null>(null);

  // Dynamic temporal event state
  const currentEvent = getTemporalEvent(language);
  const [temporalAnswer, setTemporalAnswer] = useState('');
  const [temporalCompleted, setTemporalCompleted] = useState(false);

  // Custom live game & quiz state
  const [quizAnsweredIndex, setQuizAnsweredIndex] = useState<number | null>(null);
  const [showQuizExplanation, setShowQuizExplanation] = useState(false);
  const [mindgameCompleted, setMindgameCompleted] = useState(false);
  const [revealedCardIndex, setRevealedCardIndex] = useState<number | null>(null);

  const currentTheme = userState.theme;

  // Emotional options lists
  const moodOptions: { value: Mood; label: string; icon: string }[] = [
    { value: 'ansiosa', label: language === 'es' ? 'Ansiosa' : 'Anxious', icon: '😟' },
    { value: 'triste', label: language === 'es' ? 'Triste' : 'Sad', icon: '😢' },
    { value: 'con_miedo', label: language === 'es' ? 'Con miedo' : 'Scared', icon: '😨' },
    { value: 'sin_energia', label: language === 'es' ? 'Sin energía' : 'No Energy', icon: '🔋' },
    { value: 'con_culpa', label: language === 'es' ? 'Con culpa' : 'Guilty', icon: '😔' },
    { value: 'enojada', label: language === 'es' ? 'Enojada' : 'Angry', icon: '😡' },
    { value: 'con_ansiedad', label: language === 'es' ? 'Con ansiedad' : 'With Anxiety', icon: '😰' },
    { value: 'corazon_roto', label: language === 'es' ? 'Corazón roto' : 'Heartbroken', icon: '💔' },
    { value: 'necesito_paz', label: language === 'es' ? 'Necesito paz' : 'Need Peace', icon: '🕊️' },
    { value: 'necesito_ayuda', label: language === 'es' ? 'Necesito ayuda' : 'Need Help', icon: '🆘' },
    { value: 'quiero_crecer', label: language === 'es' ? 'Quiero crecer' : 'Want to Grow', icon: '🌱' },
    { value: 'quiero_sanar', label: language === 'es' ? 'Quiero sanar' : 'Want to Heal', icon: '✨' },
  ];

  const handleMoodSelect = async (mood: Mood) => {
    setSelectedMood(mood);
    onUpdateMood(mood);
    audioSynth.playBell(440.00); // Friendly tone

    // Reset story state variables for a fresh experience
    setLoadingDaily(true);
    setLoadingStory(true);
    setStoryRead(false);
    setReflectionSaved(false);
    setUserReflectionText('');
    setOverallStoryCompleted(false);
    setStoryData(null);
    setMinijameCompleted(false);

    // Identify corresponding session/chapter of "Mi Psicóloga Me Dijo"
    const companionDay = userState.daysAcompanamiento || 1;
    const sessionIndex = (companionDay - 1) % allSessions.length;
    const selectedSession = allSessions[sessionIndex] || allSessions[0];

    try {
      // Parallelize fetches for maximum responsiveness
      const dailyPromise = fetch('/api/gemini/generate-daily', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mood, language }),
      }).then(res => res.json());

      const storyPromise = fetch('/api/gemini/generate-story', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userName: userState.name,
          mood,
          moodHistory: userState.moodHistory,
          daysAcompanamiento: companionDay,
          language,
          sessionTitle: selectedSession.title,
          sessionSummary: selectedSession.summary,
          userGoals: []
        }),
      }).then(res => res.json());

      const [dailyRes, storyRes] = await Promise.all([dailyPromise, storyPromise]);
      setDailyData(dailyRes);
      setStoryData(storyRes);

      // Check if previously favorited
      const savedFavs = localStorage.getItem('mi_psicologa_favorites');
      if (savedFavs) {
        const favs = JSON.parse(savedFavs);
        const exists = favs.some((f: any) => f.title === storyRes.titulo);
        setIsFavorite(exists);
      } else {
        setIsFavorite(false);
      }
    } catch (e) {
      console.error('Failed to fetch daily interactive path:', e);
    } finally {
      setLoadingDaily(false);
      setLoadingStory(false);
    }
  };

  const handleMarkAsRead = () => {
    setStoryRead(true);
    audioSynth.playBell(587.33); // D5 pleasant chime
  };

  const handleToggleFavorite = () => {
    if (!storyData) return;
    const nextFavoriteState = !isFavorite;
    setIsFavorite(nextFavoriteState);
    audioSynth.playBell(659.25); // E5 friendly click

    const savedFavs = localStorage.getItem('mi_psicologa_favorites');
    let favs = savedFavs ? JSON.parse(savedFavs) : [];
    if (nextFavoriteState) {
      if (!favs.some((f: any) => f.title === storyData.titulo)) {
        favs.push({
          date: new Date().toLocaleDateString(),
          title: storyData.titulo,
          story: storyData.historia,
          quote: storyData.fraseInspiradora
        });
      }
    } else {
      favs = favs.filter((f: any) => f.title !== storyData.titulo);
    }
    localStorage.setItem('mi_psicologa_favorites', JSON.stringify(favs));
  };

  const handleShareQuote = () => {
    if (!storyData) return;
    navigator.clipboard.writeText(storyData.fraseInspiradora).then(() => {
      setSharedSuccess(true);
      audioSynth.playBell(523.25); // C5 positive chime
      setTimeout(() => {
        setSharedSuccess(false);
      }, 2500);
    }).catch(err => {
      console.error('Failed to copy text:', err);
    });
  };

  const handleSaveStoryReflection = () => {
    if (!storyData || !userReflectionText.trim() || reflectionSaved) return;
    setReflectionSaved(true);
    onGainXP(20);
    audioSynth.playBell(659.25);

    const savedRefs = localStorage.getItem('mi_psicologa_reflections');
    let refs = savedRefs ? JSON.parse(savedRefs) : [];
    refs.push({
      date: new Date().toLocaleDateString(),
      storyTitle: storyData.titulo,
      reflection: userReflectionText
    });
    localStorage.setItem('mi_psicologa_reflections', JSON.stringify(refs));
  };

  const handleCompleteMinijame = () => {
    if (minijameCompleted) return;
    setMinijameCompleted(true);
    onGainXP(15);
    audioSynth.playBell(783.99); // G5 happy chime
  };

  const handleNavigateToTherapist = () => {
    if (!storyData) return;
    onNavigateToChat(storyData.psicologaOpening);
  };

  const handleClaimFullExperience = () => {
    if (!storyData || overallStoryCompleted) return;
    setOverallStoryCompleted(true);
    onGainXP(50);
    audioSynth.playBell(523.25);
    setTimeout(() => {
      audioSynth.playBell(659.25);
    }, 200);

    // Unlock a custom daily medal
    if (onUnlockMedal) {
      onUnlockMedal(`daily_story_${Date.now()}`);
    }
  };

  const handleSaveJournal = async () => {
    if (!journalNote.trim()) return;
    setJournalSaved(true);
    onGainXP(50); // High XP rewards for self-expression CBT
    audioSynth.playBell(523.25);

    // Save to the database
    try {
      await fetch(`/api/history/${userId}/update`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mood: selectedMood,
          goal: journalLesson.trim() || 'Desarrollo emocional',
        }),
      });
    } catch (e) {}
  };

  const handleOpenChest = () => {
    if (chestOpened) return;
    setChestOpened(true);
    audioSynth.playBell(659.25); // E5 positive chime
    onGainXP(100); // Mega prize!
  };

  return (
    <div id="dashboard-container" className="max-w-2xl mx-auto space-y-6 overflow-y-auto h-[calc(100vh-140px)] pr-1 scrollbar-thin">
      {/* Gamification Header Bento Box */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Card 1: Companion Day & Name Greeting */}
        <div className={`p-5 rounded-3xl border md:col-span-2 flex flex-col justify-between shadow-md relative overflow-hidden ${
          currentTheme === 'dark' 
            ? 'bg-gradient-to-tr from-neutral-900 to-neutral-950 border-neutral-850 text-white' 
            : 'bg-gradient-to-tr from-rose-50/45 via-amber-50/30 to-rose-100/10 border-rose-100/50 text-neutral-800'
        }`}>
          <div className="absolute top-0 right-0 w-24 h-24 bg-rose-400/10 rounded-full blur-2xl pointer-events-none" />
          
          <div className="space-y-1">
            <div className="flex items-center gap-1.5 text-[10px] text-rose-500 font-extrabold uppercase tracking-widest">
              <Sparkles className="w-3.5 h-3.5 text-rose-400" />
              <span>{language === 'es' ? `🌱 DÍA ${userState.daysAcompanamiento || 1} DE TU CAMINO` : `🌱 DAY ${userState.daysAcompanamiento || 1} OF YOUR PATH`}</span>
            </div>
            <h2 className="text-xl font-black tracking-tight mt-1">
              {language === 'es' 
                ? `¡Me alegra volver a verte, ${userState.name || 'Amiga'}! 🌸` 
                : `So glad to see you again, ${userState.name || 'Friend'}! 🌸`}
            </h2>
            <p className="text-[11px] text-neutral-400 leading-relaxed">
              {language === 'es'
                ? `¿Cómo te sientes hoy, ${userState.name || 'Amiga'}? Hoy preparé una experiencia especial para ti.`
                : `How are you feeling today, ${userState.name || 'Friend'}? Today I prepared a special experience for you.`}
            </p>
          </div>

          {/* XP Progress Bar */}
          <div className="space-y-1 mt-4">
            <div className="flex justify-between text-[10px] font-black text-neutral-400 uppercase tracking-wider">
              <span>{userState.xp} / 500 XP</span>
              <span className="text-rose-500">{language === 'es' ? 'Nivel' : 'Level'} {userState.level}</span>
            </div>
            <div className="w-full h-2 bg-neutral-200/50 rounded-full overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${Math.min(100, (userState.xp % 500) / 5)}%` }}
                className="h-full bg-gradient-to-r from-rose-500 to-amber-400"
              />
            </div>
          </div>
        </div>

        {/* Card 2: Streak & Accompanying Statistics */}
        <div className={`p-5 rounded-3xl border flex flex-col justify-between shadow-md relative overflow-hidden ${
          currentTheme === 'dark' 
            ? 'bg-neutral-900 border-neutral-850 text-white' 
            : 'bg-white border-rose-100/50 text-neutral-800'
        }`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <Flame className="w-5 h-5 text-rose-500 animate-pulse" />
              <span className="text-xs font-black text-neutral-800 dark:text-white">
                {userState.streak} {language === 'es' ? 'Días' : 'Days'}
              </span>
            </div>
            <span className="text-[9px] font-black text-rose-400 bg-rose-500/10 px-2.5 py-0.5 rounded-full uppercase tracking-wider">
              {language === 'es' ? 'Racha' : 'Streak'}
            </span>
          </div>

          <div className="border-t border-rose-100/10 my-3" />

          {/* Detailed stats requested: Fecha de inicio, Última visita, Actividades realizadas, Tiempo de bienestar */}
          <div className="space-y-2 text-[11px]">
            <div className="flex justify-between text-neutral-400">
              <span>{language === 'es' ? '📅 Registro:' : '📅 Registered:'}</span>
              <span className="font-bold text-neutral-600 dark:text-neutral-300">
                {userState.startDate || new Date().toISOString().split('T')[0]}
              </span>
            </div>
            <div className="flex justify-between text-neutral-400">
              <span>{language === 'es' ? '⏱️ Bienestar:' : '⏱️ Wellness:'}</span>
              <span className="font-bold text-rose-500">
                {userState.totalWellnessMinutes || 10} min
              </span>
            </div>
            <div className="flex justify-between text-neutral-400">
              <span>{language === 'es' ? '⭐ Actividades:' : '⭐ Activities:'}</span>
              <span className="font-bold text-neutral-600 dark:text-neutral-300">
                {userState.activitiesCount || 2}
              </span>
            </div>
            <div className="flex justify-between text-neutral-400">
              <span>{language === 'es' ? '🌸 Acompañamiento:' : '🌸 Path Days:'}</span>
              <span className="font-bold text-emerald-500 font-sans">
                {userState.daysAcompanamiento || 1} {language === 'es' ? 'Días' : 'Days'}
              </span>
            </div>
          </div>
        </div>
      </div>

      <AnimatePresence mode="wait">
        {!selectedMood ? (
          /* SECTION 1: HOW DO YOU FEEL today OPTIONS GRID */
          <motion.div
            key="mood-selector"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="space-y-6"
          >
            {/* Cápsula de Sabiduría Premium */}
            <div className={`p-5 rounded-3xl border relative overflow-hidden bg-gradient-to-tr from-amber-500/5 via-rose-500/5 to-indigo-500/5 ${
              currentTheme === 'dark' ? 'bg-neutral-900/60 border-neutral-850' : 'bg-white border-rose-100/40'
            }`}>
              <div className="flex items-center justify-between mb-2.5">
                <span className="text-[10px] uppercase font-black tracking-widest text-rose-400 flex items-center gap-1.5">
                  ✨ {language === 'es' ? 'Pensamiento Semilla Diario' : 'Daily Seed Thought'}
                </span>
                <span className="text-[9px] bg-rose-500/10 text-rose-500 px-2 py-0.5 rounded-full font-black uppercase tracking-wider">
                  PREMIUM
                </span>
              </div>
              <p className={`text-xs italic leading-relaxed font-semibold ${currentTheme === 'dark' ? 'text-neutral-300' : 'text-neutral-700'}`}>
                {language === 'es'
                  ? '"No tienes que sanar a un ritmo que deje de respetarte. El tiempo de tu florecimiento es tuyo y de nadie más. Abraza tu vulnerabilidad hoy."'
                  : '"You do not have to heal at a pace that stops respecting you. The time of your blossoming is yours and no one else\'s. Embrace your vulnerability today."'}
              </p>
              <p className="text-[9px] text-neutral-400 mt-2 text-right font-bold uppercase tracking-wider">
                — {language === 'es' ? 'Olivia Miller' : 'Olivia Miller'}
              </p>
            </div>

            {/* DYNAMIC TEMPORAL EVENT BENTO CARD */}
            {currentEvent && (
              <motion.div
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                className={`p-6 rounded-3xl text-white shadow-lg relative overflow-hidden bg-gradient-to-br ${currentEvent.bgGradient}`}
              >
                {/* Decorative absolute element */}
                <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full blur-2xl transform translate-x-8 -translate-y-8" />
                
                <div className="flex items-center gap-2 mb-3">
                  <span className="text-[10px] bg-white/20 text-white font-black uppercase tracking-wider px-2.5 py-1 rounded-full backdrop-blur-sm">
                    {currentEvent.badge}
                  </span>
                  <span className="text-[10px] bg-yellow-400 text-neutral-900 font-bold px-2 py-0.5 rounded-full">
                    Special Event
                  </span>
                </div>

                <h3 className="text-xl font-bold tracking-tight mb-1 flex items-center gap-2">
                  <span className="text-xl">{currentEvent.icon}</span>
                  {currentEvent.title}
                </h3>
                <p className="text-xs text-white/90 leading-relaxed mb-4">
                  {currentEvent.subtitle}
                </p>

                {/* Interactive CBT question of the day */}
                <div className="p-4 rounded-2xl bg-white/10 backdrop-blur-md border border-white/15 space-y-3">
                  <p className="text-xs font-bold leading-snug">
                    💭 {currentEvent.cbtPrompt}
                  </p>
                  
                  <AnimatePresence mode="wait">
                    {!temporalCompleted ? (
                      <motion.div key="input-form" className="space-y-2">
                        <input
                          type="text"
                          value={temporalAnswer}
                          onChange={(e) => setTemporalAnswer(e.target.value)}
                          placeholder={language === 'es' ? 'Escribe tu respuesta aquí...' : 'Write your answer here...'}
                          className="w-full p-3 text-xs bg-white/10 border border-white/20 rounded-xl text-white placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-white/50"
                        />
                        <button
                          onClick={() => {
                            if (!temporalAnswer.trim()) return;
                            setTemporalCompleted(true);
                            onGainXP(40);
                            audioSynth.playBell(587.33); // D5 chime
                          }}
                          disabled={!temporalAnswer.trim()}
                          className="w-full py-2 bg-white text-neutral-900 font-bold rounded-xl text-xs shadow-md transition-all active:scale-95 hover:bg-neutral-50 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
                        >
                          {language === 'es' ? 'Responder y ganar +40 XP' : 'Answer & gain +40 XP'}
                        </button>
                      </motion.div>
                    ) : (
                      <motion.div
                        key="completed-msg"
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="text-center py-2 space-y-1.5"
                      >
                        <div className="flex items-center justify-center gap-1.5 text-xs font-bold text-yellow-300">
                          <CheckCircle className="w-4 h-4 fill-yellow-300/20" />
                          <span>{language === 'es' ? '¡Ejercicio completado!' : 'Exercise completed!'}</span>
                        </div>
                        <p className="text-[11px] text-white/80 italic leading-relaxed">
                          "{temporalAnswer}"
                        </p>
                        <p className="text-[10px] text-yellow-200 font-semibold uppercase">
                          +40 XP {language === 'es' ? 'Ganados' : 'Earned'}
                        </p>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </motion.div>
            )}

            <div className="text-center py-2">
              <h3 className={`text-lg md:text-xl font-bold tracking-tight ${currentTheme === 'dark' ? 'text-white' : 'text-neutral-800'}`}>
                {language === 'es' ? `¿Cómo te sientes hoy, ${userState.name || 'Amiga'}? 🌸` : `How do you feel today, ${userState.name || 'Friend'}? 🌸`}
              </h3>
              <p className="text-xs text-neutral-400 mt-1">
                {language === 'es' 
                  ? 'Cada respuesta abre un camino terapéutico diferente para el día.' 
                  : 'Each answer opens up a completely unique therapeutic path for the day.'}
              </p>
            </div>

            {/* Grid of Emotions */}
            <div className="grid grid-cols-3 md:grid-cols-4 gap-3">
              {moodOptions.map((opt) => (
                <motion.button
                  key={opt.value}
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.97 }}
                  onClick={() => handleMoodSelect(opt.value)}
                  className={`p-4 rounded-3xl border flex flex-col items-center justify-center text-center gap-1.5 transition-all duration-300 shadow-sm hover:shadow-md cursor-pointer ${
                    currentTheme === 'dark'
                      ? 'bg-neutral-900/60 border-neutral-850 hover:border-rose-400'
                      : 'bg-white border-rose-100/30 hover:border-rose-300'
                  }`}
                >
                  <span className="text-2xl">{opt.icon}</span>
                  <span className={`text-xs font-semibold tracking-tight ${currentTheme === 'dark' ? 'text-neutral-200' : 'text-neutral-700'}`}>
                    {opt.label}
                  </span>
                </motion.button>
              ))}
            </div>

            {/* WISDOM CARDS DECK (TARJETAS EMOCIONALES) */}
            <div className="space-y-3 pt-4">
              <h4 className={`text-xs font-bold uppercase tracking-wider ${currentTheme === 'dark' ? 'text-neutral-400' : 'text-neutral-500'} flex items-center gap-1.5`}>
                <Layers className="w-4 h-4 text-rose-400" />
                {language === 'es' ? 'Tarjetas Emocionales Diarias' : 'Daily Emotional Cards'}
              </h4>
              <p className="text-[11px] text-neutral-400">
                {language === 'es' ? 'Haz clic para voltear una tarjeta de sabiduría y conectar contigo.' : 'Click to flip a wisdom card and connect with yourself.'}
              </p>
              
              <div className="grid grid-cols-3 gap-3">
                {[
                  {
                    title: language === 'es' ? '🌸 Mi Cuerpo' : '🌸 My Body',
                    content: language === 'es' ? 'Hoy coloco mi mano en el pecho y me permito respirar sin prisa. Mi cuerpo no es un templo de productividad, es mi hogar.' : 'Today I place my hand on my chest and allow myself to breathe without rush. My body is not a temple of productivity, it is my home.',
                    grad: 'from-pink-100 to-rose-200 text-rose-900'
                  },
                  {
                    title: language === 'es' ? '🛡️ Mi Límite' : '🛡️ My Boundary',
                    content: language === 'es' ? 'No tengo que dar explicaciones detalladas de por qué me retiro de donde me duele. Un "no" claro es suficiente para protegerme.' : 'I do not have to give detailed explanations of why I withdraw from where it hurts. A clear "no" is enough to protect myself.',
                    grad: 'from-blue-100 to-indigo-200 text-indigo-900'
                  },
                  {
                    title: language === 'es' ? '✨ Mi Futuro' : '✨ My Future',
                    content: language === 'es' ? 'La persona que seré mañana agradecerá profundamente la valentía y el límite incómodo que decido poner hoy.' : 'The person I will be tomorrow will deeply appreciate the courage and the uncomfortable boundary I choose to set today.',
                    grad: 'from-amber-100 to-yellow-200 text-amber-900'
                  }
                ].map((card, idx) => (
                  <motion.div
                    key={idx}
                    whileHover={{ scale: 1.02, y: -4 }}
                    onClick={() => {
                      setRevealedCardIndex(revealedCardIndex === idx ? null : idx);
                      audioSynth.playBell(330 + idx * 50); // custom tune
                    }}
                    className={`p-4 rounded-2xl border cursor-pointer min-h-[120px] flex flex-col justify-between transition-all shadow-sm ${
                      revealedCardIndex === idx 
                        ? 'bg-gradient-to-br ' + card.grad + ' border-transparent' 
                        : currentTheme === 'dark' 
                          ? 'bg-neutral-900/40 border-neutral-800 text-neutral-300 hover:border-neutral-700' 
                          : 'bg-white border-neutral-100 text-neutral-700 hover:border-rose-200'
                    }`}
                  >
                    <span className="text-xs font-bold tracking-tight block">
                      {card.title}
                    </span>
                    
                    <div className="mt-2 flex-1 flex items-center justify-center">
                      <AnimatePresence mode="wait">
                        {revealedCardIndex === idx ? (
                          <motion.p
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            className="text-[10px] leading-relaxed font-medium"
                          >
                            {card.content}
                          </motion.p>
                        ) : (
                          <motion.span
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            className="text-[10px] text-neutral-400 font-bold uppercase tracking-widest text-center"
                          >
                            {language === 'es' ? 'Ver' : 'Reveal'}
                          </motion.span>
                        )}
                      </AnimatePresence>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>
        ) : (
          /* SECTION 2: THE CUSTOM EMOTIONAL PATH GENERATOR */
          <motion.div
            key="emotional-path"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="space-y-5"
          >
            {/* Nav Back Header */}
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold text-rose-400 uppercase tracking-widest bg-rose-50/50 px-3 py-1 rounded-full">
                {language === 'es' ? 'Camino de:' : 'Path for:'} {moodOptions.find(o => o.value === selectedMood)?.label}
              </span>
              <button
                onClick={() => {
                  setSelectedMood(null);
                  setDailyData(null);
                  setJournalSaved(false);
                  setJournalNote('');
                  setQuizAnsweredIndex(null);
                  setShowQuizExplanation(false);
                  setMindgameCompleted(false);
                }}
                className="text-xs font-semibold text-neutral-400 hover:text-neutral-600 transition-colors"
              >
                {language === 'es' ? 'Cambiar Emoción' : 'Change Emotion'}
              </button>
            </div>

            {/* LOADER SPIN FOR GEMINI GENERATION */}
            {loadingDaily && (
              <div className="text-center py-12 flex flex-col items-center gap-3">
                <RefreshCw className="w-8 h-8 text-rose-400 animate-spin" />
                <p className="text-xs text-neutral-400 tracking-wider font-semibold animate-pulse uppercase">
                  {language === 'es' ? 'Diseñando tu recorrido emocional...' : 'Crafting your emotional journey...'}
                </p>
              </div>
            )}

            {/* DYNAMIC PATH CONTENT */}
            {dailyData && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="space-y-5"
              >
                {/* 1. Dynamic Therapeutic Story Card based on Mi Psicóloga Me Dijo */}
                {storyData && (
                  <motion.div
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4 }}
                    className="space-y-5"
                  >
                    <div className={`p-6 rounded-3xl border shadow-sm relative overflow-hidden ${
                      currentTheme === 'dark' 
                        ? 'bg-neutral-900/60 border-neutral-850' 
                        : 'bg-gradient-to-b from-rose-50/25 to-amber-50/15 border-rose-100/50'
                    }`}>
                      <div className="flex items-center justify-between mb-4">
                        <span className="text-[10px] font-bold text-rose-500 uppercase tracking-widest bg-rose-100/40 px-3 py-1 rounded-full flex items-center gap-1.5">
                          <BookOpen className="w-3.5 h-3.5" />
                          {language === 'es' ? 'Historia del Día' : 'Daily Story'}
                        </span>
                        <span className="text-[10px] text-neutral-400 font-semibold tracking-wider flex items-center gap-1">
                          📖 {language === 'es' ? 'Lectura de 2 min' : '2 min read'}
                        </span>
                      </div>

                      <h2 className={`text-2xl font-black tracking-tight mb-4 leading-tight ${currentTheme === 'dark' ? 'text-white' : 'text-neutral-800'}`}>
                        {storyData.titulo}
                      </h2>

                      <div className={`text-sm md:text-base leading-relaxed space-y-4 whitespace-pre-line font-medium ${
                        currentTheme === 'dark' ? 'text-neutral-200' : 'text-neutral-700'
                      }`}>
                        {storyData.historia}
                      </div>

                      <div className="mt-6 p-4 rounded-2xl bg-rose-500/5 border border-rose-200/10 text-center italic relative">
                        <span className="absolute -top-3 left-4 text-3xl text-rose-300 font-serif font-black leading-none pointer-events-none">“</span>
                        <p className={`text-xs md:text-sm font-semibold tracking-tight ${currentTheme === 'dark' ? 'text-rose-300' : 'text-rose-700'}`}>
                          {storyData.fraseInspiradora}
                        </p>
                        <span className="absolute -bottom-5 right-4 text-3xl text-rose-300 font-serif font-black leading-none pointer-events-none">”</span>
                      </div>

                      <div className="mt-8 pt-4 border-t border-rose-100/20 flex flex-wrap gap-2 items-center justify-between">
                        <button
                          onClick={handleToggleFavorite}
                          className={`px-4 py-2 rounded-full border text-xs font-bold transition-all flex items-center gap-1.5 active:scale-95 cursor-pointer ${
                            isFavorite
                              ? 'bg-rose-500 border-rose-500 text-white shadow-md shadow-rose-500/20'
                              : currentTheme === 'dark'
                                ? 'bg-neutral-800 border-neutral-700 text-neutral-300 hover:bg-neutral-700'
                                : 'bg-white border-rose-200 text-rose-500 hover:bg-rose-50'
                          }`}
                        >
                          <Heart className={`w-3.5 h-3.5 ${isFavorite ? 'fill-current' : ''}`} />
                          {isFavorite
                            ? (language === 'es' ? 'Guardada en Favoritos 💖' : 'Saved in Favorites 💖')
                            : (language === 'es' ? 'Guardar como Favorita' : 'Save as Favorite')}
                        </button>

                        <button
                          onClick={handleShareQuote}
                          className={`px-4 py-2 rounded-full border text-xs font-bold transition-all flex items-center gap-1.5 active:scale-95 cursor-pointer ${
                            sharedSuccess
                              ? 'bg-emerald-500 border-emerald-500 text-white shadow-md shadow-emerald-500/20'
                              : currentTheme === 'dark'
                                ? 'bg-neutral-800 border-neutral-700 text-neutral-300 hover:bg-neutral-700'
                                : 'bg-white border-amber-200 text-amber-500 hover:bg-amber-50'
                          }`}
                        >
                          <Sparkles className="w-3.5 h-3.5" />
                          {sharedSuccess
                            ? (language === 'es' ? '¡Copiada con éxito! ✨' : 'Copied with success! ✨')
                            : (language === 'es' ? 'Compartir Frase Inspiradora' : 'Share Inspiring Quote')}
                        </button>
                      </div>

                      {!storyRead && (
                        <div className="mt-8">
                          <button
                            onClick={handleMarkAsRead}
                            className="w-full py-4 bg-gradient-to-r from-rose-500 to-coral-500 hover:opacity-95 text-white font-black rounded-2xl text-xs uppercase tracking-widest transition-all active:scale-98 shadow-lg shadow-rose-500/20 cursor-pointer flex items-center justify-center gap-2 animate-pulse"
                          >
                            📖 {language === 'es' ? 'He terminado de leer. Iniciar integración terapéutica' : 'I have finished reading. Start therapeutic integration'}
                          </button>
                        </div>
                      )}
                    </div>

                    {/* Story Integration Panel */}
                    <AnimatePresence>
                      {storyRead && (
                        <motion.div
                          initial={{ opacity: 0, y: 15 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="space-y-5"
                        >
                          {/* A. Pregunta de Reflexión y Caja de Escritura */}
                          <div className={`p-6 rounded-3xl border shadow-sm ${
                            currentTheme === 'dark' ? 'bg-neutral-900/60 border-neutral-850' : 'bg-white border-rose-100/50'
                          }`}>
                            <div className="flex items-center justify-between mb-3">
                              <h3 className="font-semibold text-xs text-rose-500 uppercase tracking-widest flex items-center gap-1.5">
                                <PenTool className="w-4 h-4" />
                                {language === 'es' ? 'Reflexión del Día' : 'Daily Reflection'}
                              </h3>
                            </div>

                            <p className={`text-sm leading-relaxed mb-4 font-bold italic ${currentTheme === 'dark' ? 'text-neutral-200' : 'text-neutral-700'}`}>
                              "{storyData.preguntaReflexion}"
                            </p>

                            <textarea
                              value={userReflectionText}
                              onChange={(e) => setUserReflectionText(e.target.value)}
                              disabled={reflectionSaved}
                              placeholder={
                                language === 'es'
                                  ? 'Escribe aquí tu sentir o reflexión personal sobre esta historia...'
                                  : 'Write your feeling or personal reflection on this story here...'
                              }
                              rows={3}
                              className={`w-full p-4 rounded-2xl border text-sm focus:outline-none focus:ring-2 focus:ring-rose-300 resize-none transition-all duration-300 ${
                                currentTheme === 'dark'
                                  ? 'bg-neutral-950 border-neutral-800 text-white placeholder-neutral-500 focus:ring-rose-500'
                                  : 'bg-neutral-50/50 border-rose-100/50 text-neutral-800 placeholder-neutral-400'
                              }`}
                            />

                            <div className="mt-3 flex justify-end">
                              <button
                                onClick={handleSaveStoryReflection}
                                disabled={!userReflectionText.trim() || reflectionSaved}
                                className={`px-5 py-2.5 rounded-full text-xs font-black tracking-wider uppercase transition-all active:scale-95 cursor-pointer ${
                                  reflectionSaved
                                    ? 'bg-emerald-100 border border-emerald-205 text-emerald-700 opacity-80 cursor-default font-bold'
                                    : 'bg-rose-500 text-white hover:bg-rose-600 shadow-md shadow-rose-500/10'
                                }`}
                              >
                                {reflectionSaved
                                  ? (language === 'es' ? '✓ Reflexión Guardada' : '✓ Reflection Saved')
                                  : (language === 'es' ? 'Guardar mi Reflexión' : 'Save my Reflection')}
                              </button>
                            </div>
                          </div>

                          {/* B. Ejercicio Práctico */}
                          <div className={`p-6 rounded-3xl border shadow-sm ${
                            currentTheme === 'dark' ? 'bg-neutral-900/60 border-neutral-850' : 'bg-white border-rose-100/50'
                          }`}>
                            <h3 className="font-semibold text-xs text-amber-500 uppercase tracking-widest flex items-center gap-1.5 mb-3">
                              <HeartHandshake className="w-4 h-4" />
                              {language === 'es' ? 'Ejercicio Práctico' : 'Practical Exercise'}
                            </h3>
                            <h4 className={`text-base font-bold mb-1.5 ${currentTheme === 'dark' ? 'text-white' : 'text-neutral-800'}`}>
                              {storyData.ejercicioPractico.titulo}
                            </h4>
                            <p className={`text-xs md:text-sm leading-relaxed ${currentTheme === 'dark' ? 'text-neutral-300' : 'text-neutral-600'}`}>
                              {storyData.ejercicioPractico.descripcion}
                            </p>
                          </div>

                          {/* C. Reto Personalizado */}
                          <div className={`p-6 rounded-3xl border shadow-sm ${
                            currentTheme === 'dark' ? 'bg-neutral-900/60 border-neutral-850' : 'bg-white border-rose-100/50'
                          }`}>
                            <h3 className="font-semibold text-xs text-rose-500 uppercase tracking-widest flex items-center gap-1.5 mb-3">
                              <Layers className="w-4 h-4" />
                              {language === 'es' ? 'Reto Personalizado' : 'Personalized Challenge'}
                            </h3>
                            <p className={`text-sm font-extrabold leading-tight ${currentTheme === 'dark' ? 'text-rose-300' : 'text-rose-700'} mb-2`}>
                              {storyData.retoPersonalizado}
                            </p>
                            <p className="text-[10px] text-neutral-400">
                              {language === 'es' ? 'Un reto de acción consciente diseñado hoy para ti.' : 'A mindful action challenge crafted for you today.'}
                            </p>
                          </div>

                          {/* D. Minijuego Relacionado */}
                          <div className={`p-6 rounded-3xl border shadow-sm relative overflow-hidden bg-gradient-to-tr from-indigo-500/5 to-rose-500/5 ${
                            currentTheme === 'dark' ? 'bg-neutral-900/60 border-neutral-850' : 'bg-white border-rose-100/50'
                          }`}>
                            <div className="flex items-center justify-between mb-2">
                              <h3 className="font-semibold text-xs text-indigo-500 uppercase tracking-widest flex items-center gap-1.5">
                                <Gamepad2 className="w-4 h-4" />
                                {language === 'es' ? 'Minijuego Relacionado' : 'Related Minigame'}
                              </h3>
                              <span className="text-[9px] bg-indigo-100 text-indigo-700 px-2 py-0.5 rounded-full font-bold">
                                +15 XP
                              </span>
                            </div>

                            <h4 className={`text-base font-bold mb-1.5 ${currentTheme === 'dark' ? 'text-white' : 'text-neutral-800'}`}>
                              {storyData.minijuegoRelacionado.titulo}
                            </h4>
                            <p className={`text-xs leading-relaxed mb-4 ${currentTheme === 'dark' ? 'text-neutral-300' : 'text-neutral-600'}`}>
                              {storyData.minijuegoRelacionado.descripcion}
                            </p>

                            {!minijameCompleted ? (
                              <div className="flex flex-col items-center justify-center p-6 border border-dashed border-rose-200/55 rounded-2xl bg-rose-50/5 mb-4">
                                <motion.div
                                  animate={{ scale: [1, 1.4, 1] }}
                                  transition={{ repeat: Infinity, duration: 4, ease: 'easeInOut' }}
                                  className="w-16 h-16 rounded-full bg-rose-400/40 flex items-center justify-center mb-4"
                                >
                                  <div className="w-8 h-8 rounded-full bg-rose-500" />
                                </motion.div>
                                <p className="text-[10px] text-neutral-400 text-center mb-4">
                                  {language === 'es' ? 'Inhala al expandirse, exhala al contraerse.' : 'Breathe in as it expands, out as it contracts.'}
                                </p>
                                <button
                                  onClick={handleCompleteMinijame}
                                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold rounded-xl text-xs transition-all active:scale-95 shadow-md shadow-indigo-600/10 cursor-pointer"
                                >
                                  🎮 {language === 'es' ? 'Completar Minijuego' : 'Complete Minigame'}
                                </button>
                              </div>
                            ) : (
                              <div className="flex items-center gap-2 text-emerald-500 font-bold text-xs bg-emerald-50/50 p-3 rounded-xl mb-4 border border-emerald-100">
                                <CheckCircle className="w-4 h-4" />
                                <span>{language === 'es' ? '¡Minijuego completado con éxito! +15 XP' : 'Minigame completed successfully! +15 XP'}</span>
                              </div>
                            )}
                          </div>

                          {/* E. Conversar con Olivia */}
                          <div className={`p-6 rounded-3xl border shadow-sm ${
                            currentTheme === 'dark' ? 'bg-neutral-900/60 border-neutral-850' : 'bg-white border-rose-100/50'
                          }`}>
                            <div className="flex items-center justify-between mb-3.5">
                              <h3 className="font-semibold text-xs text-rose-500 uppercase tracking-widest flex items-center gap-1.5">
                                <MessageCircle className="w-4 h-4" />
                                {language === 'es' ? 'Conversación con Olivia' : 'Chat with Olivia'}
                              </h3>
                            </div>
                            <p className={`text-xs leading-relaxed ${currentTheme === 'dark' ? 'text-neutral-300' : 'text-neutral-600'} mb-4`}>
                              {language === 'es'
                                ? 'Profundiza en la historia de hoy y platica directamente con la Psicóloga IA de lo que removió en ti.'
                                : 'Dive deeper into today\'s story and chat directly with the Psychologist AI about what it stirred in you.'}
                            </p>

                            <button
                              onClick={handleNavigateToTherapist}
                              className="w-full py-3 bg-rose-500 hover:bg-rose-600 text-white font-extrabold rounded-2xl text-xs transition-all active:scale-95 cursor-pointer flex items-center justify-center gap-2 shadow-md shadow-rose-500/10"
                            >
                              💬 {language === 'es' ? 'Conversar sobre esta Historia' : 'Chat about this Story'}
                            </button>
                          </div>

                          {/* F. Claim Recompensa y Completar Experiencia */}
                          {!overallStoryCompleted ? (
                            <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-400 to-rose-400 text-white text-center shadow-lg">
                              <span className="text-[10px] uppercase tracking-widest font-black block text-rose-50/90 mb-1">
                                {language === 'es' ? 'Recompensa de Integración Completa' : 'Full Integration Reward'}
                              </span>
                              <h4 className="text-sm font-black mb-1 flex items-center justify-center gap-1.5">
                                <Gift className="w-4 h-4" />
                                {storyData.recompensa}
                              </h4>
                              <p className="text-[11px] text-rose-50 font-bold mb-3">
                                {language === 'es' ? 'Completa la reflexión y el minijuego para reclamar +50 XP y tu medalla especial de hoy.' : 'Complete the reflection and minigame to claim +50 XP and your special badge.'}
                              </p>
                              <button
                                onClick={handleClaimFullExperience}
                                disabled={!reflectionSaved || !minijameCompleted}
                                className={`w-full py-3 font-extrabold rounded-xl text-xs uppercase tracking-wider transition-all active:scale-95 cursor-pointer shadow-md flex items-center justify-center gap-1.5 ${
                                  (!reflectionSaved || !minijameCompleted)
                                    ? 'bg-white/20 text-white/50 cursor-not-allowed'
                                    : 'bg-white text-rose-500 hover:bg-rose-50'
                                }`}
                              >
                                🌸 {language === 'es' ? 'Completar Experiencia de Hoy' : 'Complete Today\'s Experience'}
                              </button>
                            </div>
                          ) : (
                            <div className="p-5 rounded-2xl bg-emerald-500 text-white text-center shadow-lg relative overflow-hidden">
                              <div className="absolute top-0 right-0 p-8 opacity-10 font-serif text-8xl leading-none font-bold select-none pointer-events-none">✓</div>
                              <h4 className="text-sm font-black mb-1 flex items-center justify-center gap-1.5">
                                🎉 {language === 'es' ? '¡Experiencia Completada!' : 'Experience Completed!'}
                              </h4>
                              <p className="text-xs text-emerald-50 font-medium">
                                {language === 'es'
                                  ? `Has ganado +50 XP y desbloqueado con éxito la medalla especial "${storyData.recompensa}". ¡Sigue eligiéndote!`
                                  : `You have earned +50 XP and unlocked the badge "${storyData.recompensa}". Keep choosing yourself!`}
                              </p>
                            </div>
                          )}
                        </motion.div>
                      )}
                    </AnimatePresence>

                    <div className="py-6 border-b border-rose-100/10" />
                  </motion.div>
                )}

                {/* 1. Daily Reflection Card */}
                <div className={`p-5 rounded-3xl border shadow-sm relative overflow-hidden ${
                  currentTheme === 'dark' ? 'bg-neutral-900/60 border-neutral-850' : 'bg-white border-rose-100/50'
                }`}>
                  <h3 className="font-semibold text-xs text-rose-400 uppercase tracking-widest flex items-center gap-1.5 mb-2.5">
                    <Star className="w-4 h-4 fill-rose-100" />
                    {language === 'es' ? 'Tu Reflexión de Hoy' : 'Your Reflection Today'}
                  </h3>
                  <p className={`text-sm md:text-base leading-relaxed italic ${currentTheme === 'dark' ? 'text-neutral-200' : 'text-neutral-700'}`}>
                    "{dailyData.reflection}"
                  </p>
                  <p className="text-[10px] text-neutral-400 font-semibold tracking-wider text-right mt-3 uppercase">
                    — Olivia Miller
                  </p>
                </div>

                {/* 2. CBT Interactive Card: Daily Challenge / Reto */}
                <div className={`p-5 rounded-3xl border shadow-sm ${
                  currentTheme === 'dark' ? 'bg-neutral-900/60 border-neutral-850' : 'bg-white border-rose-100/50'
                }`}>
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-semibold text-xs text-amber-500 uppercase tracking-widest flex items-center gap-1.5">
                      <Brain className="w-4 h-4" />
                      {language === 'es' ? 'Misión de hoy' : 'Today\'s Mission'}
                    </h3>
                    <span className="text-[9px] bg-amber-50 text-amber-600 px-2 py-0.5 rounded-full font-bold">
                      +30 XP
                    </span>
                  </div>
                  <p className={`text-sm font-semibold tracking-tight ${currentTheme === 'dark' ? 'text-white' : 'text-neutral-800'}`}>
                    {dailyData.reto}
                  </p>
                  <p className="text-xs text-neutral-400 mt-1 leading-relaxed">
                    {language === 'es' 
                      ? 'Llévalo a cabo con calma. Te ayudará a reafirmar tus límites y elegir tu paz.'
                      : 'Carry it out with peace. It will help assert your boundaries and choose your peace.'}
                  </p>
                </div>

                {/* 3. Emotional Affirmation Banner */}
                <div className="p-4 rounded-2xl bg-gradient-to-r from-rose-400 to-amber-300 text-white text-center shadow-md">
                  <span className="text-[9px] uppercase tracking-widest font-black block text-rose-50/80 mb-1">
                    {language === 'es' ? 'Afirmación Sanadora' : 'Healing Affirmation'}
                  </span>
                  <p className="text-xs md:text-sm font-bold leading-relaxed max-w-md mx-auto">
                    "{dailyData.afirmacion}"
                  </p>
                </div>

                {/* 3.1 ZEN MIND GAME */}
                {dailyData.juego && (
                  <div className={`p-5 rounded-3xl border shadow-sm relative overflow-hidden bg-gradient-to-tr from-indigo-500/5 to-rose-500/5 ${
                    currentTheme === 'dark' ? 'bg-neutral-900/60 border-neutral-850' : 'bg-white border-rose-100/50'
                  }`}>
                    <div className="flex items-center justify-between mb-2.5">
                      <h3 className="font-semibold text-xs text-indigo-500 uppercase tracking-widest flex items-center gap-1.5">
                        <Gamepad2 className="w-4 h-4" />
                        {language === 'es' ? 'Gimnasio Emocional: Mind Games' : 'Emotional Gym: Mind Games'}
                      </h3>
                      <span className="text-[9px] bg-indigo-100 text-indigo-700 px-2 py-0.5 rounded-full font-bold">
                        Premium
                      </span>
                    </div>
                    <p className={`text-xs leading-relaxed ${currentTheme === 'dark' ? 'text-neutral-300' : 'text-neutral-600'} mb-3`}>
                      {language === 'es'
                        ? 'Desafía tu ansiedad, estrés o tristeza con nuestros juegos interactivos calibrados clínicamente para restaurar tu paz mental.'
                        : 'Soothe your anxiety, stress or sadness with our interactive games clinically calibrated to restore peace of mind.'}
                    </p>
                    
                    <button
                      onClick={onOpenMindGames}
                      className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold rounded-2xl text-xs transition-all active:scale-95 cursor-pointer shadow-md shadow-indigo-600/10 flex items-center justify-center gap-2"
                    >
                      🎮 {language === 'es' ? 'Entrar a Jugar Mind Games' : 'Play Mind Games'}
                    </button>
                  </div>
                )}

                {/* 3.2 COGNITIVE QUIZ OF THE DAY */}
                {dailyData.quiz && (
                  <div className={`p-5 rounded-3xl border shadow-sm ${
                    currentTheme === 'dark' ? 'bg-neutral-900/60 border-neutral-850' : 'bg-white border-rose-100/50'
                  }`}>
                    <div className="flex items-center justify-between mb-2.5">
                      <h3 className="font-semibold text-xs text-emerald-500 uppercase tracking-widest flex items-center gap-1.5">
                        <HelpCircle className="w-4 h-4" />
                        {language === 'es' ? 'Desafío Cognitivo Diario' : 'Daily Cognitive Challenge'}
                      </h3>
                      <span className="text-[9px] bg-emerald-50 text-emerald-600 px-2 py-0.5 rounded-full font-bold">
                        +50 XP
                      </span>
                    </div>
                    
                    <p className={`text-xs font-bold leading-relaxed ${currentTheme === 'dark' ? 'text-white' : 'text-neutral-800'} mb-3`}>
                      {dailyData.quiz.pregunta}
                    </p>

                    <div className="space-y-2">
                      {dailyData.quiz.opciones.map((opc: string, idx: number) => {
                        const isSelected = quizAnsweredIndex === idx;
                        const isCorrect = idx === dailyData.quiz.correcta;
                        let btnStyle = currentTheme === 'dark'
                          ? 'bg-neutral-950 border-neutral-800 text-neutral-300 hover:border-neutral-700'
                          : 'bg-rose-50/10 border-rose-100/20 text-neutral-700 hover:bg-rose-50/20';

                        if (quizAnsweredIndex !== null) {
                          if (isCorrect) {
                            btnStyle = 'bg-emerald-500/10 border-emerald-500 text-emerald-700 font-semibold';
                          } else if (isSelected) {
                            btnStyle = 'bg-red-500/10 border-red-500 text-red-700 font-semibold';
                          } else {
                            btnStyle = 'opacity-40 border-neutral-200';
                          }
                        }

                        return (
                          <button
                            key={idx}
                            disabled={quizAnsweredIndex !== null}
                            onClick={() => {
                              setQuizAnsweredIndex(idx);
                              setShowQuizExplanation(true);
                              if (idx === dailyData.quiz.correcta) {
                                onGainXP(50);
                                audioSynth.playBell(523.25); // pleasant chime
                              } else {
                                audioSynth.playBell(220.00); // lower feedback tone
                              }
                            }}
                            className={`w-full p-3 text-[11px] text-left rounded-xl border transition-all active:scale-98 cursor-pointer ${btnStyle}`}
                          >
                            {opc}
                          </button>
                        );
                      })}
                    </div>

                    <AnimatePresence>
                      {showQuizExplanation && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          className={`mt-3 p-3 rounded-2xl border text-[10px] leading-relaxed space-y-1 ${
                            currentTheme === 'dark'
                              ? 'bg-neutral-950 border-neutral-800 text-neutral-400'
                              : 'bg-neutral-50 border-neutral-100 text-neutral-500'
                          }`}
                        >
                          <span className={`font-bold uppercase tracking-wider block ${
                            quizAnsweredIndex === dailyData.quiz.correcta ? 'text-emerald-500' : 'text-neutral-700'
                          }`}>
                            {quizAnsweredIndex === dailyData.quiz.correcta 
                              ? (language === 'es' ? '¡Excelente elección!' : 'Excellent choice!') 
                              : (language === 'es' ? 'Olivia te aconseja:' : 'Olivia advising you:')}
                          </span>
                          <p>{dailyData.quiz.explicacion}</p>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                )}

                {/* 4. DIARIO EMOCIONAL FORM */}
                <div className={`p-5 rounded-3xl border shadow-sm ${
                  currentTheme === 'dark' ? 'bg-neutral-900/60 border-neutral-850' : 'bg-white border-rose-100/50'
                }`}>
                  <h3 className="font-semibold text-xs text-purple-400 uppercase tracking-widest flex items-center gap-1.5 mb-2.5">
                    <PenTool className="w-4 h-4" />
                    {language === 'es' ? 'Escribe en tu Diario' : 'Write in your Journal'}
                  </h3>
                  <p className="text-xs text-neutral-400 mb-4 leading-relaxed">
                    {dailyData.mision}
                  </p>

                  <AnimatePresence mode="wait">
                    {!journalSaved ? (
                      <motion.div key="form" className="space-y-3">
                        <textarea
                          value={journalNote}
                          onChange={(e) => setJournalNote(e.target.value)}
                          placeholder={language === 'es' ? 'Escribe tus pensamientos libremente aquí...' : 'Write your honest thoughts here...'}
                          className={`w-full p-4 text-xs rounded-2xl border resize-none h-24 focus:outline-none focus:ring-2 focus:ring-rose-300 ${
                            currentTheme === 'dark'
                              ? 'bg-neutral-950 border-neutral-800 text-white'
                              : 'bg-rose-50/10 border-rose-100/40 text-neutral-800'
                          }`}
                        />
                        <div className="grid grid-cols-2 gap-2">
                          <input
                            type="text"
                            placeholder={language === 'es' ? 'Hoy agradezco por...' : 'Today I am grateful for...'}
                            value={journalGratitude}
                            onChange={(e) => setJournalGratitude(e.target.value)}
                            className={`p-3 text-xs rounded-xl border focus:outline-none focus:ring-2 focus:ring-rose-300 ${
                              currentTheme === 'dark'
                                ? 'bg-neutral-950 border-neutral-800 text-white'
                                : 'bg-white border-rose-100/30 text-neutral-800'
                            }`}
                          />
                          <input
                            type="text"
                            placeholder={language === 'es' ? 'Mi logro de hoy fue...' : 'My accomplishment was...'}
                            value={journalLesson}
                            onChange={(e) => setJournalLesson(e.target.value)}
                            className={`p-3 text-xs rounded-xl border focus:outline-none focus:ring-2 focus:ring-rose-300 ${
                              currentTheme === 'dark'
                                ? 'bg-neutral-950 border-neutral-800 text-white'
                                : 'bg-white border-rose-100/30 text-neutral-800'
                            }`}
                          />
                        </div>
                        <button
                          onClick={handleSaveJournal}
                          disabled={!journalNote.trim()}
                          className={`w-full py-3.5 rounded-full text-xs font-semibold tracking-wide bg-gradient-to-r from-rose-400 to-amber-300 text-white shadow-md active:scale-95 transition-all ${
                            !journalNote.trim() && 'opacity-50 cursor-not-allowed'
                          }`}
                        >
                          {language === 'es' ? 'Guardar en mi Diario (+50 XP)' : 'Save to my Journal (+50 XP)'}
                        </button>
                      </motion.div>
                    ) : (
                      <motion.div
                        key="saved"
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="text-center py-4 flex flex-col items-center gap-2"
                      >
                        <CheckCircle className="w-10 h-10 text-emerald-500 fill-emerald-50" />
                        <span className={`text-xs font-bold ${currentTheme === 'dark' ? 'text-white' : 'text-neutral-800'}`}>
                          {language === 'es' 
                            ? `¡Excelente trabajo, ${userState.name || ''}! Estoy orgullosa de tu progreso. 🌸` 
                            : `Excellent job, ${userState.name || ''}! I am proud of your progress. 🌸`}
                        </span>
                        <span className="text-[10px] text-rose-400 font-semibold uppercase">
                          +50 XP {language === 'es' ? 'de Progreso' : 'Reward'}
                        </span>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                {/* 5. BONUS GAMIFIED REWARDS CHEST CARD */}
                <div className={`p-5 rounded-3xl border shadow-sm relative overflow-hidden flex items-center justify-between ${
                  chestOpened
                    ? 'bg-emerald-50/20 border-emerald-100'
                    : currentTheme === 'dark'
                      ? 'bg-neutral-900/60 border-neutral-850'
                      : 'bg-gradient-to-tr from-amber-50/40 to-rose-50/40 border-amber-100/40 shadow-inner'
                }`}>
                  <div className="space-y-1 pr-3">
                    <h4 className={`font-bold tracking-tight text-sm ${currentTheme === 'dark' ? 'text-white' : 'text-neutral-800'}`}>
                      {chestOpened ? (language === 'es' ? '¡Has abierto el cofre!' : 'Chest Opened!') : (language === 'es' ? 'Recompensa Sorpresa del Día' : 'Daily Surprise Reward')}
                    </h4>
                    <p className="text-xs text-neutral-400">
                      {chestOpened
                        ? (language === 'es' ? `Has recibido la recompensa: "${dailyData.recompensa}". +100 XP` : `You received the reward: "${dailyData.recompensa}". +100 XP`)
                        : (language === 'es' ? 'Completa tu autoevaluación de hoy para reclamar tu cofre sorpresa.' : 'Complete your daily self-check to claim your surprise chest.')}
                    </p>
                  </div>
                  <button
                    onClick={handleOpenChest}
                    className={`p-3 rounded-2xl bg-amber-100 text-amber-500 shrink-0 hover:scale-105 active:scale-95 transition-all shadow-md ${
                      chestOpened && 'opacity-50 cursor-not-allowed bg-neutral-100 text-neutral-400 shadow-none'
                    }`}
                  >
                    <Gift className="w-6 h-6" />
                  </button>
                </div>
              </motion.div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
