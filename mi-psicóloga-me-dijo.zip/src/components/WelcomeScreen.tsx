import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Heart, Sparkles } from 'lucide-react';
import { Language } from '../types';
import { audioSynth } from '../lib/audio';

interface WelcomeScreenProps {
  language: Language;
  onSaveName: (name: string) => void;
  theme: 'light' | 'dark';
}

export default function WelcomeScreen({ language, onSaveName, theme }: WelcomeScreenProps) {
  const [name, setName] = useState('');

  const isEs = language === 'es' || language === 'ca';
  const title = isEs ? '🌸 Bienvenida a Mi Psicóloga Me Dijo' : '🌸 Welcome to My Therapist Told Me';
  const subtitle = isEs 
    ? 'Antes de comenzar este camino juntas, me gustaría conocerte.' 
    : 'Before we begin this journey together, I would like to get to know you.';
  const label = isEs ? '¿Cómo te llamas?' : "What is your name?";
  const placeholder = isEs ? 'Escribe tu nombre...' : 'Enter your name...';
  const buttonText = isEs ? 'Comenzar mi camino' : 'Begin my journey';

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim()) {
      audioSynth.playBell(523.25); // pleasant chime
      onSaveName(name.trim());
    }
  };

  return (
    <div className={`fixed inset-0 z-50 flex items-center justify-center p-4 overflow-hidden ${
      theme === 'dark' ? 'bg-neutral-950 text-white' : 'bg-gradient-to-b from-rose-50/40 via-amber-50/20 to-white text-neutral-850'
    }`}>
      {/* Abstract Glowing Aura Background */}
      <div className="absolute top-1/4 left-1/4 w-80 h-80 bg-rose-400/10 rounded-full filter blur-3xl" />
      <div className="absolute bottom-1/3 right-1/4 w-96 h-96 bg-amber-300/10 rounded-full filter blur-3xl" />

      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
        className={`w-full max-w-md p-8 rounded-3xl border backdrop-blur-xl shadow-2xl relative ${
          theme === 'dark' 
            ? 'bg-neutral-900/80 border-neutral-800' 
            : 'bg-white/85 border-rose-100/60'
        }`}
      >
        <div className="absolute top-4 right-4 text-rose-400/60">
          <Sparkles className="w-5 h-5 animate-pulse" />
        </div>

        <div className="flex flex-col items-center text-center space-y-6">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: 'spring', stiffness: 200, damping: 15 }}
            className="w-14 h-14 bg-gradient-to-tr from-rose-400 to-amber-300 rounded-2xl flex items-center justify-center text-white shadow-md shadow-rose-200/20"
          >
            <Heart className="w-7 h-7 fill-rose-100" />
          </motion.div>

          <div className="space-y-2">
            <h2 className="text-3xl font-black tracking-tight">{title}</h2>
            <p className={`text-sm leading-relaxed ${theme === 'dark' ? 'text-neutral-400' : 'text-neutral-500'}`}>
              {subtitle}
            </p>
          </div>

          <form onSubmit={handleSubmit} className="w-full space-y-4 pt-2">
            <div className="text-left space-y-2">
              <label className="text-xs font-bold uppercase tracking-wider text-rose-400 block pl-1">
                {label}
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder={placeholder}
                maxLength={40}
                required
                className={`w-full px-4 py-3.5 rounded-2xl border transition-all text-sm outline-none ${
                  theme === 'dark'
                    ? 'bg-neutral-950 border-neutral-800 text-white focus:border-rose-500 focus:ring-1 focus:ring-rose-500/30'
                    : 'bg-neutral-50 border-rose-100/50 text-neutral-800 focus:bg-white focus:border-rose-400 focus:ring-1 focus:ring-rose-400/30 shadow-inner'
                }`}
              />
            </div>

            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              type="submit"
              disabled={!name.trim()}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-rose-400 to-amber-300 text-white font-black text-sm tracking-wide shadow-lg shadow-rose-400/10 active:opacity-90 transition-all cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
            >
              {buttonText}
            </motion.button>
          </form>
        </div>
      </motion.div>
    </div>
  );
}
