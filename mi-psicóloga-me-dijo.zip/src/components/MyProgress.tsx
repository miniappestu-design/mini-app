import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Award, Flame, Calendar, Sparkles, Heart, CheckCircle2, 
  Circle, Plus, Trash2, Clock, CheckSquare, BarChart3, 
  Smile, Activity, BookOpen, PenTool, Sparkle, Target
} from 'lucide-react';
import { Language, UserState, Mood } from '../types';
import { audioSynth } from '../lib/audio';

interface MyProgressProps {
  language: Language;
  userState: UserState;
  onGainXP: (amount: number) => void;
}

interface ServerProfile {
  moodHistory: { date: string; mood: Mood }[];
  conversationsCount: number;
  goals: string[];
  completedSessions: string[];
  recaidas: { date: string; note: string }[];
}

export default function MyProgress({ language, userState, onGainXP }: MyProgressProps) {
  const currentTheme = userState.theme;
  const userName = userState.name || (language === 'es' ? 'Amiga' : 'Friend');

  // Local state for interactive custom goal inputs
  const [newGoalText, setNewGoalText] = useState('');
  const [quickGratitude, setQuickGratitude] = useState('');
  
  // Loaded server therapeutic data
  const [serverProfile, setServerProfile] = useState<ServerProfile>({
    moodHistory: [],
    conversationsCount: 0,
    goals: [],
    completedSessions: [],
    recaidas: []
  });
  const [isLoadingProfile, setIsLoadingProfile] = useState(true);

  // Pre-curated default therapeutic goals based on the book "Mi Psicóloga Me Dijo"
  const defaultGoalsEs = [
    'Aprender a decir "no" sin sentir culpa',
    'Poner límites sanos a personas emocionalmente demandantes',
    'Dejar de cargar con las expectativas de los demás',
    'Priorizar mi propio bienestar antes que complacer a todos',
    'Hablarme con compasión al cometer un error',
    'Identificar mis miedos inconscientes ante el rechazo'
  ];

  const defaultGoalsEn = [
    'Learn to say "no" without feeling guilty',
    'Set healthy boundaries with emotionally demanding people',
    'Stop carrying other people\'s expectations',
    'Prioritize my own well-being before pleasing everyone',
    'Speak to myself with compassion when making a mistake',
    'Identify my unconscious fears of rejection'
  ];

  const defaultGoals = language === 'es' ? defaultGoalsEs : defaultGoalsEn;

  // Curated list of medals
  const allMedals = [
    {
      id: 'welcome_badge',
      nameEs: 'Semilla de Amor Propio',
      nameEn: 'Seed of Self-Love',
      descEs: 'Otorgado al comenzar tu camino de sanación con Olivia.',
      descEn: 'Awarded when you begin your healing journey with Olivia.',
      emoji: '🌸',
      color: 'from-rose-400 to-amber-300'
    },
    {
      id: 'first_journal',
      nameEs: 'Escritura Liberadora',
      nameEn: 'Liberating Writing',
      descEs: 'Escribe tu primera reflexión honesta en tu diario.',
      descEn: 'Write your first honest reflection in your journal.',
      emoji: '✍️',
      color: 'from-purple-400 to-indigo-400'
    },
    {
      id: 'breath_master',
      nameEs: 'Soplo de Serenidad',
      nameEn: 'Breath of Serenity',
      descEs: 'Completa un ciclo de respiración consciente guiada.',
      descEn: 'Complete a cycle of guided conscious breathing.',
      emoji: '🌬️',
      color: 'from-emerald-400 to-teal-400'
    },
    {
      id: 'game_champ',
      nameEs: 'Mente Resiliente',
      nameEn: 'Resilient Mind',
      descEs: 'Desafía tu ansiedad jugando en el Gimnasio Emocional.',
      descEn: 'Challenge your anxiety playing in the Emotional Gym.',
      emoji: '🎮',
      color: 'from-sky-400 to-blue-400'
    },
    {
      id: 'streak_hero',
      nameEs: 'Firme en tu Paz',
      nameEn: 'Firm in Your Peace',
      descEs: 'Logra una racha consecutiva de 3 o más días.',
      descEn: 'Achieve a consecutive streak of 3 or more days.',
      emoji: '🔥',
      color: 'from-orange-500 to-rose-400'
    },
    {
      id: 'limit_setter',
      nameEs: 'Escudo Protector',
      nameEn: 'Protective Shield',
      descEs: 'Establece y completa un objetivo terapéutico de límites.',
      descEn: 'Establish and complete a therapeutic boundary goal.',
      emoji: '🛡️',
      color: 'from-amber-400 to-amber-600'
    }
  ];

  // Fetch server profile
  const fetchProfile = async () => {
    setIsLoadingProfile(true);
    try {
      const res = await fetch(`/api/history/olivia_user_01`);
      if (res.ok) {
        const data = await res.json();
        setServerProfile({
          moodHistory: data.moodHistory || [],
          conversationsCount: data.conversationsCount || 0,
          goals: data.goals || [],
          completedSessions: data.completedSessions || [],
          recaidas: data.recaidas || []
        });
      }
    } catch (e) {
      console.error('Failed to load server profile:', e);
    } finally {
      setIsLoadingProfile(false);
    }
  };

  useEffect(() => {
    fetchProfile();
  }, [userState.completedDailyTasks, userState.unlockedMedals]);

  // Handle checking/adding a custom goal
  const handleAddCustomGoal = async () => {
    if (!newGoalText.trim()) return;
    const goal = newGoalText.trim();
    setNewGoalText('');
    
    // Save locally
    onGainXP(15);
    audioSynth.playBell(587.33); // D5 pleasant chime

    // Save on server
    try {
      const res = await fetch('/api/history/olivia_user_01/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ goal })
      });
      if (res.ok) {
        fetchProfile();
      }
    } catch (e) {
      console.error('Error updating goal:', e);
    }
  };

  // Toggle pre-curated goals
  const handleToggleGoal = async (goal: string) => {
    if (serverProfile.goals.includes(goal)) return; // Already completed

    onGainXP(30);
    audioSynth.playBell(659.25); // E5 positive bell tone

    try {
      const res = await fetch('/api/history/olivia_user_01/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ goal })
      });
      if (res.ok) {
        fetchProfile();
      }
    } catch (e) {
      console.error('Error toggling goal:', e);
    }
  };

  // Quick Gratitude Journaling from the progress tab
  const handleSaveQuickGratitude = async () => {
    if (!quickGratitude.trim()) return;
    const noteText = quickGratitude.trim();
    setQuickGratitude('');

    onGainXP(25);
    audioSynth.playBell(523.25); // C5 calm chime

    // Save on server as a goal/diary entry proxy or trigger a history update
    try {
      await fetch('/api/history/olivia_user_01/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ goal: `📝 ${language === 'es' ? 'Agradecimiento' : 'Gratitude'}: "${noteText}"` })
      });
      fetchProfile();
    } catch (e) {
      console.error('Error saving gratitude:', e);
    }
  };

  // Clear a goal entry (or simulate deleting it)
  const handleDeleteGoal = async (goal: string) => {
    // For premium feel, let the user remove the completed goals locally/visual-only or trigger profile reload
    // In server, we can simulate or filter
    setServerProfile(prev => ({
      ...prev,
      goals: prev.goals.filter(g => g !== goal)
    }));
    audioSynth.playBell(293.66); // D4 low corrective chime
  };

  // Calculate mood check-in distribution
  const moodCounts: Record<string, number> = {};
  serverProfile.moodHistory.forEach((item) => {
    moodCounts[item.mood] = (moodCounts[item.mood] || 0) + 1;
  });

  const moodTranslations: Record<string, string> = {
    ansiosa: language === 'es' ? 'Ansiosa' : 'Anxious',
    triste: language === 'es' ? 'Triste' : 'Sad',
    con_miedo: language === 'es' ? 'Con miedo' : 'Scared',
    sin_energia: language === 'es' ? 'Sin energía' : 'No Energy',
    con_culpa: language === 'es' ? 'Con culpa' : 'Guilty',
    enojada: language === 'es' ? 'Enojada' : 'Angry',
    con_ansiedad: language === 'es' ? 'Con ansiedad' : 'With Anxiety',
    corazon_roto: language === 'es' ? 'Corazón roto' : 'Heartbroken',
    necesito_paz: language === 'es' ? 'Necesito paz' : 'Need Peace',
    necesito_ayuda: language === 'es' ? 'Necesito ayuda' : 'Need Help',
    quiero_crecer: language === 'es' ? 'Quiero crecer' : 'Want to Grow',
    quiero_sanar: language === 'es' ? 'Quiero sanar' : 'Want to Heal'
  };

  const totalMoodEntries = serverProfile.moodHistory.length || 1;

  return (
    <div id="my-progress-container" className="max-w-4xl mx-auto space-y-6 overflow-y-auto h-[calc(100vh-140px)] pr-1 scrollbar-thin">
      {/* 1. Header Banner */}
      <div className={`p-6 rounded-3xl border relative overflow-hidden flex flex-col md:flex-row items-center justify-between gap-4 shadow-md ${
        currentTheme === 'dark' 
          ? 'bg-gradient-to-tr from-neutral-900 to-neutral-950 border-neutral-850' 
          : 'bg-gradient-to-tr from-rose-50/40 via-amber-50/20 to-rose-100/10 border-rose-100/50'
      }`}>
        <div className="absolute top-0 right-0 w-32 h-32 bg-rose-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="space-y-1.5 text-center md:text-left flex-1">
          <span className="text-[10px] bg-rose-500/10 text-rose-500 px-3 py-1 rounded-full font-black uppercase tracking-widest inline-flex items-center gap-1.5">
            <Sparkle className="w-3.5 h-3.5 text-rose-500" />
            {language === 'es' ? 'Tu Espacio de Autenticidad' : 'Your Space of Authenticity'}
          </span>
          <h2 className={`text-2xl font-black tracking-tight ${currentTheme === 'dark' ? 'text-white' : 'text-neutral-800'}`}>
            {language === 'es' ? `Progreso de ${userName}` : `${userName}'s Progress`} 💖
          </h2>
          <p className={`text-xs max-w-lg leading-relaxed ${currentTheme === 'dark' ? 'text-neutral-300' : 'text-neutral-500'}`}>
            {language === 'es'
              ? 'Cada paso que das, por pequeño que sea, es una declaración de amor propio. Aquí se reúne tu rastro de valentía.'
              : 'Every step you take, no matter how small, is a declaration of self-love. Here your track of bravery is gathered.'}
          </p>
        </div>

        {/* Level and total XP summary */}
        <div className={`p-4 rounded-2xl border text-center shrink-0 min-w-[130px] ${
          currentTheme === 'dark' ? 'bg-neutral-950/40 border-neutral-800' : 'bg-white border-rose-100/30'
        }`}>
          <span className="text-[10px] text-neutral-400 uppercase font-black tracking-wider block">
            {language === 'es' ? 'Nivel de Sanación' : 'Healing Level'}
          </span>
          <span className="text-3xl font-black text-rose-500 block leading-none my-1">
            {userState.level}
          </span>
          <span className="text-[10px] font-bold text-neutral-400 block">
            {userState.xp} total XP
          </span>
        </div>
      </div>

      {/* 2. Bento Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5">
        {/* Stat 1: Days of Companion */}
        <div className={`p-4 rounded-3xl border flex flex-col justify-between shadow-sm relative overflow-hidden ${
          currentTheme === 'dark' ? 'bg-neutral-900/60 border-neutral-850' : 'bg-white border-rose-100/50'
        }`}>
          <div className="flex items-center justify-between">
            <Calendar className="w-5 h-5 text-rose-500" />
            <span className="text-[9px] font-black text-rose-400 uppercase tracking-widest">
              {language === 'es' ? 'RECORRIDO' : 'PATH'}
            </span>
          </div>
          <div className="mt-4">
            <span className={`text-2xl font-black block leading-none ${currentTheme === 'dark' ? 'text-white' : 'text-neutral-800'}`}>
              Día {userState.daysAcompanamiento || 1}
            </span>
            <span className="text-[10px] text-neutral-400 mt-1 block">
              {language === 'es' ? 'Acompañamiento real' : 'Actual days of companion'}
            </span>
          </div>
        </div>

        {/* Stat 2: Streak */}
        <div className={`p-4 rounded-3xl border flex flex-col justify-between shadow-sm relative overflow-hidden ${
          currentTheme === 'dark' ? 'bg-neutral-900/60 border-neutral-850' : 'bg-white border-rose-100/50'
        }`}>
          <div className="flex items-center justify-between">
            <Flame className="w-5 h-5 text-amber-500 animate-pulse" />
            <span className="text-[9px] font-black text-amber-500 uppercase tracking-widest">
              {language === 'es' ? 'CONSTANCIA' : 'STREAK'}
            </span>
          </div>
          <div className="mt-4">
            <span className={`text-2xl font-black block leading-none ${currentTheme === 'dark' ? 'text-white' : 'text-neutral-800'}`}>
              {userState.streak} {language === 'es' ? 'Días' : 'Days'}
            </span>
            <span className="text-[10px] text-neutral-400 mt-1 block">
              {language === 'es' ? 'Racha de autocuidado' : 'Self-care consistency'}
            </span>
          </div>
        </div>

        {/* Stat 3: Wellness Time */}
        <div className={`p-4 rounded-3xl border flex flex-col justify-between shadow-sm relative overflow-hidden ${
          currentTheme === 'dark' ? 'bg-neutral-900/60 border-neutral-850' : 'bg-white border-rose-100/50'
        }`}>
          <div className="flex items-center justify-between">
            <Clock className="w-5 h-5 text-emerald-500" />
            <span className="text-[9px] font-black text-emerald-500 uppercase tracking-widest">
              {language === 'es' ? 'TIEMPO' : 'TIME'}
            </span>
          </div>
          <div className="mt-4">
            <span className={`text-2xl font-black block leading-none ${currentTheme === 'dark' ? 'text-white' : 'text-neutral-800'}`}>
              {userState.totalWellnessMinutes || 10} min
            </span>
            <span className="text-[10px] text-neutral-400 mt-1 block">
              {language === 'es' ? 'Dedicado al bienestar' : 'Dedicated to wellness'}
            </span>
          </div>
        </div>

        {/* Stat 4: Activities Completed */}
        <div className={`p-4 rounded-3xl border flex flex-col justify-between shadow-sm relative overflow-hidden ${
          currentTheme === 'dark' ? 'bg-neutral-900/60 border-neutral-850' : 'bg-white border-rose-100/50'
        }`}>
          <div className="flex items-center justify-between">
            <Activity className="w-5 h-5 text-sky-500" />
            <span className="text-[9px] font-black text-sky-500 uppercase tracking-widest">
              {language === 'es' ? 'ACTIVIDADES' : 'ACTIVITIES'}
            </span>
          </div>
          <div className="mt-4">
            <span className={`text-2xl font-black block leading-none ${currentTheme === 'dark' ? 'text-white' : 'text-neutral-800'}`}>
              {userState.activitiesCount || 2}
            </span>
            <span className="text-[10px] text-neutral-400 mt-1 block">
              {language === 'es' ? 'Acciones realizadas' : 'Practices completed'}
            </span>
          </div>
        </div>
      </div>

      {/* 3. Emotional Evolution and Objectives Block */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
        {/* Left Column: Emotional Calendar and Evolution Chart */}
        <div className="md:col-span-2 space-y-6">
          <div className={`p-5 rounded-3xl border shadow-sm ${
            currentTheme === 'dark' ? 'bg-neutral-900/60 border-neutral-850 text-white' : 'bg-white border-rose-100/50 text-neutral-800'
          }`}>
            <h3 className="font-bold text-xs text-rose-500 uppercase tracking-widest flex items-center gap-2 mb-4">
              <BarChart3 className="w-4 h-4" />
              {language === 'es' ? 'Distribución Emocional' : 'Emotional Chart'}
            </h3>
            
            {serverProfile.moodHistory.length === 0 ? (
              <div className="text-center py-6">
                <Smile className="w-8 h-8 text-neutral-300 mx-auto mb-2 animate-bounce" />
                <p className="text-xs text-neutral-400 font-semibold uppercase">
                  {language === 'es' ? 'Aún no registras emociones' : 'No emotion logs yet'}
                </p>
                <p className="text-[10px] text-neutral-400 leading-relaxed mt-1">
                  {language === 'es' ? 'Haz un chequeo en el Inicio hoy.' : 'Complete a daily check-in to see logs.'}
                </p>
              </div>
            ) : (
              <div className="space-y-3.5">
                {Object.entries(moodCounts).map(([key, value]) => {
                  const pct = Math.round((value / totalMoodEntries) * 100);
                  const emotionLabel = moodTranslations[key] || key;
                  return (
                    <div key={key} className="space-y-1">
                      <div className="flex justify-between text-[11px] font-bold">
                        <span className="capitalize">{emotionLabel}</span>
                        <span className="text-neutral-400">{pct}% ({value})</span>
                      </div>
                      <div className="w-full h-2 bg-neutral-200/40 rounded-full overflow-hidden">
                        <motion.div
                          initial={{ width: 0 }}
                          animate={{ width: `${pct}%` }}
                          transition={{ duration: 0.6 }}
                          className="h-full bg-gradient-to-r from-rose-400 to-amber-300 rounded-full"
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Rapid Gratitude Box */}
          <div className={`p-5 rounded-3xl border shadow-sm ${
            currentTheme === 'dark' ? 'bg-neutral-900/60 border-neutral-850' : 'bg-white border-rose-100/50'
          }`}>
            <h3 className="font-bold text-xs text-purple-500 uppercase tracking-widest flex items-center gap-2 mb-3">
              <PenTool className="w-4 h-4" />
              {language === 'es' ? 'Reflexión Instantánea' : 'Instant Reflection'}
            </h3>
            <p className="text-[10px] text-neutral-400 leading-relaxed mb-3">
              {language === 'es' 
                ? '¿Qué hay en tu mente justo ahora? Escríbelo para sembrar gratitud.' 
                : 'What is on your mind right now? Write it to seed gratitude.'}
            </p>
            <div className="space-y-2">
              <input
                type="text"
                placeholder={language === 'es' ? 'Hoy agradezco por...' : 'Today I am grateful for...'}
                value={quickGratitude}
                onChange={(e) => setQuickGratitude(e.target.value)}
                className={`w-full p-3 text-xs rounded-xl border focus:outline-none focus:ring-2 focus:ring-rose-300 ${
                  currentTheme === 'dark'
                    ? 'bg-neutral-950 border-neutral-800 text-white'
                    : 'bg-white border-rose-100/30 text-neutral-800'
                }`}
              />
              <button
                onClick={handleSaveQuickGratitude}
                disabled={!quickGratitude.trim()}
                className={`w-full py-2.5 rounded-xl text-xs font-bold tracking-wide text-white bg-gradient-to-r from-purple-400 to-rose-400 hover:opacity-90 active:scale-98 transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                  !quickGratitude.trim() && 'opacity-50 cursor-not-allowed'
                }`}
              >
                <span>✨</span>
                <span>{language === 'es' ? 'Sembrar en mi Diario (+25 XP)' : 'Plant in my Journal (+25 XP)'}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: Healing Goals & Objectives List */}
        <div className="md:col-span-3 space-y-6">
          <div className={`p-5 rounded-3xl border shadow-sm ${
            currentTheme === 'dark' ? 'bg-neutral-900/60 border-neutral-850 text-white' : 'bg-white border-rose-100/50 text-neutral-800'
          }`}>
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-bold text-xs text-amber-500 uppercase tracking-widest flex items-center gap-2">
                <Target className="w-4 h-4" />
                {language === 'es' ? 'Tus Objetivos Terapéuticos' : 'Your Therapeutic Goals'}
              </h3>
              <span className="text-[9px] bg-amber-500/10 text-amber-600 px-2 py-0.5 rounded-full font-black">
                +30 XP {language === 'es' ? 'CADA UNO' : 'EACH'}
              </span>
            </div>
            
            <p className="text-[11px] text-neutral-400 leading-relaxed mb-4">
              {language === 'es'
                ? 'Elige tus objetivos de crecimiento basados en "Mi Psicóloga Me Dijo" y márcalos cuando sientas avances reales en tu interior.'
                : 'Choose your growth goals based on "My Therapist Told Me" and mark them when you feel real progress within.'}
            </p>

            {/* List of Goals */}
            <div className="space-y-2.5 max-h-[280px] overflow-y-auto pr-1">
              {/* Curated goals list */}
              {defaultGoals.map((goal, idx) => {
                const isCompleted = serverProfile.goals.includes(goal);
                return (
                  <div
                    key={idx}
                    onClick={() => handleToggleGoal(goal)}
                    className={`p-3 rounded-2xl border transition-all flex items-center justify-between cursor-pointer gap-2.5 ${
                      isCompleted
                        ? 'bg-emerald-500/5 border-emerald-500/20 text-neutral-400 line-through'
                        : currentTheme === 'dark'
                          ? 'bg-neutral-950/40 border-neutral-800 hover:border-neutral-700'
                          : 'bg-neutral-50/50 border-neutral-100 hover:bg-rose-50/10'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 flex-1">
                      {isCompleted ? (
                        <CheckCircle2 className="w-4.5 h-4.5 text-emerald-500 shrink-0" />
                      ) : (
                        <Circle className="w-4.5 h-4.5 text-neutral-300 shrink-0" />
                      )}
                      <span className="text-xs font-semibold leading-snug">{goal}</span>
                    </div>
                    {isCompleted && (
                      <span className="text-[8px] bg-emerald-500/10 text-emerald-600 px-2 py-0.5 rounded-full uppercase font-bold shrink-0">
                        {language === 'es' ? 'Logrado' : 'Achieved'}
                      </span>
                    )}
                  </div>
                );
              })}

              {/* User custom added goals */}
              {serverProfile.goals.filter(g => !defaultGoals.includes(g)).map((goal, idx) => (
                <div
                  key={`custom-${idx}`}
                  className="p-3 rounded-2xl border bg-emerald-500/5 border-emerald-500/20 text-neutral-500 transition-all flex items-center justify-between gap-2.5"
                >
                  <div className="flex items-center gap-2.5 flex-1">
                    <CheckCircle2 className="w-4.5 h-4.5 text-emerald-500 shrink-0" />
                    <span className="text-xs font-semibold leading-snug line-through">{goal}</span>
                  </div>
                  <button
                    onClick={() => handleDeleteGoal(goal)}
                    className="p-1 rounded-full text-neutral-400 hover:text-red-500 hover:bg-neutral-100 dark:hover:bg-neutral-800"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>

            {/* Custom goal input field */}
            <div className="flex items-center gap-2 mt-4 pt-4 border-t border-rose-100/10">
              <input
                type="text"
                placeholder={language === 'es' ? 'Añadir mi propio objetivo de sanación...' : 'Add my own healing goal...'}
                value={newGoalText}
                onChange={(e) => setNewGoalText(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleAddCustomGoal()}
                className={`flex-1 p-3 text-xs rounded-xl border focus:outline-none focus:ring-2 focus:ring-rose-300 ${
                  currentTheme === 'dark'
                    ? 'bg-neutral-950 border-neutral-800 text-white'
                    : 'bg-white border-rose-100/30 text-neutral-800'
                }`}
              />
              <button
                onClick={handleAddCustomGoal}
                disabled={!newGoalText.trim()}
                className={`p-3 rounded-xl bg-gradient-to-tr from-amber-400 to-rose-400 text-white hover:opacity-90 active:scale-95 transition-all cursor-pointer ${
                  !newGoalText.trim() && 'opacity-50 cursor-not-allowed'
                }`}
              >
                <Plus className="w-4.5 h-4.5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 4. Achievements and Medals Section */}
      <div className={`p-6 rounded-3xl border shadow-sm ${
        currentTheme === 'dark' ? 'bg-neutral-900/60 border-neutral-850' : 'bg-white border-rose-100/50'
      }`}>
        <div className="mb-4">
          <h3 className="font-bold text-xs text-rose-500 uppercase tracking-widest flex items-center gap-2">
            <Award className="w-4.5 h-4.5" />
            {language === 'es' ? 'Tus Insignias y Logros' : 'Your Achievements & Badges'}
          </h3>
          <p className="text-[11px] text-neutral-400 mt-1 leading-relaxed">
            {language === 'es'
              ? 'Conforme avanzas en tus sesiones, respondes el chat y realizas prácticas, desbloquearás insignias que honran tu evolución.'
              : 'As you progress in your sessions, answer the chat, and practice, you will unlock badges that honor your evolution.'}
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
          {allMedals.map((medal) => {
            const isUnlocked = userState.unlockedMedals.includes(medal.id);
            return (
              <motion.div
                key={medal.id}
                whileHover={{ scale: isUnlocked ? 1.03 : 1 }}
                className={`p-3.5 rounded-2xl border text-center relative flex flex-col items-center justify-between min-h-[145px] transition-all ${
                  isUnlocked
                    ? `bg-gradient-to-b ${currentTheme === 'dark' ? 'from-neutral-900 to-neutral-950' : 'from-neutral-50/50 to-white'} border-rose-100/30 shadow-md`
                    : 'opacity-40 grayscale border-dashed border-neutral-300 dark:border-neutral-800'
                }`}
              >
                <div className="flex flex-col items-center mt-1">
                  {/* Icon with glowing aura if unlocked */}
                  <div className="relative">
                    {isUnlocked && (
                      <motion.div 
                        animate={{ scale: [1, 1.15, 1], opacity: [0.3, 0, 0.3] }}
                        transition={{ repeat: Infinity, duration: 3, ease: 'easeInOut' }}
                        className="absolute inset-0 bg-rose-400 rounded-full blur-md"
                      />
                    )}
                    <div className={`w-12 h-12 rounded-full bg-gradient-to-tr ${isUnlocked ? medal.color : 'from-neutral-200 to-neutral-300'} flex items-center justify-center text-xl shadow-inner relative z-10`}>
                      {medal.emoji}
                    </div>
                  </div>

                  <h4 className={`text-xs font-bold mt-2.5 leading-tight ${currentTheme === 'dark' ? 'text-white' : 'text-neutral-800'}`}>
                    {language === 'es' ? medal.nameEs : medal.nameEn}
                  </h4>
                  <p className="text-[9px] text-neutral-400 leading-snug mt-1 max-w-[100px] mx-auto line-clamp-2">
                    {language === 'es' ? medal.descEs : medal.descEn}
                  </p>
                </div>

                <div className="mt-2 w-full">
                  <span className={`text-[8px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full block text-center ${
                    isUnlocked
                      ? 'bg-emerald-500/10 text-emerald-600'
                      : 'bg-neutral-100 text-neutral-500 dark:bg-neutral-800 dark:text-neutral-400'
                  }`}>
                    {isUnlocked 
                      ? (language === 'es' ? 'Desbloqueado' : 'Unlocked') 
                      : (language === 'es' ? 'Bloqueado' : 'Locked')}
                  </span>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
