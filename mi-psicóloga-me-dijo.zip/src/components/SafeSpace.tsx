import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Play, Square, Volume2, ShieldAlert, Sparkles, Smile, Wind, Compass } from 'lucide-react';
import { Language, UserState } from '../types';
import { audioSynth } from '../lib/audio';

interface SafeSpaceProps {
  language: Language;
  userState: UserState;
  onGainXP: (amount: number) => void;
}

export default function SafeSpace({ language, userState, onGainXP }: SafeSpaceProps) {
  const [soundMix, setSoundMix] = useState({
    rain: false,
    ocean: false,
    synth: false,
  });
  const [volumes, setVolumes] = useState({
    rain: 0.15,
    ocean: 0.25,
    synth: 0.12,
  });
  const [sleepMinutes, setSleepMinutes] = useState<number | null>(null);
  const [timeLeft, setTimeLeft] = useState<number>(0);

  const [breatheState, setBreatheState] = useState<'inhale' | 'hold' | 'exhale' | 'idle'>('idle');
  const [breatheSeconds, setBreatheSeconds] = useState(0);

  // SOS Panic Calm Mode
  const [sosActive, setSosActive] = useState(false);
  const [sosStep, setSosStep] = useState(0);

  const currentTheme = userState.theme;

  // Cleanup sounds on component unmount
  useEffect(() => {
    return () => {
      audioSynth.stopAll();
    };
  }, []);

  // Guided breathing loop interval
  useEffect(() => {
    if (breatheState === 'idle') return;
    let sec = 0;
    const interval = setInterval(() => {
      sec += 1;
      setBreatheSeconds(sec);

      if (breatheState === 'inhale' && sec >= 4) {
        setBreatheState('hold');
        audioSynth.playBell(392.00); // G note chime
        sec = 0;
      } else if (breatheState === 'hold' && sec >= 4) {
        setBreatheState('exhale');
        audioSynth.playBell(329.63); // E note chime
        sec = 0;
      } else if (breatheState === 'exhale' && sec >= 4) {
        setBreatheState('inhale');
        audioSynth.playBell(523.25); // High C note chime
        sec = 0;
        onGainXP(10); // Reward for completing a full breath cycle
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [breatheState]);

  // SOS step sequence
  useEffect(() => {
    if (!sosActive) return;
    const timeouts = [
      setTimeout(() => setSosStep(1), 5000),
      setTimeout(() => setSosStep(2), 12000),
      setTimeout(() => setSosStep(3), 22000),
      setTimeout(() => {
        setSosActive(false);
        setSosStep(0);
        onGainXP(50); // Massive boost for completing SOS session
      }, 35000)
    ];

    return () => timeouts.forEach(clearTimeout);
  }, [sosActive]);

  // Sleep Timer Countdown Effect
  useEffect(() => {
    if (sleepMinutes === null) return;
    
    setTimeLeft(sleepMinutes * 60);
    const interval = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          audioSynth.fadeOutAndStop(3);
          setSoundMix({ rain: false, ocean: false, synth: false });
          setSleepMinutes(null);
          clearInterval(interval);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [sleepMinutes]);

  const handleToggleSound = (sound: 'rain' | 'ocean' | 'synth') => {
    audioSynth.resumeContext();

    setSoundMix(prev => {
      const isPlayingNow = !prev[sound];
      if (isPlayingNow) {
        if (sound === 'rain') audioSynth.playRain(volumes.rain);
        if (sound === 'ocean') audioSynth.playOcean(volumes.ocean);
        if (sound === 'synth') audioSynth.playSynth(volumes.synth);
      } else {
        if (sound === 'rain') audioSynth.stopRain();
        if (sound === 'ocean') audioSynth.stopOcean();
        if (sound === 'synth') audioSynth.stopSynth();
      }
      return { ...prev, [sound]: isPlayingNow };
    });
  };

  const handleVolumeChange = (sound: 'rain' | 'ocean' | 'synth', val: number) => {
    setVolumes(prev => {
      const updated = { ...prev, [sound]: val };
      audioSynth.setVolume(sound, val);
      return updated;
    });
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const startBreathing = () => {
    setBreatheState('inhale');
    setBreatheSeconds(0);
    audioSynth.playBell(523.25);
  };

  const stopBreathing = () => {
    setBreatheState('idle');
    setBreatheSeconds(0);
  };

  const triggerSOS = () => {
    setSosActive(true);
    setSosStep(0);
    audioSynth.playBell(261.63); // Low C for grounding
    audioSynth.playOcean(volumes.ocean); // Autostart soothing sea sound in SOS mode
    setSoundMix({ rain: false, ocean: true, synth: false });
  };

  const sosMessages: Record<Language, string[]> = {
    es: [
      'Todo está bien. Estás a salvo aquí conmigo.',
      'Siente tus pies en el suelo. Respira lento y profundo.',
      'Esto que sientes es solo ansiedad, y va a pasar. No dura para siempre.',
      'Estás haciendo un gran trabajo cuidándote. Inhala paz, exhala tensión.'
    ],
    en: [
      'Everything is fine. You are safe here with me.',
      'Feel your feet on the ground. Breathe slow and deep.',
      'What you feel is just anxiety, and it will pass. It does not last forever.',
      'You are doing a great job taking care of yourself. Inhale peace, exhale tension.'
    ],
    pt: [
      'Está tudo bem. Você está segura aqui comigo.',
      'Sinta seus pés no chão. Respire lento e profundo.',
      'O que você sente é apenas ansiedade, e vai passar. Não dura para sempre.',
      'Você está fazendo um excelente trabalho se cuidando. Inspire paz, expire tensão.'
    ],
    it: [
      'Tutto va bene. Sei al sicuro qui con me.',
      'Senti i tuoi piedi a terra. Respira lentamente e profondamente.',
      'Ciò che provi è solo ansia, e passerà. Non dura per sempre.',
      'Stai facendo un ottimo lavoro prendendoti cura di te stessa. Inspira pace, espira tensione.'
    ],
    fr: [
      'Tout va bien. Tu es en sécurité ici avec moi.',
      'Sens tes pieds sur le sol. Respire lentement et profondément.',
      'Ce que tu ressens n\'est que de l\'anxiété, et cela va passer. Ça ne dure pas toujours.',
      'Tu fais du super travail en prenant soin de toi. Inspire la paix, expire la tension.'
    ],
    de: [
      'Alles ist gut. Du bist hier bei mir in Sicherheit.',
      'Spüre deine Füße auf dem Boden. Atme langsam und tief.',
      'Was du fühlst, ist nur Angst, und sie wird vergehen. Es hält nicht ewig an.',
      'Du machst das großartig, dich um dich selbst zu kümmern. Atme Frieden ein, atme Anspannung aus.'
    ],
    nl: [
      'Alles is goed. Je bent veilig hier bij mij.',
      'Voel je voeten op de grond. Adem langzaam en diep.',
      'Wat je voelt is gewoon angst, en het zal voorbijgaan. Het duurt niet eeuwig.',
      'Je doet het geweldig om voor jezelf te zorgen. Adem vrede in, adem spanning uit.'
    ],
    ca: [
      'Tot està bé. Estàs segura aquí amb mi.',
      'Sent els teus peus a terra. Respira lentament i profundament.',
      'Això que sents és només ansietat, i passarà. No dura per sempre.',
      'Estàs fent una gran feina cuidant-te. Inspira pau, exhala tensió.'
    ]
  };

  return (
    <div id="safe-space-container" className="max-w-xl mx-auto space-y-6 overflow-y-auto h-[calc(100vh-140px)] pr-1 scrollbar-thin">
      {/* Welcome Card */}
      <div className="text-center">
        <h2 className={`text-2xl font-bold tracking-tight flex items-center justify-center gap-2 ${currentTheme === 'dark' ? 'text-white' : 'text-neutral-800'}`}>
          <Compass className="w-6 h-6 text-rose-400" />
          {language === 'es' ? 'Tu Espacio Seguro' : 'Your Safe Space'}
        </h2>
        <p className="text-xs text-neutral-400 mt-1">
          {language === 'es' ? 'Un refugio cálido para cuando te sientas desbordada.' : 'A warm refuge for whenever you feel overwhelmed.'}
        </p>
      </div>

      {/* SOS EMERGENCY PANIC ACCORDION BUTTON */}
      <div className={`p-5 rounded-3xl border text-center shadow-lg relative overflow-hidden transition-all ${
        sosActive 
          ? 'bg-rose-100/50 border-rose-300' 
          : currentTheme === 'dark'
            ? 'bg-neutral-900/80 border-rose-900/30'
            : 'bg-gradient-to-tr from-rose-50 to-amber-50 border-rose-100'
      }`}>
        <AnimatePresence mode="wait">
          {!sosActive ? (
            <motion.div key="sos-idle" className="space-y-4">
              <div className="mx-auto w-12 h-12 bg-rose-200/50 rounded-full flex items-center justify-center">
                <ShieldAlert className="w-6 h-6 text-rose-400" />
              </div>
              <div>
                <h3 className="font-bold text-base text-rose-500 tracking-tight">
                  {language === 'es' ? '¿Anhelas Calma Inmediata? (SOS)' : 'Need Immediate Calm? (SOS)'}
                </h3>
                <p className="text-xs text-neutral-500 max-w-sm mx-auto mt-1 leading-relaxed">
                  {language === 'es' 
                    ? '¿Sientes un ataque de pánico o ansiedad? Presiona para iniciar una guía sensorial de calma rápida de 30 segundos.'
                    : 'Feeling a panic attack or high anxiety? Press to initiate a quick 30-second sensory calm guide.'}
                </p>
              </div>
              <button
                id="trigger-sos-btn"
                onClick={triggerSOS}
                className="px-6 py-2.5 bg-gradient-to-r from-rose-400 to-coral-400 text-white font-bold text-xs rounded-full shadow-md active:scale-95 transition-all uppercase tracking-wider"
              >
                {language === 'es' ? 'Iniciar Calma SOS' : 'Trigger SOS Calm'}
              </button>
            </motion.div>
          ) : (
            <motion.div key="sos-active" className="space-y-6 py-4">
              {/* Spinning calming spiral representation */}
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ repeat: Infinity, duration: 10, ease: 'linear' }}
                className="mx-auto w-16 h-16 border-4 border-dashed border-rose-400 rounded-full flex items-center justify-center"
              >
                🌀
              </motion.div>
              <motion.div
                key={sosStep}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-2 min-h-[60px] flex flex-col justify-center"
              >
                <h4 className="font-bold text-sm text-rose-600">
                  Olivia te acompaña:
                </h4>
                <p className="text-xs md:text-sm text-neutral-600 italic font-medium max-w-md mx-auto leading-relaxed">
                  "{(sosMessages[language] || sosMessages['es'])[sosStep]}"
                </p>
              </motion.div>
              <button
                onClick={() => {
                  setSosActive(false);
                  audioSynth.stopAll();
                  setSoundMix({ rain: false, ocean: false, synth: false });
                }}
                className="px-4 py-1.5 bg-neutral-200 text-neutral-600 text-[10px] font-bold rounded-full uppercase tracking-wider hover:bg-neutral-300 transition-colors"
              >
                {language === 'es' ? 'Cerrar SOS' : 'Cancel SOS'}
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* PREMIUM MIXER BENTO CARD */}
      <div className={`p-6 rounded-3xl border shadow-md relative overflow-hidden ${
        currentTheme === 'dark' ? 'bg-neutral-900/60 border-neutral-850 text-white' : 'bg-white border-rose-100/50 text-neutral-800'
      }`}>
        <div className="flex items-center justify-between mb-2">
          <h3 className="font-extrabold tracking-tight text-sm md:text-base flex items-center gap-2">
            <Volume2 className="w-5 h-5 text-rose-400" />
            {language === 'es' ? 'Mezclador Ambient Premium' : 'Premium Ambient Mixer'}
          </h3>
          <span className="text-[9px] bg-rose-500/10 text-rose-500 px-2 py-0.5 rounded-full font-black uppercase tracking-wider">
            HQ Audio
          </span>
        </div>
        <p className="text-[11px] text-neutral-400 mb-5 leading-relaxed">
          {language === 'es'
            ? 'Combina múltiples sonidos, calibra volúmenes independientes y activa el temporizador para dormir.'
            : 'Mix multiple sounds, calibrate individual volumes and activate the custom sleep timer.'}
        </p>

        {/* Mixer Grid */}
        <div className="space-y-4 mb-5">
          {[
            { id: 'rain', label: language === 'es' ? 'Lluvia Zen' : 'Zen Rain', emoji: '🌧️', color: 'bg-blue-400' },
            { id: 'ocean', label: language === 'es' ? 'Olas de Mar' : 'Ocean Waves', emoji: '🌊', color: 'bg-teal-400' },
            { id: 'synth', label: language === 'es' ? 'Acordes de Paz' : 'Peace Chords', emoji: '🎹', color: 'bg-purple-400' }
          ].map(sound => {
            const isPlaying = soundMix[sound.id as 'rain' | 'ocean' | 'synth'];
            const curVol = volumes[sound.id as 'rain' | 'ocean' | 'synth'];
            return (
              <div 
                key={sound.id} 
                className={`p-3.5 rounded-2xl border transition-all flex flex-col space-y-2.5 ${
                  isPlaying 
                    ? 'bg-rose-50/10 border-rose-200' 
                    : 'bg-neutral-100/5 border-neutral-200/10'
                }`}
              >
                <div className="flex items-center justify-between">
                  <button
                    onClick={() => handleToggleSound(sound.id as any)}
                    className={`flex items-center gap-2 text-xs font-bold px-3.5 py-1.5 rounded-full border transition-all cursor-pointer ${
                      isPlaying 
                        ? 'bg-rose-400 text-white border-rose-400 font-extrabold shadow-sm scale-98' 
                        : 'bg-white hover:bg-neutral-150 text-neutral-700 border-neutral-200'
                    }`}
                  >
                    <span>{sound.emoji}</span>
                    <span>{sound.label}</span>
                  </button>

                  {/* Bouncing audio wave bars if playing */}
                  {isPlaying ? (
                    <div className="flex items-end gap-0.5 h-3">
                      {[0.1, 0.4, 0.25].map((delay, idx) => (
                        <motion.div
                          key={idx}
                          animate={{ height: [4, 12, 4] }}
                          transition={{ repeat: Infinity, duration: 0.8, delay, ease: 'easeInOut' }}
                          className={`w-0.5 rounded-full ${sound.color}`}
                        />
                      ))}
                    </div>
                  ) : (
                    <span className="text-[10px] text-neutral-400 uppercase font-bold tracking-wider">OFF</span>
                  )}
                </div>

                {/* Range Volume Slider */}
                <div className="flex items-center gap-2.5">
                  <span className="text-[10px] font-black text-neutral-400 w-6 text-right">
                    {Math.round(curVol * 100)}%
                  </span>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.01"
                    value={curVol}
                    onChange={(e) => handleVolumeChange(sound.id as any, parseFloat(e.target.value))}
                    disabled={!isPlaying}
                    className={`flex-1 h-1 rounded-full appearance-none cursor-pointer focus:outline-none transition-all ${
                      isPlaying ? 'bg-rose-400 accent-rose-500' : 'bg-neutral-250 cursor-not-allowed opacity-40'
                    }`}
                  />
                </div>
              </div>
            );
          })}
        </div>

        {/* SLEEP TIMER ROW */}
        <div className="border-t border-rose-100/10 pt-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="space-y-0.5">
            <span className="text-[10px] font-black uppercase tracking-wider text-neutral-400 block">
              {language === 'es' ? 'Temporizador de Sueño' : 'Sleep Timer'}
            </span>
            {sleepMinutes !== null ? (
              <span className="text-xs font-bold text-rose-500 flex items-center gap-1">
                ⏱️ {language === 'es' ? 'Apagando en' : 'Stopping in'} {formatTime(timeLeft)}
              </span>
            ) : (
              <span className="text-[11px] text-neutral-400 italic">
                {language === 'es' ? 'Sin límite de tiempo' : 'Continuous play'}
              </span>
            )}
          </div>

          <div className="flex gap-1.5 flex-wrap">
            {[
              { label: language === 'es' ? 'Apagado' : 'Off', value: null },
              { label: '5m', value: 5 },
              { label: '10m', value: 10 },
              { label: '15m', value: 15 },
              { label: '30m', value: 30 }
            ].map((opt, i) => (
              <button
                key={i}
                onClick={() => setSleepMinutes(opt.value)}
                className={`px-3 py-1 text-[10px] font-bold rounded-lg border cursor-pointer transition-colors ${
                  sleepMinutes === opt.value
                    ? 'bg-rose-400 text-white border-rose-400'
                    : 'bg-neutral-100/10 hover:bg-neutral-150 border-neutral-200/10 text-neutral-500'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* GUIDED DEEP BREATHING CONTROLLER CARD */}
      <div className={`p-5 rounded-3xl border shadow-sm flex flex-col items-center text-center ${
        currentTheme === 'dark' ? 'bg-neutral-900/60 border-neutral-850' : 'bg-white border-rose-100/50'
      }`}>
        <h3 className={`font-semibold tracking-tight text-sm md:text-base flex items-center gap-2 mb-1 self-start ${currentTheme === 'dark' ? 'text-white' : 'text-neutral-800'}`}>
          <Wind className="w-5 h-5 text-rose-400" />
          {language === 'es' ? 'Regulador de Aliento' : 'Breathing Regulator'}
        </h3>
        <p className="text-xs text-neutral-400 mb-6 self-start text-left">
          {language === 'es' 
            ? 'Una guía respiratoria de rítmica 4-4-4 para estabilizar las palpitaciones de inmediato.' 
            : 'A 4-4-4 rhythmic breathing guide to stabilize heart rate immediately.'}
        </p>

        {/* Breathing expanding circle visual element */}
        <div className="relative w-48 h-48 flex items-center justify-center mb-6">
          <AnimatePresence>
            {breatheState !== 'idle' && (
              <motion.div
                animate={{
                  scale: breatheState === 'inhale' ? 1.6 : breatheState === 'hold' ? 1.6 : 0.9,
                  opacity: breatheState === 'hold' ? 0.4 : 0.2
                }}
                transition={{ duration: 4, ease: 'easeInOut' }}
                className="absolute w-28 h-28 bg-gradient-to-tr from-rose-400 to-amber-300 rounded-full blur-xl"
              />
            )}
          </AnimatePresence>

          <div className="z-10 w-28 h-28 rounded-full bg-white/70 backdrop-blur-xl border border-white/40 flex flex-col items-center justify-center shadow-md">
            <span className="text-[10px] uppercase font-bold tracking-widest text-rose-400">
              {breatheState === 'idle' && 'Breathe'}
              {breatheState === 'inhale' && (language === 'es' ? 'Inhala' : 'Inhale')}
              {breatheState === 'hold' && (language === 'es' ? 'Sostén' : 'Hold')}
              {breatheState === 'exhale' && (language === 'es' ? 'Exhala' : 'Exhale')}
            </span>
            {breatheState !== 'idle' && (
              <span className="text-2xl font-bold mt-1 text-neutral-800">{breatheSeconds}</span>
            )}
          </div>
        </div>

        <div className="w-full flex gap-2 justify-center">
          {breatheState === 'idle' ? (
            <button
              onClick={startBreathing}
              className="px-6 py-2.5 bg-gradient-to-r from-rose-400 to-amber-300 text-white font-bold text-xs rounded-full shadow-md active:scale-95 transition-all uppercase tracking-wider"
            >
              {language === 'es' ? 'Comenzar Ciclo' : 'Start Cycle'}
            </button>
          ) : (
            <button
              onClick={stopBreathing}
              className="px-6 py-2.5 bg-neutral-200 text-neutral-600 font-bold text-xs rounded-full shadow-md active:scale-95 transition-all uppercase tracking-wider"
            >
              {language === 'es' ? 'Detener' : 'Stop'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
