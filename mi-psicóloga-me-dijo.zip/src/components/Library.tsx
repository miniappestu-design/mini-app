import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, BookOpen, Heart, Award, ArrowLeft, CheckCircle, Sparkles, Filter } from 'lucide-react';
import { Session, Language, UserState } from '../types';
import { allSessions } from '../data/sessions';

interface LibraryProps {
  language: Language;
  userState: UserState;
  onGainXP: (amount: number) => void;
  onCompleteSession: (id: number) => void;
}

export default function Library({ language, userState, onGainXP, onCompleteSession }: LibraryProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedSession, setSelectedSession] = useState<Session | null>(null);
  const [exerciseAnswer, setExerciseAnswer] = useState('');
  const [exerciseCompleted, setExerciseCompleted] = useState(false);

  // Categories translation dictionary
  const categoriesMap: Record<string, string> = {
    all: language === 'es' ? 'Todas' : 'All',
    ansiedad: language === 'es' ? 'Ansiedad' : 'Anxiety',
    autoestima: language === 'es' ? 'Autoestima' : 'Self-Esteem',
    limites: language === 'es' ? 'Límites' : 'Boundaries',
    apego: language === 'es' ? 'Apego' : 'Attachment',
    relaciones: language === 'es' ? 'Relaciones' : 'Relationships',
    duelo: language === 'es' ? 'Duelo y Pérdida' : 'Grief & Loss',
    crecimiento: language === 'es' ? 'Crecimiento' : 'Growth',
  };

  const currentTheme = userState.theme;

  // Filter 110 sessions securely
  const filteredSessions = allSessions.filter(session => {
    const matchesSearch = session.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          session.summary.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || session.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleOpenSession = (session: Session) => {
    setSelectedSession(session);
    setExerciseAnswer('');
    setExerciseCompleted(userState.completedDailyTasks.includes(`session-${session.id}`));
  };

  const handleCompleteExercise = () => {
    if (!selectedSession) return;
    setExerciseCompleted(true);
    onGainXP(50); // High rewards for book session completion
    onCompleteSession(selectedSession.id);
  };

  return (
    <div id="library-container" className="max-w-4xl mx-auto h-[calc(100vh-140px)] flex flex-col">
      <AnimatePresence mode="wait">
        {!selectedSession ? (
          <motion.div
            key="list"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            className="flex-1 flex flex-col overflow-hidden"
          >
            {/* Header Description */}
            <div className="mb-4">
              <h2 className={`text-2xl font-bold tracking-tight flex items-center gap-2 ${currentTheme === 'dark' ? 'text-white' : 'text-neutral-800'}`}>
                <BookOpen className="w-6 h-6 text-rose-400" />
                {language === 'es' ? 'Biblioteca de 110 Sesiones' : '110 Sessions Library'}
              </h2>
              <p className="text-xs text-neutral-400">
                {language === 'es' 
                  ? 'Explora las lecciones y ejercicios interactivos oficiales de la autora Olivia Miller.' 
                  : 'Explore the official interactive lessons and exercises by author Olivia Miller.'}
              </p>
            </div>

            {/* Filter Section (Translucent Bento Style) */}
            <div className={`p-4 rounded-3xl mb-4 border flex flex-col md:flex-row gap-3 ${
              currentTheme === 'dark' ? 'bg-neutral-900/40 border-neutral-900' : 'bg-white/80 border-rose-100/50'
            }`}>
              {/* Search Bar */}
              <div className="relative flex-1">
                <Search className="absolute left-3.5 top-3.5 w-4.5 h-4.5 text-neutral-400" />
                <input
                  type="text"
                  placeholder={language === 'es' ? 'Buscar entre las 110 sesiones...' : 'Search inside the 110 sessions...'}
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className={`w-full pl-11 pr-4 py-3 text-sm rounded-2xl border focus:outline-none focus:ring-2 focus:ring-rose-300 transition-all ${
                    currentTheme === 'dark'
                      ? 'bg-neutral-950 border-neutral-800 text-white focus:ring-rose-500'
                      : 'bg-rose-50/20 border-rose-100/40 text-neutral-800'
                  }`}
                />
              </div>

              {/* Category pills list */}
              <div className="flex items-center gap-1.5 overflow-x-auto py-1 scrollbar-none">
                <Filter className="w-4 h-4 text-rose-400 shrink-0 hidden md:block" />
                {Object.keys(categoriesMap).map((catKey) => (
                  <button
                    key={catKey}
                    onClick={() => setSelectedCategory(catKey)}
                    className={`px-3 py-1.5 rounded-full text-xs font-medium tracking-tight whitespace-nowrap transition-all duration-300 ${
                      selectedCategory === catKey
                        ? 'bg-gradient-to-r from-rose-400 to-coral-400 text-white shadow-sm'
                        : currentTheme === 'dark'
                          ? 'bg-neutral-800 hover:bg-neutral-700 text-neutral-300'
                          : 'bg-rose-50/50 hover:bg-rose-100/50 text-neutral-600'
                    }`}
                  >
                    {categoriesMap[catKey]}
                  </button>
                ))}
              </div>
            </div>

            {/* Sessions Scrollable List */}
            <div className="flex-1 overflow-y-auto space-y-3 pr-1 scrollbar-thin">
              {filteredSessions.length > 0 ? (
                filteredSessions.map((session) => {
                  const isCompleted = userState.completedDailyTasks.includes(`session-${session.id}`);
                  return (
                    <motion.div
                      key={session.id}
                      whileHover={{ scale: 1.01 }}
                      onClick={() => handleOpenSession(session)}
                      className={`p-4 rounded-3xl border cursor-pointer flex items-center justify-between transition-all duration-300 hover:shadow-md ${
                        currentTheme === 'dark'
                          ? 'bg-neutral-900/60 border-neutral-850 hover:border-neutral-700'
                          : 'bg-white border-rose-100/30 hover:border-rose-200'
                      }`}
                    >
                      <div className="flex items-start gap-4 flex-1 pr-2">
                        <div className={`w-11 h-11 rounded-2xl flex items-center justify-center text-xs font-bold shrink-0 ${
                          isCompleted
                            ? 'bg-emerald-100 text-emerald-600'
                            : 'bg-rose-50 text-rose-400'
                        }`}>
                          #{session.id}
                        </div>
                        <div className="flex flex-col">
                          <span className={`text-xs font-semibold tracking-wide uppercase px-2 py-0.5 rounded-full w-fit mb-1 ${
                            session.category === 'crecimiento' ? 'bg-amber-100 text-amber-700' :
                            session.category === 'ansiedad' ? 'bg-purple-100 text-purple-700' :
                            session.category === 'autoestima' ? 'bg-rose-100 text-rose-700' :
                            'bg-blue-100 text-blue-700'
                          }`}>
                            {categoriesMap[session.category]}
                          </span>
                          <h4 className={`font-semibold text-sm md:text-base tracking-tight leading-tight ${currentTheme === 'dark' ? 'text-white' : 'text-neutral-800'}`}>
                            {session.title}
                          </h4>
                          <p className="text-xs text-neutral-400 mt-1 line-clamp-2">
                            {session.summary}
                          </p>
                        </div>
                      </div>
                      <div className="shrink-0 flex items-center gap-2">
                        {isCompleted && (
                          <CheckCircle className="w-5 h-5 text-emerald-500 fill-emerald-50" />
                        )}
                        <BookOpen className="w-5 h-5 text-rose-300" />
                      </div>
                    </motion.div>
                  );
                })
              ) : (
                <div className="text-center py-12 text-neutral-400 text-sm">
                  {language === 'es' ? 'No se encontraron sesiones para este filtro.' : 'No sessions found for this filter.'}
                </div>
              )}
            </div>
          </motion.div>
        ) : (
          /* Active Session View (Translucent Glass card format) */
          <motion.div
            key="session-detail"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className={`flex-1 overflow-y-auto p-5 rounded-3xl border flex flex-col scrollbar-thin ${
              currentTheme === 'dark' ? 'bg-neutral-900 border-neutral-800 text-white' : 'bg-white border-rose-100/50'
            }`}
          >
            {/* Session Back Nav */}
            <div className="flex items-center justify-between mb-5">
              <button
                onClick={() => setSelectedSession(null)}
                className="flex items-center gap-1 text-xs font-semibold text-rose-400 hover:text-rose-500 transition-colors"
              >
                <ArrowLeft className="w-4 h-4" />
                {language === 'es' ? 'Volver a la Biblioteca' : 'Back to Library'}
              </button>
              <div className="flex items-center gap-1.5 text-xs text-amber-500 font-semibold bg-amber-50/50 px-2 py-1 rounded-full">
                <Award className="w-4 h-4" />
                <span>+50 {language === 'es' ? 'XP de Logro' : 'XP Reward'}</span>
              </div>
            </div>

            {/* Session Title & Info */}
            <div className="mb-4">
              <span className="text-[10px] font-bold tracking-widest uppercase text-rose-400">
                SESIÓN #{selectedSession.id} • {categoriesMap[selectedSession.category]}
              </span>
              <h1 className={`text-xl md:text-2xl font-bold tracking-tight mt-1 ${currentTheme === 'dark' ? 'text-white' : 'text-neutral-800'}`}>
                {selectedSession.title}
              </h1>
            </div>

            {/* Premium Blockquote Card */}
            <div className={`p-4 rounded-2xl border-l-4 border-rose-400 mb-5 italic text-sm ${
              currentTheme === 'dark' ? 'bg-neutral-950/60 text-neutral-300' : 'bg-rose-50/30 text-neutral-700'
            }`}>
              "{selectedSession.quote}"
            </div>

            {/* Session Content */}
            <div className="flex-1 space-y-4 text-sm leading-relaxed text-neutral-400 mb-6 font-normal">
              <p className="whitespace-pre-line">{selectedSession.content}</p>
              
              <div className={`p-4 rounded-2xl border mt-5 ${
                currentTheme === 'dark' ? 'bg-neutral-950/40 border-neutral-850' : 'bg-amber-50/20 border-amber-100/30'
              }`}>
                <h5 className="font-semibold text-xs text-amber-600 uppercase tracking-widest flex items-center gap-1.5 mb-2">
                  <Sparkles className="w-4 h-4" />
                  {language === 'es' ? 'Reflexión para ti' : 'Reflection of the day'}
                </h5>
                <p className={`text-sm italic font-medium ${currentTheme === 'dark' ? 'text-neutral-200' : 'text-neutral-700'}`}>
                  {selectedSession.reflectionPrompt}
                </p>
              </div>
            </div>

            {/* Practical Interactive Exercise Box */}
            <div className={`p-5 rounded-2xl border ${
              currentTheme === 'dark' ? 'bg-neutral-950/50 border-neutral-850' : 'bg-rose-50/20 border-rose-100/30'
            }`}>
              <h4 className={`font-semibold tracking-tight text-base mb-2 flex items-center gap-2 ${currentTheme === 'dark' ? 'text-white' : 'text-neutral-800'}`}>
                <Award className="w-5 h-5 text-rose-400" />
                {selectedSession.exercise.title}
              </h4>
              <p className="text-xs text-neutral-400 mb-4">
                {selectedSession.exercise.instructions}
              </p>

              {selectedSession.exercise.type === 'write' && (
                <div className="space-y-3">
                  <textarea
                    value={exerciseAnswer}
                    onChange={(e) => setExerciseAnswer(e.target.value)}
                    disabled={exerciseCompleted}
                    placeholder={selectedSession.exercise.prompt || 'Escribe tus pensamientos aquí...'}
                    className={`w-full p-3 text-xs rounded-xl border focus:outline-none focus:ring-2 focus:ring-rose-300 resize-none h-20 ${
                      currentTheme === 'dark'
                        ? 'bg-neutral-900 border-neutral-800 text-white'
                        : 'bg-white border-rose-100/40 text-neutral-800'
                    }`}
                  />
                  <button
                    onClick={handleCompleteExercise}
                    disabled={!exerciseAnswer.trim() || exerciseCompleted}
                    className={`w-full py-3 rounded-full text-xs font-semibold tracking-wide bg-gradient-to-r from-rose-400 to-amber-300 text-white shadow-md active:scale-95 transition-all ${
                      (!exerciseAnswer.trim() || exerciseCompleted) && 'opacity-50 cursor-not-allowed'
                    }`}
                  >
                    {exerciseCompleted ? '✓ Ejercicio Completado' : 'Enviar y ganar +50 XP'}
                  </button>
                </div>
              )}

              {selectedSession.exercise.type === 'choice' && (
                <div className="space-y-2">
                  {selectedSession.exercise.choices?.map((choice, i) => (
                    <button
                      key={i}
                      disabled={exerciseCompleted}
                      onClick={() => handleCompleteExercise()}
                      className={`w-full p-3 rounded-xl border text-left text-xs font-medium transition-all ${
                        exerciseCompleted
                          ? 'bg-emerald-50 border-emerald-100 text-emerald-800'
                          : currentTheme === 'dark'
                            ? 'bg-neutral-900 border-neutral-800 text-neutral-300 hover:border-rose-400'
                            : 'bg-white border-rose-100/30 text-neutral-700 hover:border-rose-400'
                      }`}
                    >
                      {choice}
                    </button>
                  ))}
                </div>
              )}

              {selectedSession.exercise.type === 'breathe' && (
                <button
                  onClick={handleCompleteExercise}
                  disabled={exerciseCompleted}
                  className="w-full py-3 rounded-full text-xs font-semibold tracking-wide bg-gradient-to-r from-rose-400 to-amber-300 text-white shadow-md active:scale-95 transition-all"
                >
                  {exerciseCompleted ? '✓ Ejercicio Completado' : 'Realizar respiración y completar (+50 XP)'}
                </button>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
