import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, Heart, Award, Flame, Languages, Calendar, Sun, Moon, ShieldAlert, BookOpen, Compass, X } from 'lucide-react';
import { Language, Mood, UserState } from './types';
import { i18nDict } from './i18n';
import Dashboard from './components/Dashboard';
import TherapistChat from './components/TherapistChat';
import Library from './components/Library';
import Toolbox from './components/Toolbox';
import SafeSpace from './components/SafeSpace';
import MyProgress from './components/MyProgress';
import WelcomeScreen from './components/WelcomeScreen';
import MindGames from './components/MindGames';
import HealingStories from './components/HealingStories';
import { audioSynth } from './lib/audio';

// Premium therapeutic quotes database for daily check-in
const MOTIVATIONAL_QUOTES = {
  es: [
    "No tienes que cargar con las expectativas de los demás para ser digna de amor. Elígete a ti hoy.",
    "Aprender a decir 'no' no te hace egoísta, te hace libre y fiel a tu propio corazón.",
    "Suelta el saco de boxeo emocional que no te pertenece. No eres responsable de arreglar a otros.",
    "Mereces un amor que no te haga dudar de tu valor, empezando por el amor que te das a ti misma.",
    "Poner límites es una de las formas más sagradas y honestas de decir: 'Yo también importo'.",
    "Está bien no poder con todo. Hoy date permiso de descansar, respirar y simplemente ser.",
    "La cajita de ojalá está llena de futuros que no controlas. Concéntrate en tu paz del presente.",
    "Sanar no es un camino lineal; tropezar no borra lo que ya has avanzado. Sigue adelante con compasión.",
    "No tienes que pedir perdón por ocupar espacio o por priorizar tu salud mental. Eres suficiente.",
    "Tu paz interior es innegociable. No la sacrifiques para mantener contentos a quienes no respetan tus límites."
  ],
  en: [
    "You don't have to carry others' expectations to be worthy of love. Choose yourself today.",
    "Learning to say 'no' doesn't make you selfish, it makes you free and true to your own heart.",
    "Drop the emotional punching bag that doesn't belong to you. You are not responsible for fixing others.",
    "You deserve a love that doesn't make you doubt your worth, starting with the love you give yourself.",
    "Setting boundaries is one of the most sacred and honest ways to say: 'I matter too.'",
    "It is okay not to be able to do everything. Today, give yourself permission to rest, breathe, and just be.",
    "The 'what if' box is full of futures you cannot control. Focus on your present peace.",
    "Healing is not a linear path; stumbling doesn't erase your progress. Move forward with compassion.",
    "You don't have to apologize for occupying space or prioritizing your mental health. You are enough.",
    "Your inner peace is non-negotiable. Do not sacrifice it to please those who don't respect your boundaries."
  ]
};

export default function App() {
  const [userId, setUserId] = useState('olivia_user_01');
  const [language, setLanguage] = useState<Language>('es');
  const [activeTab, setActiveTab] = useState<'home' | 'stories' | 'chat' | 'library' | 'toolbox' | 'safe_space' | 'progress'>('home');
  const [chatInitialMessage, setChatInitialMessage] = useState<string | null>(null);
  const [showLangMenu, setShowLangMenu] = useState(false);
  const [showMindGames, setShowMindGames] = useState(false);
  const [showStreakModal, setShowStreakModal] = useState(false);
  const [streakModalData, setStreakModalData] = useState<{
    streak: number;
    quote: string;
    isFirstWelcome: boolean;
  } | null>(null);

  // Core local persistence gamified state
  const [userState, setUserState] = useState<UserState>({
    xp: 0,
    level: 1,
    streak: 0,
    lastActiveDate: '',
    moodHistory: {},
    unlockedMedals: ['welcome_badge'],
    completedDailyTasks: [],
    weeklyXP: [0, 0, 0, 0, 0, 0, 0],
    soundEnabled: true,
    theme: 'light',
    startDate: '',
    daysAcompanamiento: 0,
    totalWellnessMinutes: 0,
    activitiesCount: 0,
  });

  // Load state and detect automatic browser language
  useEffect(() => {
    // Detect browser language
    const browserLang = navigator.language.split('-')[0] as Language;
    const supportedLangs: Language[] = ['es', 'en', 'pt', 'it', 'fr', 'de', 'nl', 'ca'];
    let detectedLang: Language = 'es';
    if (supportedLangs.includes(browserLang)) {
      setLanguage(browserLang);
      detectedLang = browserLang;
    }

    // Load localStorage
    const saved = localStorage.getItem('mi_psicologa_user_state');
    const todayStr = new Date().toISOString().split('T')[0];

    if (saved) {
      try {
        const loadedState: UserState = JSON.parse(saved);
        const lastActive = loadedState.lastActiveDate;
        let newStreak = loadedState.streak;
        let showModal = false;
        let updatedTasks = loadedState.completedDailyTasks || [];

        if (!lastActive) {
          // Absolute first session
          newStreak = 1;
          showModal = true;
          updatedTasks = [];
        } else if (lastActive !== todayStr) {
          // A brand new day has arrived!
          const lastActiveDateObj = new Date(lastActive);
          const todayDateObj = new Date(todayStr);
          
          // Clear time component for pure calendar-day comparison
          lastActiveDateObj.setHours(0, 0, 0, 0);
          todayDateObj.setHours(0, 0, 0, 0);
          
          const diffTime = Math.abs(todayDateObj.getTime() - lastActiveDateObj.getTime());
          const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));

          if (diffDays <= 1) {
            // Consecutive calendar day check-in! Increase racha!
            newStreak += 1;
          } else {
            // Missed one or more days: reset streak to 1 as self-love return
            newStreak = 1;
          }
          showModal = true;
          updatedTasks = []; // reset daily checkboxes for a fresh calendar day
        }

        let newDaysAcompanamiento = loadedState.daysAcompanamiento || 1;

        const nextState: UserState = {
          ...loadedState,
          streak: newStreak,
          lastActiveDate: todayStr,
          completedDailyTasks: updatedTasks,
          startDate: loadedState.startDate || todayStr,
          daysAcompanamiento: newDaysAcompanamiento,
          totalWellnessMinutes: loadedState.totalWellnessMinutes || 10,
          activitiesCount: loadedState.activitiesCount || 2,
        };

        setUserState(nextState);
        localStorage.setItem('mi_psicologa_user_state', JSON.stringify(nextState));

        if (showModal) {
          const quotesList = MOTIVATIONAL_QUOTES[detectedLang === 'es' ? 'es' : 'en'] || MOTIVATIONAL_QUOTES['es'];
          const randomQuote = quotesList[Math.floor(Math.random() * quotesList.length)];
          setStreakModalData({
            streak: newStreak,
            quote: randomQuote,
            isFirstWelcome: false
          });
          // Small timeout to allow interface to render nicely
          setTimeout(() => {
            setShowStreakModal(true);
          }, 800);
        }
      } catch (e) {
        console.error('Error loading state:', e);
      }
    }
  }, []);

  // Background preloading of daily healing stories for instant tab switching!
  useEffect(() => {
    const preloadStories = async () => {
      const name = userState.name || 'María';
      const day = userState.daysAcompanamiento || 1;
      const mood = Object.values(userState.moodHistory).pop() || 'ansiosa';
      const cacheKey = `daily_stories_cache_${name}_day${day}_${language}`;
      
      try {
        const cached = localStorage.getItem(cacheKey);
        if (cached) return; // Already cached, no need to preload!

        const res = await fetch('/api/gemini/generate-four-stories', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userName: name,
            mood,
            daysAcompanamiento: day,
            language,
          }),
        });
        if (res.ok) {
          const data = await res.json();
          if (data.stories && data.stories.length === 4) {
            localStorage.setItem(cacheKey, JSON.stringify(data.stories));
          }
        }
      } catch (e) {
        console.warn("Background preloading of stories skipped:", e);
      }
    };

    // Preload after 2.5 seconds to avoid slowing down initial app startup
    const timer = setTimeout(() => {
      preloadStories();
    }, 2500);

    return () => clearTimeout(timer);
  }, [userState.name, userState.daysAcompanamiento, userState.moodHistory, language]);

  const saveState = (newState: UserState) => {
    setUserState(newState);
    localStorage.setItem('mi_psicologa_user_state', JSON.stringify(newState));
  };

  const handleGainXP = (amount: number) => {
    let newXp = userState.xp + amount;
    let newLevel = userState.level;

    // Check leveling up (every 500 XP = level up)
    if (newXp >= newLevel * 500) {
      newLevel += 1;
    }

    const minutesEarned = amount >= 20 ? 5 : 2;
    const currentWellness = userState.totalWellnessMinutes || 10;
    const currentActivities = userState.activitiesCount || 2;

    const updated: UserState = {
      ...userState,
      xp: newXp,
      level: newLevel,
      totalWellnessMinutes: currentWellness + minutesEarned,
      activitiesCount: currentActivities + 1,
    };
    saveState(updated);
  };

  const handleUpdateMood = (mood: Mood) => {
    const today = new Date().toISOString().split('T')[0];
    const updated: UserState = {
      ...userState,
      moodHistory: {
        ...userState.moodHistory,
        [today]: mood,
      },
    };
    saveState(updated);
  };

  const handleCompleteSession = (id: number) => {
    const updated: UserState = {
      ...userState,
      completedDailyTasks: [...userState.completedDailyTasks, `session-${id}`],
    };
    saveState(updated);
  };

  const toggleTheme = () => {
    const nextTheme = userState.theme === 'light' ? 'dark' : 'light';
    saveState({
      ...userState,
      theme: nextTheme,
    });
  };

  const dict = i18nDict[language] || i18nDict['es'];

  if (!userState.name) {
    return (
      <WelcomeScreen
        language={language}
        theme={userState.theme}
        onSaveName={(name) => {
          const todayStr = new Date().toISOString().split('T')[0];
          const initialState: UserState = {
            xp: 100,
            level: 1,
            streak: 1,
            lastActiveDate: todayStr,
            moodHistory: {},
            unlockedMedals: ['welcome_badge'],
            completedDailyTasks: [],
            weeklyXP: [100, 0, 0, 0, 0, 0, 0],
            soundEnabled: true,
            theme: userState.theme,
            name,
            startDate: todayStr,
            daysAcompanamiento: 1,
            totalWellnessMinutes: 10,
            activitiesCount: 1,
          };
          saveState(initialState);

          // Select random daily quote for first registration welcome
          const quotesList = MOTIVATIONAL_QUOTES[language === 'es' ? 'es' : 'en'] || MOTIVATIONAL_QUOTES['es'];
          const randomQuote = quotesList[Math.floor(Math.random() * quotesList.length)];
          setStreakModalData({
            streak: 1,
            quote: randomQuote,
            isFirstWelcome: true
          });
          setShowStreakModal(true);
        }}
      />
    );
  }

  return (
    <div className={`min-h-screen transition-colors duration-300 ${
      userState.theme === 'dark' 
        ? 'bg-neutral-950 text-white selection:bg-rose-500/20' 
        : 'bg-gradient-to-b from-rose-50/10 via-amber-50/5 to-white text-neutral-800 selection:bg-rose-100'
    }`}>
      {/* Premium Header */}
      <header className={`sticky top-0 z-40 px-4 py-3 border-b backdrop-blur-md flex items-center justify-between ${
        userState.theme === 'dark' 
          ? 'bg-neutral-950/80 border-neutral-900' 
          : 'bg-white/80 border-rose-100/30'
      }`}>
        {/* Title branding with subtle book-logo icon */}
        <div className="flex items-center gap-2 cursor-pointer" onClick={() => setActiveTab('home')}>
          <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-rose-400 to-amber-300 flex items-center justify-center text-white shadow-sm">
            <Heart className="w-5 h-5 fill-rose-100" />
          </div>
          <div>
            <h1 className="font-bold text-sm tracking-tight leading-tight">
              {dict.appName}
            </h1>
            <p className="text-[10px] text-neutral-400 font-semibold tracking-tight">
              {language === 'es' ? '110 Sesiones Terapéuticas' : '110 Healing Sessions'}
            </p>
          </div>
        </div>

        {/* Global Toolbar Menu (i18n dropdown, theme toggler, rewards modal tracker) */}
        <div className="flex items-center gap-2">
          {/* Theme Toggler */}
          <button
            onClick={toggleTheme}
            className={`p-2 rounded-xl transition-all border ${
              userState.theme === 'dark'
                ? 'bg-neutral-900 border-neutral-800 text-amber-300'
                : 'bg-rose-50/20 border-rose-100/40 text-neutral-600 hover:bg-rose-50/50'
            }`}
          >
            {userState.theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>

          {/* Premium Language Dropdown Trigger */}
          <div className="relative">
            <button
              id="language-selector-btn"
              onClick={() => setShowLangMenu(!showLangMenu)}
              className={`px-3 py-1.5 rounded-xl border text-xs font-semibold tracking-wide flex items-center gap-1.5 transition-all ${
                userState.theme === 'dark'
                  ? 'bg-neutral-900 border-neutral-800 text-white'
                  : 'bg-rose-50/20 border-rose-100/40 text-neutral-700 hover:bg-rose-50/50'
              }`}
            >
              <Languages className="w-4 h-4" />
              <span className="uppercase">{language}</span>
            </button>

            {/* Translucent Language Selector Panel */}
            {showLangMenu && (
              <div className={`absolute right-0 mt-2 w-40 rounded-2xl border p-2 shadow-lg backdrop-blur-xl z-50 ${
                userState.theme === 'dark'
                  ? 'bg-neutral-900/95 border-neutral-800 text-white'
                  : 'bg-white/95 border-rose-100/60 text-neutral-800'
              }`}>
                <div className="grid grid-cols-1 gap-1 text-xs">
                  {[
                    { code: 'es', label: 'Español' },
                    { code: 'en', label: 'English' },
                    { code: 'pt', label: 'Português' },
                    { code: 'it', label: 'Italiano' },
                    { code: 'fr', label: 'Français' },
                    { code: 'de', label: 'Deutsch' },
                    { code: 'nl', label: 'Nederlands' },
                    { code: 'ca', label: 'Català' },
                  ].map((lang) => (
                    <button
                      key={lang.code}
                      onClick={() => {
                        setLanguage(lang.code as Language);
                        setShowLangMenu(false);
                      }}
                      className={`w-full py-2 px-3 text-left rounded-xl transition-colors ${
                        language === lang.code
                          ? 'bg-rose-100/50 text-rose-600 font-bold'
                          : 'hover:bg-rose-50/30'
                      }`}
                    >
                      {lang.label}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Main Responsive Body Canvas */}
      <main className="px-4 py-6 pb-28">
        <AnimatePresence mode="wait">
          {activeTab === 'home' && (
            <motion.div
              key="home"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25 }}
            >
              <Dashboard
                language={language}
                userState={userState}
                onGainXP={handleGainXP}
                onUpdateMood={handleUpdateMood}
                userId={userId}
                onOpenMindGames={() => setShowMindGames(true)}
                onNavigateToChat={(msg) => {
                  setChatInitialMessage(msg);
                  setActiveTab('chat');
                }}
              />
            </motion.div>
          )}

          {activeTab === 'chat' && (
            <motion.div
              key="chat"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25 }}
            >
              <TherapistChat
                language={language}
                userState={userState}
                onGainXP={handleGainXP}
                userId={userId}
                initialTopicMessage={chatInitialMessage}
                onClearInitialTopic={() => setChatInitialMessage(null)}
              />
            </motion.div>
          )}

          {activeTab === 'library' && (
            <motion.div
              key="library"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25 }}
            >
              <Library
                language={language}
                userState={userState}
                onGainXP={handleGainXP}
                onCompleteSession={handleCompleteSession}
              />
            </motion.div>
          )}

          {activeTab === 'toolbox' && (
            <motion.div
              key="toolbox"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25 }}
            >
              <Toolbox
                language={language}
                userState={userState}
                onGainXP={handleGainXP}
              />
            </motion.div>
          )}

          {activeTab === 'safe_space' && (
            <motion.div
              key="safe_space"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25 }}
            >
              <SafeSpace
                language={language}
                userState={userState}
                onGainXP={handleGainXP}
              />
            </motion.div>
          )}

          {activeTab === 'stories' && (
            <motion.div
              key="stories"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25 }}
            >
              <HealingStories
                language={language}
                userState={userState}
                onGainXP={handleGainXP}
                onUpdateUserState={(updated) => {
                  saveState({
                    ...userState,
                    ...updated
                  });
                }}
                onNavigateToChat={(msg) => {
                  setChatInitialMessage(msg);
                  setActiveTab('chat');
                }}
              />
            </motion.div>
          )}

          {activeTab === 'progress' && (
            <motion.div
              key="progress"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25 }}
            >
              <MyProgress
                language={language}
                userState={userState}
                onGainXP={handleGainXP}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* iOS Translucent Glassmorphic Bottom Tab Bar */}
      <nav className={`fixed bottom-4 left-4 right-4 z-40 rounded-full border p-2 backdrop-blur-xl shadow-lg flex items-center justify-around max-w-lg mx-auto transition-all ${
        userState.theme === 'dark'
          ? 'bg-neutral-900/80 border-neutral-800/80'
          : 'bg-white/80 border-rose-100/50'
      }`}>
        {[
          { id: 'home', label: dict.home, emoji: '🌱' },
          { id: 'stories', label: language === 'es' || language === 'ca' ? 'Historias' : 'Stories', emoji: '🌸' },
          { id: 'chat', label: dict.chat, emoji: '💬' },
          { id: 'library', label: dict.library, emoji: '📚' },
          { id: 'toolbox', label: dict.toolbox, emoji: '⚡' },
          { id: 'safe_space', label: dict.safeSpace, emoji: '🕊️' },
          { id: 'progress', label: language === 'es' || language === 'ca' ? 'Mi Progreso' : 'My Progress', emoji: '💖' }
        ].map(tab => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex flex-col items-center justify-center p-2 rounded-full cursor-pointer transition-all duration-300 relative ${
                isActive 
                  ? 'bg-rose-100/60 scale-102 text-rose-500 font-bold' 
                  : 'text-neutral-500 hover:text-rose-400'
              }`}
            >
              <span className="text-base md:text-lg">{tab.emoji}</span>
              <span className="text-[8px] font-semibold tracking-tight block mt-0.5 whitespace-nowrap">
                {tab.label}
              </span>
            </button>
          );
        })}
      </nav>

      {showMindGames && (
        <MindGames
          language={language}
          userState={userState}
          onGainXP={handleGainXP}
          onClose={() => setShowMindGames(false)}
        />
      )}

      {/* Premium Daily Streak & Self-Care Celebration Overlay */}
      <AnimatePresence>
        {showStreakModal && streakModalData && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-950/75 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 30 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              transition={{ type: 'spring', duration: 0.55 }}
              className={`w-full max-w-md p-6 rounded-3xl border relative overflow-hidden text-center shadow-2xl ${
                userState.theme === 'dark' 
                  ? 'bg-neutral-900 border-neutral-800 text-white' 
                  : 'bg-white border-rose-100/40 text-neutral-800'
              }`}
            >
              {/* Premium Top Accents */}
              <div className="absolute -top-12 -left-12 w-28 h-28 rounded-full bg-rose-400/10 blur-2xl pointer-events-none" />
              <div className="absolute -top-12 -right-12 w-28 h-28 rounded-full bg-amber-400/10 blur-2xl pointer-events-none" />

              <button
                onClick={() => setShowStreakModal(false)}
                className={`absolute top-4 right-4 p-1.5 rounded-full border transition-colors ${
                  userState.theme === 'dark'
                    ? 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:text-white'
                    : 'bg-neutral-50 border-neutral-200 text-neutral-400 hover:text-neutral-700'
                }`}
              >
                <X className="w-4 h-4" />
              </button>

              {/* Glowing Interactive Racha Icon */}
              <div className="flex flex-col items-center mt-3 mb-5">
                <div className="relative">
                  <motion.div 
                    animate={{ scale: [1, 1.25, 1], opacity: [0.35, 0, 0.35] }}
                    transition={{ repeat: Infinity, duration: 2.2, ease: 'easeInOut' }}
                    className="absolute inset-0 bg-rose-500 rounded-full blur-xl"
                  />
                  <div className="w-20 h-20 bg-gradient-to-tr from-rose-500 to-amber-400 rounded-3xl flex items-center justify-center text-white relative shadow-lg shadow-rose-500/20">
                    <Flame className="w-10 h-10 fill-amber-100/20 animate-bounce" style={{ animationDuration: '3s' }} />
                  </div>
                </div>
                
                <h3 className="text-2xl font-black tracking-tight mt-4">
                  {language === 'es' 
                    ? `¡Racha de ${streakModalData.streak} ${streakModalData.streak === 1 ? 'Día' : 'Días'}!` 
                    : `${streakModalData.streak}-Day Streak!`}
                </h3>
                <p className="text-[10px] text-rose-500 font-extrabold tracking-widest uppercase mt-1">
                  {language === 'es' ? 'Tu Psicóloga Te Acompaña' : 'Your Psychologist Companions You'}
                </p>
              </div>

              {/* Motivational Quote Rendered beautifully */}
              <div className={`p-5 rounded-2xl border text-left leading-relaxed relative ${
                userState.theme === 'dark'
                  ? 'bg-neutral-950/50 border-neutral-800 text-neutral-200'
                  : 'bg-rose-50/25 border-rose-100/30 text-neutral-700'
              }`}>
                <span className="absolute top-1.5 left-2 text-4xl font-serif text-rose-400/20 select-none">“</span>
                <p className="text-xs font-semibold px-4 pt-1 pb-1.5 italic leading-relaxed">
                  {streakModalData.quote}
                </p>
                <div className="text-right pr-4">
                  <span className="text-[9px] font-black uppercase tracking-wider text-rose-400">
                    {language === 'es' ? '— Tu Psicóloga' : '— Your Psychologist'}
                  </span>
                </div>
              </div>

              {/* Claim Reward Button */}
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => {
                  handleGainXP(30);
                  audioSynth.playBell(659.25); // E5 positive bell tone
                  setShowStreakModal(false);
                }}
                className="w-full mt-6 py-4 bg-gradient-to-r from-rose-500 to-amber-400 text-white font-extrabold rounded-2xl text-xs uppercase tracking-widest shadow-md hover:shadow-lg hover:shadow-rose-500/10 transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                <span>✨</span>
                <span>
                  {streakModalData.isFirstWelcome
                    ? (language === 'es' ? 'Empezar con amor propio (+30 XP)' : 'Begin with self-love (+30 XP)')
                    : (language === 'es' ? 'Recibir Regalo Diario (+30 XP)' : 'Claim Daily Gift (+30 XP)')
                  }
                </span>
              </motion.button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
