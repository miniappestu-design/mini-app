import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI, Type } from '@google/genai';
import { createServer as createViteServer } from 'vite';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini SDK with telemetry User-Agent
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// JSON file database path for user therapeutic history
const DB_PATH = path.join(process.cwd(), 'server_history.json');

// Helper to read database
function readDb() {
  if (!fs.existsSync(DB_PATH)) {
    return {};
  }
  try {
    const data = fs.readFileSync(DB_PATH, 'utf-8');
    return JSON.parse(data);
  } catch (e) {
    return {};
  }
}

// Helper to write database
function writeDb(data: any) {
  try {
    fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2), 'utf-8');
  } catch (e) {
    console.error('Failed to write history DB:', e);
  }
}

// API: Get user profile memory
app.get('/api/history/:userId', (req, res) => {
  const { userId } = req.params;
  const db = readDb();
  const profile = db[userId] || {
    moodHistory: [],
    conversationsCount: 0,
    goals: [],
    completedSessions: [],
    recaidas: [],
  };
  res.json(profile);
});

// API: Save goal or update profile
app.post('/api/history/:userId/update', (req, res) => {
  const { userId } = req.params;
  const updates = req.body; // e.g. { mood, completedSession, goal, recaida }
  const db = readDb();
  if (!db[userId]) {
    db[userId] = {
      moodHistory: [],
      conversationsCount: 0,
      goals: [],
      completedSessions: [],
      recaidas: [],
    };
  }

  const p = db[userId];
  if (updates.mood) {
    p.moodHistory.push({ date: new Date().toISOString(), mood: updates.mood });
  }
  if (updates.completedSession) {
    if (!p.completedSessions.includes(updates.completedSession)) {
      p.completedSessions.push(updates.completedSession);
    }
  }
  if (updates.goal) {
    if (!p.goals.includes(updates.goal)) {
      p.goals.push(updates.goal);
    }
  }
  if (updates.recaida) {
    p.recaidas.push({ date: new Date().toISOString(), note: updates.recaida });
  }

  writeDb(db);
  res.json({ success: true, profile: p });
});

// API: SECURE THERAPIST CHAT
app.post('/api/gemini/chat', async (req, res) => {
  const { message, mood, language, userId, chatHistory, userState } = req.body;
  const detectedLang = language || 'es';

  // Read profile to supply personalized memories to Gemini
  const db = readDb();
  const p = db[userId] || {
    moodHistory: [],
    conversationsCount: 0,
    goals: [],
    completedSessions: [],
    recaidas: [],
  };

  p.conversationsCount += 1;
  if (mood) {
    p.moodHistory.push({ date: new Date().toISOString(), mood });
  }
  db[userId] = p;
  writeDb(db);

  // Extract frequent emotions
  const emotions = p.moodHistory.map((h: any) => h.mood);
  const frequentEmotion = emotions.length > 0 
    ? emotions.sort((a: any, b: any) => emotions.filter((v: any) => v === a).length - emotions.filter((v: any) => v === b).length).pop()
    : mood || 'ansiosa';

  const userName = userState?.name || 'María';
  const userStreak = userState?.streak || 0;
  const userLevel = userState?.level || 1;
  const userXP = userState?.xp || 0;
  const unlockedMedals = userState?.unlockedMedals?.join(', ') || 'welcome_badge';
  const completedTasks = userState?.completedDailyTasks?.join(', ') || 'ninguna';

  // System instruction for Olivia Miller persona based on the book
  const systemInstruction = `
    Eres Olivia Miller, la terapeuta y autora empática del libro "Mi Psicóloga Me Dijo".
    Tu tono es sumamente compasivo, perspicaz, directo, honesto, libre de formalidades excesivas o cursilerías, pero profundamente contenedor y empoderador (estilo Headspace + Finch).
    Tu objetivo es ayudar a la usuaria a elegirse a sí misma sin culpas, poner límites y dejar de tolerar situaciones dañinas.
    
    DEBES DIRIGIRTE A LA USUARIA POR SU NOMBRE SIEMPRE. Su nombre es: ${userName}.
    Trátala por su nombre de manera cálida y natural al inicio o en momentos importantes de tu respuesta.

    INFORMACIÓN DE MEMORIA DEL PACIENTE (Úsala activamente para personalizar tu respuesta):
    - Nombre del paciente: ${userName}.
    - Idioma preferido: ${detectedLang}. RESPONDE ESTRICTAMENTE EN ESTE IDIOMA.
    - Estado emocional de hoy: ${mood || 'No especificado'}.
    - Emoción más frecuente guardada: ${frequentEmotion}.
    - Racha actual en la app: ${userStreak} días consecutivos cuidándose. Felicítala por su constancia si su racha es alta.
    - Nivel actual: Nivel ${userLevel} (${userXP} XP totales).
    - Medallas y logros obtenidos: ${unlockedMedals}.
    - Actividades completadas hoy: ${completedTasks}.
    - Metas terapéuticas activas: ${p.goals.join(', ') || 'Aprender a ponerse primero, sanar y amarse sin culpa'}.
    - Sesiones completadas del libro: ${p.completedSessions.length} sesiones.
    
    REGLAS DE CONVERSACIÓN:
    1. Dirígete a ella por su nombre (${userName}) constantemente y con mucho afecto fraternal.
    2. Nunca respondas con la misma plantilla. Adapta tus palabras al estado de ánimo.
    3. Haz preguntas cortas y poderosas que inviten a la introspección (estilo socrático).
    4. No des sermones largos. Mantén tus respuestas entre 2 y 4 párrafos cortos y scannables.
    5. Usa metáforas del libro si es apropiado (el saco de boxeo, soltar cuando estés lista, la cajita de ojalá).
  `;

  try {
    // Map client chat history to Gemini structure
    const contents = [];
    if (chatHistory && Array.isArray(chatHistory)) {
      // Limit context to last 10 messages for performance and token boundaries
      const recentHistory = chatHistory.slice(-10);
      for (const msg of recentHistory) {
        contents.push({
          role: msg.sender === 'user' ? 'user' : 'model',
          parts: [{ text: msg.text }],
        });
      }
    }
    // Append the current message
    contents.push({
      role: 'user',
      parts: [{ text: message }],
    });

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: contents as any,
      config: {
        systemInstruction,
        temperature: 0.75,
      },
    });

    res.json({ reply: response.text });
  } catch (error: any) {
    console.error('Gemini Chat API Error:', error);
    res.status(500).json({ error: error.message || 'Error en la conexión con la psicóloga IA.' });
  }
});

// API: SECURE DYNAMIC THERAPEUTIC DAILY STORY GENERATOR - 4 PREMIUM STORIES
app.post('/api/gemini/generate-four-stories', async (req, res) => {
  const {
    userName,
    mood,
    daysAcompanamiento,
    language,
    moodHistory,
    userGoals
  } = req.body;

  const targetLang = language || 'es';
  const detectedName = userName || 'María';
  const detectedMood = mood || 'ansiosa';
  const companionDay = daysAcompanamiento || 1;

  const prompt = `
    Eres Olivia Miller, la terapeuta y autora empática del libro "Mi Psicóloga Me Dijo".
    Genera exactamente cuatro (4) Historias Terapéuticas Diarias diferentes para la sección "Historias que Sanan" en el idioma: "${targetLang}".
    Las historias deben inspirarse libremente en los conceptos de aceptación, compasión, límites, amor propio y liberación emocional del libro "Mi Psicóloga Me Dijo", sin copiar pasajes largos directamente del PDF.
    Cada una de las cuatro historias debe ser completamente distinta, única, profunda y emocionalmente poderosa.

    PERFIL DE LA USUARIA:
    - Nombre: ${detectedName} (Dirígete a ella por su nombre de forma sumamente personal, amorosa y natural en cada historia).
    - Estado de ánimo hoy: ${detectedMood}
    - Día de acompañamiento: Día ${companionDay}

    Para cada una de las 4 historias, debes incluir de manera profunda y humana:
    1. Un dolor o conflicto emocional identificable (ej. dependencia afectiva, miedo al rechazo, agotamiento mental, culpa al decir "no").
    2. El desarrollo emocional de la situación con el que la usuaria se identifique.
    3. Una solución, aprendizaje o toma de conciencia basada en herramientas de terapia psicológica cognitiva y aceptación.
    4. Una reflexión final compasiva que invite al cambio y al crecimiento personal de ${detectedName}.
    5. Un mensaje inspirador que deje esperanza y paz al final.

    REQUISITOS FORMALES:
    - Cada historia debe tener exactamente entre 200 y 300 palabras.
    - Deben sentirse como si una psicóloga empática conversara directamente con ella de tú a tú, de manera cálida, nunca robótica.
    - TODO el contenido (títulos, historias, preguntas, reflexiones, ejercicios, juegos, retos, recompensas, etc.) debe estar redactado enteramente en el idioma: "${targetLang}". No mezcles idiomas bajo ninguna circunstancia.

    Genera una respuesta JSON que contenga un objeto con una clave "stories" que contenga un array de exactamente cuatro objetos de historias. El esquema es:
    {
      "stories": [
        {
          "id": 1,
          "titulo": "Título de la primera historia",
          "historia": "Contenido completo de la primera historia terapéutica (200-300 palabras, dirigiéndote a ${detectedName} de forma sumamente personal, amorosa y directa, adaptado a su emoción '${detectedMood}')",
          "preguntaReflexion": "Pregunta de reflexión poderosa relacionada para invitar a la introspección",
          "reflexionGuiada": "Una breve reflexión guiada para asimilar el aprendizaje profundo",
          "ejercicioPractico": {
            "titulo": "Título corto del ejercicio práctico",
            "descripcion": "Instrucciones detalladas de un ejercicio práctico de sanación que ${detectedName} puede hacer hoy"
          },
          "retoPersonalizado": "Un reto accionable, sencillo y poderoso para aplicar hoy en su vida diaria",
          "minijuegoRelacionado": {
            "titulo": "Título del minijuego",
            "descripcion": "Un minijuego de enfoque mental de 1 minuto (ej. romper cadenas mentales de dependencia, inflar la burbuja de respiración, liberar piedras de culpa en el océano, etc.)",
            "tipo": "breathe"
          },
          "recompensa": "Nombre de una medalla o recompensa simbólica de sanación (ej. 'Firmeza Sagrada 🌸', 'Límites de Acero 🛡️')",
          "fraseInspiradora": "Frase inspiradora corta y reconfortante extraída de la historia para guardar",
          "psicologaOpening": "Primer mensaje que dirá Olivia en el Chat IA para platicar de este tema de forma interactiva"
        },
        {
          "id": 2,
          "titulo": "Título de la segunda historia",
          "historia": "Contenido completo de la segunda historia terapéutica (200-300 palabras, dirigiéndote a ${detectedName} de forma sumamente personal, amorosa y directa, adaptado a su emoción '${detectedMood}')",
          "preguntaReflexion": "Pregunta de reflexión poderosa relacionada para invitar a la introspección",
          "reflexionGuiada": "Una breve reflexión guiada para asimilar el aprendizaje profundo",
          "ejercicioPractico": {
            "titulo": "Título corto del ejercicio práctico",
            "descripcion": "Instrucciones detalladas de un ejercicio práctico de sanación que ${detectedName} puede hacer hoy"
          },
          "retoPersonalizado": "Un reto accionable, sencillo y poderoso para aplicar hoy en su vida diaria",
          "minijuegoRelacionado": {
            "titulo": "Título del minijuego",
            "descripcion": "Un minijuego de enfoque mental de 1 minuto",
            "tipo": "pop_bubbles"
          },
          "recompensa": "Nombre de una medalla o recompensa simbólica de sanación (ej. 'Corazón Libre 🕊️', 'Soltar Amarras ⚓')",
          "fraseInspiradora": "Frase inspiradora corta y reconfortante extraída de la historia",
          "psicologaOpening": "Primer mensaje que dirá Olivia en el Chat IA para platicar de este tema de forma interactiva"
        },
        {
          "id": 3,
          "titulo": "Título de la tercera historia",
          "historia": "Contenido completo de la tercera historia terapéutica (200-300 palabras, dirigiéndote a ${detectedName} de forma sumamente personal, amorosa y directa, adaptado a su emoción '${detectedMood}')",
          "preguntaReflexion": "Pregunta de reflexión poderosa relacionada para invitar a la introspección",
          "reflexionGuiada": "Una breve reflexión guiada para asimilar el aprendizaje profundo",
          "ejercicioPractico": {
            "titulo": "Título corto del ejercicio práctico",
            "descripcion": "Instrucciones detalladas de un ejercicio práctico de sanación que ${detectedName} puede hacer hoy"
          },
          "retoPersonalizado": "Un reto accionable, sencillo y poderoso para aplicar hoy en su vida diaria",
          "minijuegoRelacionado": {
            "titulo": "Título del minijuego",
            "descripcion": "Un minijuego de enfoque mental de 1 minuto",
            "tipo": "drop_stones"
          },
          "recompensa": "Nombre de una medalla o recompensa simbólica de sanación (ej. 'Flor de Autocompasión 🌸', 'Espejo Divino 🪞')",
          "fraseInspiradora": "Frase inspiradora corta y reconfortante extraída de la historia",
          "psicologaOpening": "Primer mensaje que dirá Olivia en el Chat IA para platicar de este tema de forma interactiva"
        },
        {
          "id": 4,
          "titulo": "Título de la cuarta historia",
          "historia": "Contenido completo de la cuarta historia terapéutica (200-300 palabras, dirigiéndote a ${detectedName} de forma sumamente personal, amorosa y directa, adaptado a su emoción '${detectedMood}')",
          "preguntaReflexion": "Pregunta de reflexión poderosa relacionada para invitar a la introspección",
          "reflexionGuiada": "Una breve reflexión guiada para asimilar el aprendizaje profundo",
          "ejercicioPractico": {
            "titulo": "Título corto del ejercicio práctico",
            "descripcion": "Instrucciones detalladas de un ejercicio práctico de sanación que ${detectedName} puede hacer hoy"
          },
          "retoPersonalizado": "Un reto accionable, sencillo y poderoso para aplicar hoy en su vida diaria",
          "minijuegoRelacionado": {
            "titulo": "Título del minijuego de construir",
            "descripcion": "Instrucciones para un juego de construir un fuerte muro de autoestima y estabilidad con bloques emocionales",
            "tipo": "block_builder"
          },
          "recompensa": "Nombre de una medalla o recompensa simbólica de sanación (ej. 'Sagrario Interior 🏰', 'Vuelo Alado 🦅')",
          "fraseInspiradora": "Frase inspiradora corta y reconfortante extraída de la historia",
          "psicologaOpening": "Primer mensaje que dirá Olivia en el Chat IA para platicar de este tema de forma interactiva"
        }
      ]
    }
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            stories: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.INTEGER },
                  titulo: { type: Type.STRING },
                  historia: { type: Type.STRING },
                  preguntaReflexion: { type: Type.STRING },
                  reflexionGuiada: { type: Type.STRING },
                  ejercicioPractico: {
                    type: Type.OBJECT,
                    properties: {
                      titulo: { type: Type.STRING },
                      descripcion: { type: Type.STRING }
                    },
                    required: ['titulo', 'descripcion']
                  },
                  retoPersonalizado: { type: Type.STRING },
                  minijuegoRelacionado: {
                    type: Type.OBJECT,
                    properties: {
                      titulo: { type: Type.STRING },
                      descripcion: { type: Type.STRING },
                      tipo: { type: Type.STRING }
                    },
                    required: ['titulo', 'descripcion', 'tipo']
                  },
                  recompensa: { type: Type.STRING },
                  fraseInspiradora: { type: Type.STRING },
                  psicologaOpening: { type: Type.STRING }
                },
                required: [
                  'id', 'titulo', 'historia', 'preguntaReflexion', 'reflexionGuiada',
                  'ejercicioPractico', 'retoPersonalizado', 'minijuegoRelacionado',
                  'recompensa', 'fraseInspiradora', 'psicologaOpening'
                ]
              }
            }
          },
          required: ['stories']
        },
        temperature: 0.8,
      }
    });

    const data = JSON.parse(response.text.trim());
    res.json(data);
  } catch (error: any) {
    console.error("Error generating daily premium stories:", error);

    // Beautiful high-quality fallbacks translated to all target languages
    const fallbacks: Record<string, any[]> = {
      es: [
        {
          id: 1,
          titulo: 'La lección del saco de boxeo 🥊',
          historia: `Querida ${detectedName}, sé que hoy te sientes ${detectedMood}. A veces, en nuestro afán de ser buenas y amadas, nos convertimos sin querer en el saco de boxeo emocional de los demás. Aguantamos comentarios que pinchan, justificamos actitudes egoístas bajo la etiqueta de "es que está pasando un mal momento" y nos silenciamos para no molestar. Pero hoy, en tu día ${companionDay} de este camino, quiero recordarte algo vital: poner un límite firme no te hace una persona egoísta o mala. Te hace una persona valiente que decide respetarse a sí misma. No estás loca por sentirte tan cansada, ${detectedName}; lo que pasa es que estás cargando pesos ajenos. Suelta ese saco ahora mismo, no te pertenece.`,
          preguntaReflexion: '¿A quién o a qué situación le has estado sirviendo de saco de boxeo emocional últimamente para evitar un conflicto?',
          reflexionGuiada: 'Cierra los ojos un instante. Visualiza las cargas que sostienes. Si no son tuyas, date permiso para dar un paso atrás y respirar hondo.',
          ejercicioPractico: {
            titulo: 'El decreto de auto-respeto',
            descripcion: 'Escribe en un papel: "Hoy renuncio al papel de sostener lo que otros no quieren sanar". Rómpelo como acto de liberación.'
          },
          retoPersonalizado: 'Di un "No" claro y amable hoy a cualquier petición que te haga sentir incómoda o sobrecargada, sin dar explicaciones innecesarias.',
          minijuegoRelacionado: {
            titulo: 'Burbujas de límites 🫧',
            descripcion: 'Imagina que cada burbuja en pantalla es una expectativa ajena. Tócalas para disolverlas y recuperar tu espacio personal.',
            tipo: 'pop_bubbles'
          },
          recompensa: 'Medalla del Auto-Respeto 🛡️',
          fraseInspiradora: 'Poner un límite no es un acto de guerra; es tu mayor declaración de amor propio.',
          psicologaOpening: `Hola ${detectedName}. Me dolió ver cuánto peso cargas. ¿Platicamos sobre la historia del saco de boxeo? ¿Con quién sientes que te pasa esto?`
        },
        {
          id: 2,
          titulo: 'La cajita de ojalá 📦',
          historia: `A veces guardamos en el pecho una cajita invisible que yo llamo "la cajita de ojalá", ${detectedName}. Ojalá cambie, ojalá se dé cuenta, ojalá me pida disculpas, ojalá me valore como merezco. Sostenemos relaciones rotas o dinámicas que nos desgastan simplemente alimentando esa cajita de fantasía. Sin embargo, aceptar que hay personas que nunca van a darnos lo que necesitamos no es rendirse; es liberarse. Hoy, ${detectedName}, quiero que abraces la cruda pero sanadora verdad de que no puedes cambiar a nadie. Tu único deber real de rescate es contigo misma.`,
          preguntaReflexion: '¿Qué ojalá estás sosteniendo hoy que te impide ver la realidad y tomar una decisión por tu propio bien?',
          reflexionGuiada: 'Asimilar la realidad puede doler al principio, pero es el único suelo firme sobre el que puedes reconstruir tu paz mental.',
          ejercicioPractico: {
            titulo: 'Abriendo la cajita',
            descripcion: 'Anota en tu diario tres cosas que esperas de alguien y que probablemente nunca van a suceder. Léelas y murmura: "Lo acepto y me libero".'
          },
          retoPersonalizado: 'Evita justificar hoy una mala actitud de alguien. Mírala tal cual es y respira tu libertad.',
          minijuegoRelacionado: {
            titulo: 'Soltar las amarras ⚓',
            descripcion: 'Sigue la respiración rítmica del loto dorado para anclarte en el presente y soltar los ojalás del pasado.',
            tipo: 'breathe'
          },
          recompensa: 'Medalla de la Aceptación Liberadora 🕊️',
          fraseInspiradora: 'Dejar ir no es perder; es dejar espacio para que entre lo que realmente mereces.',
          psicologaOpening: `Hola ${detectedName}. Esa cajita de ojalá suele estar muy llena. ¿Quieres contarme qué ojalá te cuesta más soltar hoy?`
        },
        {
          id: 3,
          titulo: 'La tiranía de la mejor versión 🌸',
          historia: `Nos han vendido la idea constante de que debemos esforzarnos por alcanzar "nuestra mejor versión", ${detectedName}. Nos exigen estar siempre radiantes, productivas, sanadas y en equilibrio perfecto. Pero hoy quiero revelarte un secreto: esa exigencia es otra forma de maltrato emocional silencioso. Tu versión cansada, rota, triste, que apenas puede con el día de hoy, también es digna de ser amada y abrazada por ti. No necesitas ser perfecta para elegirte, ${detectedName}. Ser imperfecta y estar agotada también está bien. Hoy nos damos tregua.`,
          preguntaReflexion: '¿De qué manera te has estado exigiendo ser fuerte hoy cuando en realidad solo necesitabas parar y llorar?',
          reflexionGuiada: 'Date permiso para ser humana. Abraza tu vulnerabilidad. Tus grietas son por donde entra la luz de tu verdadera fortaleza.',
          ejercicioPractico: {
            titulo: 'Carta de tregua',
            descripcion: 'Coloca tu mano en el corazón y repite en voz alta tres veces: "Me perdono por estar cansada. Hoy es suficiente con respirar".'
          },
          retoPersonalizado: 'Cancela o pospone hoy una tarea que no sea urgente y usa ese tiempo para descansar plenamente sin sentir culpa.',
          minijuegoRelacionado: {
            titulo: 'Sacar las piedras de la culpa 🪨',
            descripcion: 'Arrastra las piedras pesadas de la autoexigencia fuera de tu mochila y lánzalas al mar azul para volver a flotar.',
            tipo: 'drop_stones'
          },
          recompensa: 'Medalla de la Autocompasión Divina 🌸',
          fraseInspiradora: 'No tienes que ser perfecta para ser amada; con tu cansancio y tus dudas, ya eres completamente suficiente.',
          psicologaOpening: `Hola ${detectedName}. Siento que te exiges demasiado. Hablemos de la tiranía de ser perfecta. ¿Cómo te trata tu voz interna hoy?`
        },
        {
          id: 4,
          titulo: 'El santuario del silencio interior 🏰',
          historia: `Querida ${detectedName}, a menudo huimos del silencio de nuestra propia compañía como si fuera un desierto hostil. Llenamos cada segundo con notificaciones, ruido o conversaciones vacías por miedo a encontrarnos con lo que habita en nuestro pecho. Pero el silencio no es tu enemigo; es un santuario sagrado. Hoy, en tu día ${companionDay}, quiero que aprendas a sentarte contigo misma sin juzgarte, sin resolver problemas y sin culparte. Eres un lugar seguro para ti, ${detectedName}.`,
          preguntaReflexion: '¿A qué pensamiento o emoción le temes más cuando te quedas completamente en silencio a solas?',
          reflexionGuiada: 'Imagina que tu mente es un estanque de agua clara. Si dejas de agitarlo, el lodo se asentará por sí mismo y verás con claridad.',
          ejercicioPractico: {
            titulo: 'Cinco minutos de nada',
            descripcion: 'Siéntate en silencio durante 5 minutos. No busques calmar la mente; solo observa tus pensamientos como nubes que pasan sin aferrarte a ellas.'
          },
          retoPersonalizado: 'Pasa las primeras dos horas de tu tarde hoy sin revisar redes sociales ni encender pantallas de fondo.',
          minijuegoRelacionado: {
            titulo: 'Tetris de la Calma 🧱',
            descripcion: 'Encaja las piezas de tus pilares emocionales (Paz, Amor, Límites, Respeto) para construir un fuerte muro de autoestima y estabilidad emocional.',
            tipo: 'block_builder'
          },
          recompensa: 'Medalla del Sagrario Interior 🏰',
          fraseInspiradora: 'El silencio no es vacío; está lleno de las respuestas que tanto has estado buscando afuera.',
          psicologaOpening: `Hola ${detectedName}. Qué bello encontrarnos en este silencio sagrado. ¿Has podido experimentar esa calma hoy? ¿Cómo te sientes al estar a solas contigo?`
        }
      ],
      en: [
        {
          id: 1,
          titulo: 'The Lesson of the Punching Bag 🥊',
          historia: `Dear ${detectedName}, I know you are feeling ${detectedMood} today. Sometimes, in our eagerness to be good and loved, we accidentally become the emotional punching bag for others. We endure comments that sting, we justify selfish attitudes because "they are going through a hard time", and we keep quiet to avoid generating tension. But today, on day ${companionDay} of your path, I want to remind you of something vital: setting a firm boundary does not make you a selfish or bad person. It makes you a courageous person who chooses to respect herself. You are not crazy for feeling so tired, ${detectedName}; you are just carrying weights that belong to others. Let go of that punching bag right now.`,
          preguntaReflexion: 'Whom or what situation have you been serving as an emotional punching bag lately to avoid conflict?',
          reflexionGuiada: 'Close your eyes for a moment. Visualize the weights you are carrying. If they are not yours, give yourself permission to step back and breathe.',
          ejercicioPractico: {
            titulo: 'The Self-Respect Decree',
            descripcion: 'Write on a piece of paper: "Today I renounce the role of holding what others refuse to heal." Tear it up as an act of release.'
          },
          retoPersonalizado: 'Say a clear and polite "No" today to any request that makes you feel uncomfortable or overloaded, without giving unnecessary explanations.',
          minijuegoRelacionado: {
            titulo: 'Boundary Bubbles 🫧',
            descripcion: 'Imagine each bubble on screen is another person\'s expectation. Tap them to dissolve them and reclaim your personal space.',
            tipo: 'pop_bubbles'
          },
          recompensa: 'Self-Respect Badge 🛡️',
          fraseInspiradora: 'Setting a boundary is not an act of war; it is your greatest declaration of self-love.',
          psicologaOpening: `Hello ${detectedName}. It hurt to see how much weight you carry. Shall we talk about the punching bag story? Who makes you feel this way?`
        },
        {
          id: 2,
          titulo: 'The Wish Box 📦',
          historia: `Sometimes we carry an invisible little box in our chest that I call "the wish box," ${detectedName}. "I wish they would change, I wish they would realize, I wish they would apologize, I wish they would value me." We sustain broken relationships or draining dynamics just by feeding that fantasy box. However, accepting that some people will never give us what we need is not giving up; it is setting ourselves free. Today, ${detectedName}, I want you to embrace the harsh but healing truth that you cannot change anyone. Your only real rescue duty is to yourself.`,
          preguntaReflexion: 'What wish are you holding onto today that prevents you from seeing reality and making a decision for your own good?',
          reflexionGuiada: 'Grasping reality can hurt at first, but it is the only solid ground upon which you can rebuild your peace of mind.',
          ejercicioPractico: {
            titulo: 'Opening the Box',
            descripcion: 'Write down three things you expect from someone that will probably never happen. Read them and whisper: "I accept this and I set myself free."'
          },
          retoPersonalizado: 'Avoid justifying someone\'s bad attitude today. See it for what it is and breathe in your freedom.',
          minijuegoRelacionado: {
            titulo: 'Loosening the Anchors ⚓',
            descripcion: 'Follow the rhythmic breathing of the golden lotus to anchor yourself in the present and let go of past wishes.',
            tipo: 'breathe'
          },
          recompensa: 'Liberating Acceptance Badge 🕊️',
          fraseInspiradora: 'Letting go is not losing; it is leaving space for what you truly deserve to enter.',
          psicologaOpening: `Hello ${detectedName}. That wish box is usually very full. Do you want to tell me which wish is hardest for you to let go of today?`
        },
        {
          id: 3,
          titulo: 'The Tyranny of the Best Version 🌸',
          historia: `We have been sold the constant idea that we must strive to reach "our best version," ${detectedName}. We are demanded to be always glowing, productive, healed, and in perfect balance. But today I want to reveal a secret: that demand is just another form of silent emotional abuse. Your tired, broken, sad version, which can barely handle today, is also worthy of being loved and embraced by you. You do not need to be perfect to choose yourself, ${detectedName}. Being imperfect and exhausted is also okay. Today we give ourselves a truce.`,
          preguntaReflexion: 'In what ways have you been demanding yourself to be strong today when you actually just needed to stop and cry?',
          reflexionGuiada: 'Give yourself permission to be human. Embrace your vulnerability. Your cracks are where the light of your true strength enters.',
          ejercicioPractico: {
            titulo: 'Letter of Truce',
            descripcion: 'Place your hand on your heart and repeat out loud three times: "I forgive myself for being tired. Today, breathing is enough."'
          },
          retoPersonalizado: 'Cancel or postpone a task today that is not urgent and use that time to rest fully without feeling guilty.',
          minijuegoRelacionado: {
            titulo: 'Remove Guilt Stones 🪨',
            descripcion: 'Drag the heavy stones of self-demand out of your backpack and drop them into the blue sea to float again.',
            tipo: 'drop_stones'
          },
          recompensa: 'Divine Self-Compassion Badge 🌸',
          fraseInspiradora: 'You do not have to be perfect to be loved; with your fatigue and your doubts, you are already completely enough.',
          psicologaOpening: `Hello ${detectedName}. I feel you demand too much of yourself. Let's talk about the tyranny of being perfect. How is your inner voice treating you today?`
        },
        {
          id: 4,
          titulo: 'The Sanctuary of Inner Silence 🏰',
          historia: `Dear ${detectedName}, we often flee from the silence of our own company as if it were a hostile desert. We fill every second with notifications, noise, or empty chatter out of fear of meeting what lives in our chest. But silence is not your enemy; it is a sacred sanctuary. Today, on day ${companionDay}, I want you to learn to sit with yourself without judgment, without solving problems, and without blame. You are a safe place for yourself, ${detectedName}.`,
          preguntaReflexion: 'What thought or emotion do you fear most when you are left completely alone in silence?',
          reflexionGuiada: 'Imagine your mind is a pool of clear water. If you stop agitating it, the mud will settle on its own, and you will see with clarity.',
          ejercicioPractico: {
            titulo: 'Five Minutes of Nothingness',
            descripcion: 'Sit in silence for 5 minutes. Do not try to quiet your mind; just watch your thoughts like passing clouds without holding onto them.'
          },
          retoPersonalizado: 'Spend the first two hours of your afternoon today without checking social media or turning on background screens.',
          minijuegoRelacionado: {
            titulo: 'Tetris of Calm 🧱',
            descripcion: 'Stack and fit the blocks of your emotional pillars (Peace, Boundaries, Love, Respect) to build a strong wall of self-esteem and stability.',
            tipo: 'block_builder'
          },
          recompensa: 'Inner Sanctuary Badge 🏰',
          fraseInspiradora: 'Silence is not empty; it is full of the answers you have been looking for so much outside.',
          psicologaOpening: `Hello ${detectedName}. How beautiful to meet in this sacred silence. Have you been able to experience that calm today? How do you feel being alone with yourself?`
        }
      ]
    };

    // Use selected language or fall back to English or Spanish
    const langKey = fallbacks[targetLang] ? targetLang : (targetLang === 'ca' ? 'es' : 'en');
    const defaultStories = fallbacks[langKey] || fallbacks['es'];

    // If language is not es/en, we can quickly translate titles/histories using local prompt or just return English/Spanish as high-quality fallback
    res.json({ stories: defaultStories });
  }
});

// API: SECURE DYNAMIC THERAPEUTIC DAILY STORY GENERATOR
app.post('/api/gemini/generate-story', async (req, res) => {
  const {
    userName,
    mood,
    moodHistory,
    daysAcompanamiento,
    language,
    sessionTitle,
    sessionSummary,
    userGoals
  } = req.body;

  const targetLang = language || 'es';
  const detectedName = userName || 'María';
  const detectedMood = mood || 'ansiosa';
  const companionDay = daysAcompanamiento || 1;

  const prompt = `
    Eres Olivia Miller, la terapeuta y autora empática del libro "Mi Psicóloga Me Dijo".
    Tu objetivo es redactar la "Historia Terapéutica del Día" completamente personalizada para una usuaria.
    
    PERFIL DE LA USUARIA:
    - Nombre: ${detectedName} (Dirígete a ella por su nombre de forma cálida, cercana, fraternal y natural en la historia).
    - Estado de ánimo hoy: ${detectedMood}
    - Día de acompañamiento: Día ${companionDay} de su proceso.
    - Metas de la usuaria: ${userGoals ? JSON.stringify(userGoals) : "Elegirse a sí misma, sanar y poner límites"}
    - Historial emocional previo: ${moodHistory ? JSON.stringify(moodHistory) : "Ninguno registrado aún"}
    
    INSPIRACIÓN Y TEMA DEL LIBRO:
    - Capítulo/Tema de inspiración: "${sessionTitle}"
    - Sinopsis de apoyo: "${sessionSummary}"
    
    REQUISITOS DE LA HISTORIA:
    1. Debe estar redactada en un tono conversacional, súper cercano, como si le escribieras una carta o una reflexión cálida de tú a tú especialmente para ella.
    2. NO debe sonar fría ni como un capítulo rígido de un libro de teoría.
    3. Debe tener entre 250 y 300 palabras.
    4. Usa metáforas del libro (el saco de boxeo, soltar cuando estés lista, la cajita de ojalá) de manera sutil si encaja.
    5. Todo el contenido generado (historia, títulos, preguntas, ejercicios, retos, minijuegos, recompensas, etc.) debe estar redactado enteramente en el idioma: "${targetLang}". No mezcles idiomas bajo ninguna circunstancia.

    Genera un objeto JSON estricto con los siguientes campos exactos en el idioma "${targetLang}":
    {
      "titulo": "Título de la Historia",
      "historia": "Contenido de la historia terapéutica (entre 250 y 300 palabras, dirigiéndote a ${detectedName} de forma muy personal y amorosa, adaptado a su emoción '${detectedMood}' y al tema del libro '${sessionTitle}')",
      "preguntaReflexion": "Una pregunta profunda y compasiva para invitar a la introspección basada en la lectura",
      "ejercicioPractico": {
        "titulo": "Título corto del ejercicio práctico",
        "descripcion": "Instrucciones paso a paso para realizar un pequeño ejercicio de sanación hoy (ej: escribir, respirar, autocompasión)"
      },
      "retoPersonalizado": "Un reto accionable y sencillo para aplicar hoy en su vida diaria",
      "minijuegoRelacionado": {
        "titulo": "Título del minijuego",
        "descripcion": "Un minijuego de enfoque, atención plena, un laberinto mental, o un rompecabezas cognitivo rápido relacionado con soltar, perdonarse o sanar"
      },
      "recompensa": "Nombre de una recompensa/medalla simbólica y tierna por completar (ej: 'Abrazo Interior 🌸', 'Flor de los Límites 🛡️')",
      "fraseInspiradora": "Una frase corta, poderosa y reconfortante extraída de la historia para compartir o guardar",
      "psicologaOpening": "El mensaje inicial cálido y receptivo con el que Olivia abrirá el Chat IA si la usuaria decide conversar sobre esta historia"
    }
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            titulo: { type: Type.STRING },
            historia: { type: Type.STRING },
            preguntaReflexion: { type: Type.STRING },
            ejercicioPractico: {
              type: Type.OBJECT,
              properties: {
                titulo: { type: Type.STRING },
                descripcion: { type: Type.STRING }
              },
              required: ['titulo', 'descripcion']
            },
            retoPersonalizado: { type: Type.STRING },
            minijuegoRelacionado: {
              type: Type.OBJECT,
              properties: {
                titulo: { type: Type.STRING },
                descripcion: { type: Type.STRING }
              },
              required: ['titulo', 'descripcion']
            },
            recompensa: { type: Type.STRING },
            fraseInspiradora: { type: Type.STRING },
            psicologaOpening: { type: Type.STRING }
          },
          required: [
            'titulo',
            'historia',
            'preguntaReflexion',
            'ejercicioPractico',
            'retoPersonalizado',
            'minijuegoRelacionado',
            'recompensa',
            'fraseInspiradora',
            'psicologaOpening'
          ]
        },
        temperature: 0.75,
      }
    });

    const data = JSON.parse(response.text.trim());
    res.json(data);
  } catch (error: any) {
    console.error("Error generating daily story:", error);
    // Dynamic translated fallback if API fails
    const defaultTitle = targetLang === 'es' ? 'La lección del saco de boxeo' : 'The Lesson of the Punching Bag';
    const defaultStory = targetLang === 'es'
      ? `Querida ${detectedName}, sé que hoy te sientes ${detectedMood}. A veces, en nuestro afán de ser buenas, nos convertimos sin querer en el saco de boxeo emocional de los demás. Aguantamos comentarios que duelen, justificamos actitudes egoístas y nos callamos para no causar tensión. Pero quiero que recuerdes algo hoy, en tu día ${companionDay} de este camino: poner un límite no te hace una mala persona. Te hace una persona valiente que se respeta a sí misma. No estás loca por estar cansada, ${detectedName}. Estás sanando. Hoy, decide soltar ese saco de boxeo que no te pertenece. Estoy aquí contigo, paso a paso.`
      : `Dear ${detectedName}, I know you are feeling ${detectedMood} today. Sometimes, in our eagerness to be good, we accidentally become the emotional punching bag for others. We endure comments that hurt, we justify selfish attitudes, and we remain silent to avoid tension. But I want you to remember something today, on day ${companionDay} of your path: setting a boundary doesn't make you a bad person. It makes you a courageous person who respects herself. You are not crazy for being tired, ${detectedName}. You are healing. Today, decide to let go of that punching bag that doesn't belong to you. I am here with you, step by step.`;
    
    res.json({
      titulo: defaultTitle,
      historia: defaultStory,
      preguntaReflexion: targetLang === 'es' ? '¿A quién o a qué situación le has estado sirviendo de saco de boxeo últimamente?' : 'Whom or what situation have you been serving as a punching bag lately?',
      ejercicioPractico: {
        titulo: targetLang === 'es' ? 'La carta de descompresión' : 'Decompression Letter',
        descripcion: targetLang === 'es' ? 'Escribe en un papel todo el enojo acumulado por no haber puesto un límite. Luego, rópelo o bórralo como acto simbólico de liberación.' : 'Write down on paper all the anger accumulated from not setting a boundary. Then, tear it up or delete it as a symbolic act of release.'
      },
      retoPersonalizado: targetLang === 'es' ? 'Di "No" hoy a una pequeña petición que no deseas realizar, sin disculparte.' : 'Say "No" today to a small request you do not wish to fulfill, without apologizing.',
      minijuegoRelacionado: {
        titulo: targetLang === 'es' ? 'La burbuja de la calma' : 'Calm Bubble',
        descripcion: targetLang === 'es' ? 'Toca la pantalla siguiendo el ritmo de expansión y contracción de una flor zen durante 1 minuto.' : 'Tap the screen matching the expansion and contraction rhythm of a zen flower for 1 minute.'
      },
      recompensa: targetLang === 'es' ? 'Medalla del Auto-Respeto 🛡️' : 'Self-Respect Badge 🛡️',
      fraseInspiradora: targetLang === 'es' ? 'Poner un límite no es un acto de egoísmo; es tu mayor acto de amor propio.' : 'Setting a boundary is not an act of selfishness; it is your greatest act of self-love.',
      psicologaOpening: targetLang === 'es' ? `Hola, ${detectedName}. Me gustaría que platiquemos sobre la historia de hoy y sobre cómo te sentiste al leerla. ¿Cómo resuena en tu corazón?` : `Hello, ${detectedName}. I would love to talk about today's story and how you felt reading it. How does it resonate in your heart?`
    });
  }
});

// API: SECURE DYNAMIC CONTENT GENERATOR (Reflection, Challenge, Affirmation, Exercise, Game, Reward, Quiz)
app.post('/api/gemini/generate-daily', async (req, res) => {
  const { mood, language } = req.body;
  const targetLang = language || 'es';

  const prompt = `
    Genera un set completo de contenido de bienestar emocional diario altamente personalizado, vivo y único para una persona que hoy se siente: "${mood}".
    El contenido debe estar adaptado al libro "Mi Psicóloga Me Dijo" de Olivia Miller.
    Debe estar redactado completamente en el idioma: "${targetLang}".
    
    Genera un objeto JSON estricto con los siguientes campos exactos:
    {
      "afirmacion": "Una afirmación corta y de gran impacto para repetir hoy.",
      "reflexion": "Una reflexión corta e inspiradora basada en priorizarse, poner límites y sanar (2-3 oraciones).",
      "reto": "Un reto práctico y sencillo para aplicar hoy (ej. decir no a algo pequeño, tomar agua, 10 min de silencio).",
      "mision": "Una pregunta socrática o ejercicio de escritura para el diario hoy.",
      "pregunta": "Una pregunta profunda para cuestionar creencias limitantes.",
      "juego": "Un pequeño minijuego de atención plena, juego mental zen, o reto de enfoque divertido para centrarse hoy (1-2 oraciones).",
      "recompensa": "Un premio espiritual o medalla simbólica que recibirá hoy por completar la actividad (ej. 'Medalla de la Firmeza', 'Flor de la Autocompasión').",
      "quiz": {
        "pregunta": "Un cuestionario cognitivo rápido sobre cómo responder a un pensamiento limitador asociado a este estado de ánimo.",
        "opciones": ["Opción 1 saludable", "Opción 2 dañina o sumisa", "Opción 3 evasiva"],
        "correcta": 0,
        "explicacion": "Una breve explicación de por qué la opción saludable es la correcta según la psicología empática de Olivia Miller."
      }
    }
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            afirmacion: { type: Type.STRING },
            reflexion: { type: Type.STRING },
            reto: { type: Type.STRING },
            mision: { type: Type.STRING },
            pregunta: { type: Type.STRING },
            juego: { type: Type.STRING },
            recompensa: { type: Type.STRING },
            quiz: {
              type: Type.OBJECT,
              properties: {
                pregunta: { type: Type.STRING },
                opciones: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING }
                },
                correcta: { type: Type.INTEGER },
                explicacion: { type: Type.STRING }
              },
              required: ['pregunta', 'opciones', 'correcta', 'explicacion']
            }
          },
          required: ['afirmacion', 'reflexion', 'reto', 'mision', 'pregunta', 'juego', 'recompensa', 'quiz'],
        },
      },
    });

    const dailyData = JSON.parse(response.text.trim());
    res.json(dailyData);
  } catch (error: any) {
    console.error('Gemini Generate Daily Error:', error);
    // Secure offline-ready fallback content if API key is missing or fails
    const fallbacks: Record<string, any> = {
      es: {
        afirmacion: 'Hoy elijo mi paz mental sobre la necesidad de complacer a los demás.',
        reflexion: 'No eres egoísta por poner límites. Quienes se molestan cuando dices "no" son quienes se beneficiaban de tu falta de fronteras.',
        reto: 'Toma 10 minutos de silencio absoluto y haz una pausa de descompresión.',
        mision: 'Escribe en tu diario sobre una situación que te drena la energía actualmente.',
        pregunta: '¿Qué pasaría si te perdonas por no poder resolverle la vida a todo el mundo?',
        juego: 'Minijuego 5-4-3-2-1: Nombra en voz alta 5 cosas que veas, 4 cosas que sientas físicamente, 3 sonidos, 2 olores y 1 sabor.',
        recompensa: 'Medalla de la Firmeza Interior 🛡️',
        quiz: {
          pregunta: 'Si alguien se molesta porque pusiste un límite legítimo, ¿qué pensamiento es el más saludable?',
          opciones: [
            'Su enojo es su responsabilidad y refleja su incomodidad, no mi egoísmo.',
            'Debo pedir disculpas inmediatamente y ceder para no generar tensión.',
            'Quizás fui demasiado ruda y debería explicarle 10 veces por qué lo hice.'
          ],
          correcta: 0,
          explicacion: 'Quienes están acostumbrados a beneficiarse de tu falta de límites reaccionarán con molestia cuando empieces a establecerlos. Proteger tu paz no requiere justificaciones interminables.'
        }
      },
      en: {
        afirmacion: 'Today I choose my peace of mind over the need to please others.',
        reflexion: 'You are not selfish for setting boundaries. Those who get upset when you say "no" are those who benefited from your lack of limits.',
        reto: 'Take 10 minutes of absolute silence and have a decompression break.',
        mision: 'Write in your journal about a situation that currently drains your energy.',
        pregunta: 'What would happen if you forgive yourself for not being able to solve everyone\'s problems?',
        juego: 'The 5-4-3-2-1 Game: Look around and name 5 things you can see, 4 things you can touch, 3 things you can hear, 2 things you can smell, and 1 thing you can taste.',
        recompensa: 'Badge of Inner Steadfastness 🛡️',
        quiz: {
          pregunta: 'If someone gets angry because you set a legitimate boundary, which thought is healthiest?',
          opciones: [
            'Their anger is their responsibility and reflects their discomfort, not my selfishness.',
            'I must apologize immediately and yield to avoid tension.',
            'Maybe I was too harsh and should explain 10 times why I did it.'
          ],
          correcta: 0,
          explicacion: 'Those who are used to benefiting from your lack of boundaries will react with anger when you start setting them. Protecting your peace does not require endless justifications.'
        }
      }
    };
    const defaultData = fallbacks[targetLang] || fallbacks['es'];
    res.json(defaultData);
  }
});

async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer();
